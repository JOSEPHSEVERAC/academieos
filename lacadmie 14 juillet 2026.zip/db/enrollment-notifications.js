// db/enrollment-notifications.js
// Owns: transactional enrollment + boutique + welcome emails.
// Does NOT own: email transport (services/email.js), student CRUD, campaign emails.

const { sendEmail } = require('../services/email');

const FROM_EMAIL = process.env.FROM_EMAIL || 'contact@lacademie.art';
const FROM_NAME  = "L'Académie";

// ── Brand assets (sober palette: anthracite #0a0a0a, gold #c9a84c, cream #faf8f5) ─
// Mirrors the brand block used in routes/messaging.js so transactional mail
// reads as a single coherent family with campaign blasts.
const LOGO_URL = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev/company_98213/images/c14f688c-4f74-46d3-a097-a49cda1d65ec.png';

/**
 * Send enrollment confirmation emails after a student is registered.
 * Sends to parent_email and student.email (if distinct from parent).
 *
 * @param {object} student  - student row (first_name, last_name, email, parent_name, parent_email, formule, disciplines, etc.)
 * @param {string} saisonLabel - e.g. "2025/2026"
 */
async function sendEnrollmentConfirmation(pool, student, saisonLabel) {
  const recipients = [];

  // Parent email (primary contact)
  if (student.parent_email && student.parent_email.trim()) {
    recipients.push({ to: student.parent_email.trim(), role: 'responsable' });
  }

  // Student email (if different from parent email)
  if (student.email && student.email.trim()) {
    const isDuplicate = recipients.some(r => r.to.toLowerCase() === student.email.trim().toLowerCase());
    if (!isDuplicate) {
      recipients.push({ to: student.email.trim(), role: 'eleve' });
    }
  }

  if (recipients.length === 0) {
    console.log('[enrollment-email] No recipients found — skipping notification');
    return;
  }

  const studentName = `${student.first_name || ''} ${student.last_name || ''}`.trim();
  const saison = saisonLabel || '2025/2026';

  // Fetch formula details and disciplines if not already loaded
  let formuleLabel = student.formule_label || student.formule || 'Non renseignée';
  let disciplinesList = student.disciplines || [];

  if (!student.disciplines && student.discipline_ids) {
    const discRes = await pool.query(
      `SELECT d.name FROM disciplines d WHERE d.id = ANY($1)`,
      [student.discipline_ids]
    );
    disciplinesList = discRes.rows.map(r => r.name);
  }

  const disciplinesText = disciplinesList.length
    ? disciplinesList.join(', ')
    : 'Non renseignées';

  const promises = recipients.map(({ to, role }) =>
    sendEnrollmentEmail(to, studentName, role, {
      saison,
      formuleLabel,
      disciplinesText,
      numeroAdherent: student.numero_adherent,
    })
  );

  await Promise.allSettled(promises);
}

async function sendEnrollmentEmail(to, studentName, role, { saison, formuleLabel, disciplinesText, numeroAdherent }) {
  const roleGreeting = role === 'eleve'
    ? `Bonjour ${studentName},`
    : `Bonjour,`;

  const subject = `Confirmation d'inscription — ${studentName} — ${saison}`;

  const plain = `
L'Académie — Confirmation d'inscription

${roleGreeting}

Votre inscription à L'Académie vient d'être enregistrée pour la saison ${saison}.

--- RÉSUMÉ ---
Nom : ${studentName}
N° Adhérent : ${numeroAdherent || 'À confirmer'}
Saison : ${saison}
Formule : ${formuleLabel}
Disciplines : ${disciplinesText}

--- PROCHAINES ÉTAPES ---
• Paiement de l'adhésion annuelle (25 €)
• Paiement des mensualités selon votre formule
• Début des cours selon le planning

Merci de votre confiance.
L'Académie
www.lacademie.art
  `.trim();

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${subject}</title>
</head>
<body style="margin:0;padding:0;background:#f5f1ec;font-family:Arial,Helvetica,sans-serif">
  <div style="max-width:600px;margin:0 auto;background:#ffffff;border-radius:8px;overflow:hidden;margin-top:20px;margin-bottom:20px">
    <!-- Header -->
    <div style="background:#2d2d2d;padding:24px 32px;text-align:center">
      <div style="font-size:22px;font-weight:700;color:#ffffff;letter-spacing:0.5px">L'Académie</div>
      <div style="font-size:12px;color:#aaaaaa;margin-top:4px">École de danse — Arcachon &amp; Gujan-Mestras</div>
    </div>

    <!-- Body -->
    <div style="padding:32px">
      <p style="margin:0 0 20px;font-size:16px;color:#333">
        ${roleGreeting.replace('Bonjour', '<strong>Bonjour</strong>')}
      </p>

      <p style="margin:0 0 28px;font-size:15px;color:#555;line-height:1.6">
        Votre inscription à <strong>L'Académie</strong> vient d'être enregistrée pour la saison <strong>${saison}</strong>.
        Nous vous remercions de votre confiance.
      </p>

      <!-- Summary card -->
      <div style="background:#f9f6f2;border-radius:8px;padding:20px 24px;margin-bottom:24px">
        <table style="width:100%;border-collapse:collapse;font-size:14px">
          <tr>
            <td style="padding:6px 0;color:#888;width:130px">Élève</td>
            <td style="padding:6px 0;color:#222;font-weight:600">${studentName}</td>
          </tr>
          ${numeroAdherent ? `
          <tr>
            <td style="padding:6px 0;color:#888">N° Adhérent</td>
            <td style="padding:6px 0;color:#222;font-weight:600">${numeroAdherent}</td>
          </tr>
          ` : ''}
          <tr>
            <td style="padding:6px 0;color:#888">Saison</td>
            <td style="padding:6px 0;color:#222;font-weight:600">${saison}</td>
          </tr>
          <tr>
            <td style="padding:6px 0;color:#888">Formule</td>
            <td style="padding:6px 0;color:#222;font-weight:600">${formuleLabel}</td>
          </tr>
          <tr>
            <td style="padding:6px 0;color:#888;vertical-align:top">Disciplines</td>
            <td style="padding:6px 0;color:#222;font-weight:600">${disciplinesText}</td>
          </tr>
        </table>
      </div>

      <!-- Next steps -->
      <p style="margin:0 0 12px;font-size:14px;font-weight:700;color:#333">Prochaines étapes :</p>
      <ul style="margin:0 0 28px;padding-left:20px;font-size:14px;color:#555;line-height:1.8">
        <li>Régler l'adhésion annuelle (25 €)</li>
        <li>Paiement des mensualités selon votre formule</li>
        <li>Début des cours selon le planning</li>
      </ul>

      <p style="margin:0;font-size:13px;color:#888;line-height:1.5">
        Une question ? Contactez-nous à <a href="mailto:contact@lacademie.art" style="color:#c850a0">contact@lacademie.art</a>
      </p>
    </div>

    <!-- Footer -->
    <div style="background:#f5f1ec;padding:16px 32px;text-align:center">
      <p style="margin:0;font-size:11px;color:#aaa">
        L'Académie · Arcachon · Gujan-Mestras · <a href="mailto:contact@lacademie.art" style="color:#aaa">contact@lacademie.art</a>
      </p>
    </div>
  </div>
</body>
</html>
  `.trim();

  try {
    await sendEmail(to, subject, plain, html);
    console.log(`[enrollment-email] Sent to ${to} (${role}) — subject: ${subject}`);
  } catch (err) {
    console.error(`[enrollment-email] Failed to send to ${to}: ${err.message}`);
    // Non-fatal — don't block the enrollment response
  }
}

async function sendInscriptionWelcome(student, newFormuleLabel) {
  const email = student.email && student.email.trim();
  if (!email) {
    console.log('[inscription-email] No email — skipping');
    return;
  }
  if (student.unsubscribed === true) {
    console.log('[inscription-email] Unsubscribed — skipping');
    return;
  }

  const studentName = `${student.first_name || ''} ${student.last_name || ''}`.trim();
  const subject = "Bienvenue à L'Académie — accédez à votre espace élève";
  const loginUrl = 'https://lacademie.polsia.app/reseau/app';

  const plain = `
Bienvenue à L'Académie !

Bonjour ${studentName},

Votre inscription à L'Académie est confirmée — formule : ${newFormuleLabel}.

Vous pouvez dès maintenant accéder à votre espace élève :
${loginUrl}

À très bientôt sur les parquets !
L'Académie
www.lacademie.art
  `.trim();

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${subject}</title>
</head>
<body style="margin:0;padding:0;background:#f5f1ec;font-family:Arial,Helvetica,sans-serif">
  <div style="max-width:600px;margin:20px auto;background:#ffffff;border-radius:8px;overflow:hidden">
    <!-- Header -->
    <div style="background:#2d2d2d;padding:24px 32px;text-align:center">
      <div style="font-size:22px;font-weight:700;color:#ffffff;letter-spacing:0.5px">L'Académie</div>
      <div style="font-size:12px;color:#aaaaaa;margin-top:4px">École de danse — Arcachon &amp; Gujan-Mestras</div>
    </div>

    <!-- Body -->
    <div style="padding:32px">
      <p style="margin:0 0 20px;font-size:16px;color:#333">
        <strong>Bienvenue, ${studentName} !</strong>
      </p>

      <p style="margin:0 0 16px;font-size:15px;color:#555;line-height:1.6">
        Votre inscription à <strong>L'Académie</strong> est confirmée.
      </p>

      <div style="background:#f9f6f2;border-radius:8px;padding:16px 24px;margin-bottom:28px;font-size:14px;color:#555">
        Formule souscrite : <strong style="color:#222">${newFormuleLabel}</strong>
      </div>

      <p style="margin:0 0 24px;font-size:15px;color:#555;line-height:1.6">
        Votre espace élève est maintenant disponible. Vous y retrouverez le planning des cours,
        les actualités de l'école et votre suivi personnel.
      </p>

      <!-- CTA -->
      <div style="text-align:center;margin-bottom:32px">
        <a href="${loginUrl}"
           style="display:inline-block;background:#c9a84c;color:#ffffff;text-decoration:none;
                  padding:14px 32px;border-radius:6px;font-size:15px;font-weight:700;letter-spacing:0.3px">
          Accéder à mon espace élève
        </a>
      </div>

      <p style="margin:0;font-size:13px;color:#888;line-height:1.5">
        Une question ? Contactez-nous à <a href="mailto:contact@lacademie.art" style="color:#c9a84c">contact@lacademie.art</a>
      </p>
    </div>

    <!-- Footer -->
    <div style="background:#f5f1ec;padding:16px 32px;text-align:center">
      <p style="margin:0;font-size:11px;color:#aaa">
        L'Académie · Arcachon · Gujan-Mestras · <a href="mailto:contact@lacademie.art" style="color:#aaa">contact@lacademie.art</a>
      </p>
    </div>
  </div>
</body>
</html>
  `.trim();

  try {
    await sendEmail(email, subject, plain, html);
    console.log(`[inscription-email] Sent to ${email} — ${studentName}`);
  } catch (err) {
    console.error(`[inscription-email] Failed to send to ${email}: ${err.message}`);
    // Non-fatal — don't block the admin response
  }
}

// ── Boutique (Printful) order confirmation ────────────────────────────────────
// Sent to the adhèrent right after routes/boutique.js creates an order (auto-send
// to Printful just updates status — the confirmation email is one per order).
//
// @param {object} pool
// @param {object} order   - boutique_orders row + .items (with .product_name, .taille, .couleur)
// @param {object} user    - users_reseau row (nom, prenom, email)
// @param {Array}  [_lines] - unused legacy param kept for signature compatibility
async function sendOrderConfirmation(pool, order, user, _lines = null) {
  if (!user?.email) {
    console.log('[order-email] No recipient email — skipping confirmation');
    return;
  }
  const fullName = `${user.prenom || ''} ${user.nom || ''}`.trim() || 'Adhérent';
  const orderId = order?.id || order?.order_id || '—';
  const items = Array.isArray(order?.items) ? order.items : [];
  const totalCents = Number(order?.prix_adherent_cents || 0) + Number(order?.frais_livraison_cents || 0);
  const totalEuros = (totalCents / 100).toFixed(2).replace('.', ',');

  const subject = `Confirmation de commande — ${orderId}`;

  const linesText = items.map(it => {
    const qty = it.quantity || 1;
    const unit = (it.prix_vente_cents / 100).toFixed(2).replace('.', ',');
    const size  = it.taille  ? ` (taille ${it.taille})`  : '';
    const color = it.couleur ? ` — ${it.couleur}`        : '';
    return `• ${it.product_name || 'Article'}${size}${color} × ${qty}  —  ${unit} €`;
  }).join('\n');

  const linesHtml = items.map(it => {
    const qty = it.quantity || 1;
    const unit = (it.prix_vente_cents / 100).toFixed(2).replace('.', ',');
    const size  = it.taille  ? `<span style="color:#888"> (taille ${it.taille})</span>`  : '';
    const color = it.couleur ? `<span style="color:#888"> — ${it.couleur}</span>`        : '';
    return `<tr>
      <td style="padding:6px 0;color:#222;font-weight:600">${it.product_name || 'Article'}${size}${color}</td>
      <td style="padding:6px 16px;color:#888;text-align:center">${qty}</td>
      <td style="padding:6px 0;color:#222;text-align:right">${unit} €</td>
    </tr>`;
  }).join('');

  const APP_URL = process.env.APP_URL || 'https://lacademie.art';
  const unsubUrl = `${APP_URL}/api/email/unsubscribe?email=${encodeURIComponent(user.email)}`;

  const plain = `
L'Académie — Confirmation de commande

Bonjour ${fullName},

Nous avons bien reçu votre commande n°${orderId}. Elle sera transmise à notre partenaire d'impression (Printful) dans les plus brefs délais.

— DÉTAIL DE LA COMMANDE —
${linesText || '(aucun article)'}

Total payé : ${totalEuros} €
Mode : Printful (production à la demande, livraison internationale)

Vous recevrez un email dès l'expédition avec le numéro de suivi.

À très bientôt sur les parquets !
L'Académie
www.lacademie.art
  `.trim();

  const html = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@1,400&display=swap');
    body { margin:0; padding:0; background:#f5f5f5; font-family:Arial,Helvetica,sans-serif; }
    table { border-collapse:collapse; }
  </style>
</head>
<body>
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:20px 0">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:10px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08)">

      <!-- Header : logo sur fond blanc -->
      <tr>
        <td align="center" style="background:#ffffff;padding:32px 20px 24px">
          <img src="${LOGO_URL}" alt="L'Académie" width="140" style="max-width:140px;height:auto;display:block;margin:0 auto">
        </td>
      </tr>

      <!-- Corps -->
      <tr>
        <td style="padding:0 40px 28px;font-family:Arial,sans-serif;font-size:15px;line-height:1.7;color:#333333">
          <p style="margin:0 0 16px">Bonjour <strong>${fullName}</strong>,</p>
          <p style="margin:0 0 24px;color:#555">
            Nous avons bien reçu votre commande <strong>n°${orderId}</strong>.
            Elle sera transmise à notre partenaire d'impression (Printful) dans les plus brefs délais.
          </p>

          <div style="background:#f9f6f2;border-radius:8px;padding:20px 24px;margin-bottom:24px">
            <table style="width:100%;border-collapse:collapse;font-size:14px">
              ${linesHtml || '<tr><td style="padding:6px 0;color:#888">(aucun article)</td></tr>'}
              <tr>
                <td colspan="2" style="padding:14px 0 4px;border-top:1px solid #e5e0d8;color:#888">Total payé</td>
                <td style="padding:14px 0 4px;border-top:1px solid #e5e0d8;color:#222;font-weight:700;text-align:right">${totalEuros} €</td>
              </tr>
            </table>
          </div>

          <p style="margin:0;color:#888;font-size:13px;line-height:1.5">
            Production à la demande + livraison internationale.
            Vous recevrez un email dès l'expédition avec le numéro de suivi.
          </p>
        </td>
      </tr>

      <!-- Brand block : logo + slogan + 1965 (sober, anthracite/gold/cream) -->
      <tr>
        <td align="center" style="padding:32px 40px 28px;border-top:1px solid #e0e0e0">
          <img src="${LOGO_URL}" alt="L'Académie" width="80" style="max-width:80px;height:auto;display:block;margin:0 auto 12px">
          <div style="font-family:'Cormorant Garamond',Georgia,'Times New Roman',serif;font-size:18px;color:#000000;font-style:italic;letter-spacing:0.02em;margin-bottom:8px">&#171;&#8201;Avec ou sans pointes&#8201;&#187;</div>
          <div style="font-family:Arial,sans-serif;font-size:12px;color:#000000;letter-spacing:0.12em">1965</div>
        </td>
      </tr>

      <!-- Mentions légales -->
      <tr>
        <td align="center" style="background:#f9f9f9;padding:20px 40px;border-top:1px solid #ece8e3">
          <div style="font-family:Arial,sans-serif;font-size:11px;color:#9ca3af;line-height:1.8">
            THERPSIKHOROS SAS<br>
            24 rue Paul Pouget — 33470 Gujan-Mestras<br>
            SIRET 833 749 344 00028 · Tél. 05 56 54 45 51<br>
            <a href="https://lacademie.eu" style="color:#9ca3af;text-decoration:none">lacademie.eu</a>
            · <a href="mailto:contact@lacademie.eu" style="color:#9ca3af;text-decoration:none">contact@lacademie.eu</a>
          </div>
        </td>
      </tr>

      <!-- RGPD opt-out -->
      <tr>
        <td align="center" style="padding:12px 40px 24px;background:#f9f9f9">
          <div style="font-family:Arial,sans-serif;font-size:11px;color:#9ca3af">
            Vous recevez cet email car vous êtes adhérent(e) à L'Académie.
            <a href="${unsubUrl}" style="color:#9ca3af;text-decoration:underline">Se désinscrire</a>
          </div>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>`.trim();

  try {
    await sendEmail(user.email, subject, plain, html);
    console.log(`[order-email] Sent to ${user.email} — order ${orderId} — ${totalEuros} €`);
  } catch (err) {
    console.error(`[order-email] Failed to send to ${user.email}: ${err.message}`);
    // Non-fatal — don't block the createOrder / send-to-printful response.
  }
}

module.exports = { sendEnrollmentConfirmation, sendInscriptionWelcome, sendOrderConfirmation };