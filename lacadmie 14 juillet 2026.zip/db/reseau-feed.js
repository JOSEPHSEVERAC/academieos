// db/reseau-feed.js
// Query functions for the reseau social news feed.
// Owns: reseau_posts, reseau_comments, reseau_reactions.

const { notifySocialEvent } = require('../services/notifications');

/**
 * Create a new post.
 * @param {object} pool
 * @param {object} post - { authorId, content, imageData }
 */
async function createPost(pool, { authorId, content, imageData }) {
  const result = await pool.query(
    `INSERT INTO reseau_posts (author_id, content, image_data)
     VALUES ($1, $2, $3)
     RETURNING *`,
    [authorId, content.trim(), imageData || null]
  );
  return result.rows[0];
}

/**
 * Get paginated feed of posts with author info and reaction counts.
 * @param {object} pool
 * @param {number} limit
 * @param {number|null} beforeId - cursor for pagination (posts with id < beforeId)
 */
async function getFeed(pool, limit, beforeId) {
  let params;
  let whereClause;
  if (beforeId) {
    whereClause = `WHERE p.id < $1 AND p.is_deleted = false`;
    params = [beforeId, limit];
  } else {
    whereClause = `WHERE p.is_deleted = false`;
    params = [limit];
  }
  const result = await pool.query(
    `SELECT p.id, p.content, p.created_at,
            p.author_id,
            ur.nom AS author_nom, ur.prenom AS author_prenom, ur.role AS author_role,
            -- has_image: boolean flag so feed doesn't need to load base64 image_data
            (p.image_data IS NOT NULL) AS has_image,
            -- Reaction counts per emoji
            (SELECT json_object_agg(r.emoji, r.cnt) FROM (
               SELECT emoji, COUNT(*) AS cnt FROM reseau_reactions
               WHERE post_id = p.id GROUP BY emoji
             ) r) AS reaction_counts
     FROM reseau_posts p
     JOIN users_reseau ur ON ur.id = p.author_id
     ${whereClause}
     ORDER BY p.created_at DESC
     LIMIT $${params.length}`,
    params
  );
  return result.rows;
}

/**
 * Get a single post by ID with reactions.
 * @param {object} pool
 * @param {number} postId
 */
async function getPost(pool, postId) {
  const result = await pool.query(
    `SELECT p.id, p.content, p.image_data, p.created_at,
            ur.nom AS author_nom, ur.prenom AS author_prenom, ur.role AS author_role,
            (SELECT json_object_agg(r.emoji, r.cnt) FROM (
               SELECT emoji, COUNT(*) AS cnt FROM reseau_reactions
               WHERE post_id = p.id GROUP BY emoji
             ) r) AS reaction_counts
     FROM reseau_posts p
     JOIN users_reseau ur ON ur.id = p.author_id
     WHERE p.id = $1 AND p.is_deleted = false`,
    [postId]
  );
  return result.rows[0] || null;
}

/**
 * Create a comment on a post.
 * @param {object} pool
 */
async function createComment(pool, { postId, authorId, content }) {
  const result = await pool.query(
    `INSERT INTO reseau_comments (post_id, author_id, content)
     VALUES ($1, $2, $3)
     RETURNING *`,
    [postId, authorId, content.trim()]
  );
  // Notification seam — currently log-only; future work resolves recipient
  // (post author) and dispatches via Resend.
  notifySocialEvent(pool, {
    kind: 'comment_created',
    actorId: authorId,
    recipientId: null,
    entityType: 'comment',
    entityId: result.rows[0]?.id,
    post_id: postId,
  }).catch(() => {});
  return result.rows[0];
}

/**
 * Get comments for a post.
 * @param {object} pool
 * @param {number} postId
 */
async function getComments(pool, postId) {
  const result = await pool.query(
    `SELECT rc.id, rc.content, rc.created_at,
            ur.nom AS author_nom, ur.prenom AS author_prenom, ur.role AS author_role
     FROM reseau_comments rc
     JOIN users_reseau ur ON ur.id = rc.author_id
     WHERE rc.post_id = $1 AND rc.is_deleted = false
     ORDER BY rc.created_at ASC`,
    [postId]
  );
  return result.rows;
}

/**
 * Upsert a reaction (toggle: if same emoji exists, remove it).
 * Returns { action: 'added'|'removed', emoji }
 * @param {object} pool
 */
async function toggleReaction(pool, { postId, authorId, emoji }) {
  // Check if exists
  const existing = await pool.query(
    `SELECT id FROM reseau_reactions
     WHERE post_id = $1 AND author_id = $2 AND emoji = $3`,
    [postId, authorId, emoji]
  );

  if (existing.rows.length > 0) {
    // Remove
    await pool.query(
      `DELETE FROM reseau_reactions WHERE post_id = $1 AND author_id = $2 AND emoji = $3`,
      [postId, authorId, emoji]
    );
    await notifySocialEvent(pool, {
      kind: 'reaction_removed',
      actorId: authorId,
      entityType: 'reaction',
      entityId: postId,
      emoji,
    }).catch(() => {});
    return { action: 'removed', emoji };
  } else {
    await pool.query(
      `INSERT INTO reseau_reactions (post_id, author_id, emoji) VALUES ($1, $2, $3)
       ON CONFLICT DO NOTHING`,
      [postId, authorId, emoji]
    );
    await notifySocialEvent(pool, {
      kind: 'reaction_added',
      actorId: authorId,
      entityType: 'reaction',
      entityId: postId,
      emoji,
    }).catch(() => {});
    return { action: 'added', emoji };
  }
}

/**
 * Soft-delete a post (moderator only).
 * @param {object} pool
 * @param {number} postId
 */
async function deletePost(pool, postId) {
  await pool.query(`UPDATE reseau_posts SET is_deleted = true WHERE id = $1`, [postId]);
}

/**
 * Soft-delete a comment (moderator only).
 * @param {object} pool
 * @param {number} commentId
 */
async function deleteComment(pool, commentId) {
  await pool.query(`UPDATE reseau_comments SET is_deleted = true WHERE id = $1`, [commentId]);
}

/**
 * Get user by ID (for role checking).
 * @param {object} pool
 * @param {number} userId
 */
async function getUserById(pool, userId) {
  const result = await pool.query(
    `SELECT id, nom, prenom, role FROM users_reseau WHERE id = $1`,
    [userId]
  );
  return result.rows[0] || null;
}

module.exports = {
  createPost,
  getFeed,
  getPost,
  createComment,
  getComments,
  toggleReaction,
  deletePost,
  deleteComment,
  getUserById,
};