// db/media-events.js
// Query functions for the media_events table (event folders for photo/video galleries).
// Owns: media_events table. Does NOT own: reseau_photos, reseau_videos.

/**
 * Create a media event.
 * @param {object} pool
 * @param {object} event - { title, description, dateEvent, createdBy }
 */
async function createEvent(pool, { title, description, dateEvent, createdBy }) {
  const result = await pool.query(
    `INSERT INTO media_events (title, description, date_event, created_by)
     VALUES ($1, $2, $3, $4)
     RETURNING *`,
    [title.trim(), description || null, dateEvent || null, createdBy || null]
  );
  return result.rows[0];
}

/**
 * List all media events, ordered by date descending.
 * @param {object} pool
 */
async function listEvents(pool) {
  const result = await pool.query(
    `SELECT me.id, me.title, me.description, me.date_event, me.created_at,
            me.created_by,
            u.nom AS creator_nom, u.prenom AS creator_prenom,
            (SELECT COUNT(*) FROM reseau_photos WHERE event_id = me.id AND is_deleted = false)
              AS photo_count,
            (SELECT COUNT(*) FROM reseau_videos WHERE event_id = me.id AND is_deleted = false)
              AS video_count
     FROM media_events me
     LEFT JOIN users_reseau u ON u.id = me.created_by
     ORDER BY me.date_event DESC NULLS LAST, me.created_at DESC`
  );
  return result.rows;
}

/**
 * Get a single media event by ID.
 * @param {object} pool
 * @param {number} eventId
 */
async function getEventById(pool, eventId) {
  const result = await pool.query(
    `SELECT me.id, me.title, me.description, me.date_event, me.created_at,
            me.created_by,
            u.nom AS creator_nom, u.prenom AS creator_prenom
     FROM media_events me
     LEFT JOIN users_reseau u ON u.id = me.created_by
     WHERE me.id = $1`,
    [eventId]
  );
  return result.rows[0] || null;
}

/**
 * Update a media event (direction only).
 * @param {object} pool
 * @param {number} eventId
 * @param {object} fields - { title, description, dateEvent }
 */
async function updateEvent(pool, eventId, { title, description, dateEvent }) {
  const result = await pool.query(
    `UPDATE media_events
     SET title = COALESCE($2, title),
         description = COALESCE($3, description),
         date_event = COALESCE($4, date_event)
     WHERE id = $1
     RETURNING *`,
    [eventId, title ? title.trim() : null, description || null, dateEvent || null]
  );
  return result.rows[0] || null;
}

/**
 * Delete a media event (does not cascade — media remains, event_id becomes null).
 * @param {object} pool
 * @param {number} eventId
 */
async function deleteEvent(pool, eventId) {
  await pool.query(`DELETE FROM media_events WHERE id = $1`, [eventId]);
}

/**
 * Get photos belonging to a media event.
 * Visibility: direction sees all; others see public photos + their own private portraits.
 * @param {object} pool
 * @param {number} eventId
 * @param {object} opts - { userId, userRole }
 */
async function getPhotosByEvent(pool, eventId, { userId, userRole }) {
  const isDirection = ['president', 'directrice', 'professeur'].includes(userRole);

  let params = [eventId];
  let visibilityClause = isDirection
    ? `rp.event_id = $1 AND rp.is_deleted = false`
    : `rp.event_id = $1 AND rp.is_deleted = false AND (rp.is_private = false OR (rp.is_private = true AND rp.private_eleve_id = $2))`;

  if (!isDirection) params.push(userId);

  const result = await pool.query(
    `SELECT rp.id, rp.titre, rp.lieu, rp.evenement_type, rp.jour,
            rp.image_url, rp.is_private, rp.private_eleve_id,
            rp.description, rp.ballet_title, rp.created_at,
            rp.uploader_id, rp.uploader_role,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom
     FROM reseau_photos rp
     LEFT JOIN users_reseau u ON u.id = rp.uploader_id
     WHERE ${visibilityClause}
     ORDER BY rp.ballet_title ASC NULLS LAST, rp.jour DESC NULLS LAST, rp.created_at DESC`,
    params
  );
  return result.rows;
}

/**
 * Get videos belonging to a media event.
 * Visibility: direction sees all; others see public videos + their own private portraits.
 * @param {object} pool
 * @param {number} eventId
 * @param {object} opts - { userId, userRole }
 */
async function getVideosByEvent(pool, eventId, { userId, userRole }) {
  const isDirection = ['president', 'directrice', 'professeur'].includes(userRole);

  let params = [eventId];
  let visibilityClause = isDirection
    ? `rv.event_id = $1 AND rv.is_deleted = false`
    : `rv.event_id = $1 AND rv.is_deleted = false AND (rv.is_private = false OR (rv.is_private = true AND rv.private_eleve_id = $2))`;

  if (!isDirection) params.push(userId);

  const result = await pool.query(
    `SELECT rv.id, rv.titre, rv.lieu, rv.evenement_type, rv.jour,
            rv.video_url, rv.type_mime, rv.is_private, rv.private_eleve_id,
            rv.description, rv.ballet_title, rv.created_at,
            rv.uploader_id, rv.uploader_role,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom
     FROM reseau_videos rv
     LEFT JOIN users_reseau u ON u.id = rv.uploader_id
     WHERE ${visibilityClause}
     ORDER BY rv.ballet_title ASC NULLS LAST, rv.jour DESC NULLS LAST, rv.created_at DESC`,
    params
  );
  return result.rows;
}

/**
 * Get child ballets for a media event.
 * @param {object} pool
 * @param {number} parentEventId
 */
async function getBalletFolders(pool, parentEventId) {
  const result = await pool.query(
    `SELECT me.id, me.title, me.type, me.created_at,
            (SELECT COUNT(*) FROM reseau_photos WHERE event_id = me.id AND is_deleted = false)
              AS photo_count,
            (SELECT COUNT(*) FROM reseau_videos WHERE event_id = me.id AND is_deleted = false)
              AS video_count
     FROM media_events me
     WHERE me.parent_event_id = $1 AND me.type = 'ballet'
     ORDER BY me.title ASC`,
    [parentEventId]
  );
  return result.rows;
}

/**
 * Resolve or create a ballet entry for a given event_id + ballet_title.
 * Returns the media_events.id to set on the photo/video.
 * @param {object} pool
 * @param {number} parentEventId - the gala event id
 * @param {string} balletTitle - the ballet title
 * @param {number} createdBy - user id
 */
async function resolveBalletEntry(pool, parentEventId, balletTitle, createdBy) {
  const trimmed = balletTitle.trim();
  if (!trimmed) return null;

  // Try to find existing ballet
  const existing = await pool.query(
    `SELECT id FROM media_events WHERE title = $1 AND parent_event_id = $2 AND type = 'ballet'`,
    [trimmed, parentEventId]
  );
  if (existing.rows[0]) return existing.rows[0].id;

  // Create new ballet entry
  const created = await pool.query(
    `INSERT INTO media_events (title, parent_event_id, type, created_by)
     VALUES ($1, $2, 'ballet', $3)
     RETURNING id`,
    [trimmed, parentEventId, createdBy]
  );
  return created.rows[0].id;
}

module.exports = {
  createEvent,
  listEvents,
  getEventById,
  updateEvent,
  deleteEvent,
  getPhotosByEvent,
  getVideosByEvent,
  getBalletFolders,
  resolveBalletEntry,
};