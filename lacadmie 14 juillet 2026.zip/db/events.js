// db/events.js
// Owns: events + event_media tables — container model for event galleries.
// Does NOT own: reseau_photos/reseau_videos (standalone galleries), auth.

/**
 * List events with optional type filter. Returns media counts.
 */
async function listEvents(pool, { filterType, sort }) {
  const params = [];
  const where = ['e.is_deleted = false'];

  if (filterType) {
    params.push(filterType);
    where.push(`e.event_type = $${params.length}`);
  }

  const orderDir = sort === 'oldest' ? 'ASC' : 'DESC';

  const result = await pool.query(
    `SELECT e.id, e.title, e.location, e.event_date, e.event_type,
            e.description, e.cover_image, e.created_by, e.created_at,
            u.nom AS creator_nom, u.prenom AS creator_prenom,
            COALESCE(mc.photo_count, 0)::int AS photo_count,
            COALESCE(mc.video_count, 0)::int AS video_count
     FROM events e
     LEFT JOIN users_reseau u ON u.id = e.created_by
     LEFT JOIN LATERAL (
       SELECT
         COUNT(*) FILTER (WHERE file_type = 'photo' AND is_deleted = false) AS photo_count,
         COUNT(*) FILTER (WHERE file_type = 'video' AND is_deleted = false) AS video_count
       FROM event_media WHERE event_id = e.id
     ) mc ON true
     WHERE ${where.join(' AND ')}
     ORDER BY e.event_date ${orderDir}, e.created_at ${orderDir}
     LIMIT 100`,
    params
  );
  return result.rows;
}

/**
 * Get a single event by ID with media counts.
 */
async function getEventById(pool, eventId) {
  const result = await pool.query(
    `SELECT e.*, u.nom AS creator_nom, u.prenom AS creator_prenom,
            COALESCE(mc.photo_count, 0)::int AS photo_count,
            COALESCE(mc.video_count, 0)::int AS video_count
     FROM events e
     LEFT JOIN users_reseau u ON u.id = e.created_by
     LEFT JOIN LATERAL (
       SELECT
         COUNT(*) FILTER (WHERE file_type = 'photo' AND is_deleted = false) AS photo_count,
         COUNT(*) FILTER (WHERE file_type = 'video' AND is_deleted = false) AS video_count
       FROM event_media WHERE event_id = e.id
     ) mc ON true
     WHERE e.id = $1 AND e.is_deleted = false`,
    [eventId]
  );
  return result.rows[0] || null;
}

/**
 * Create a new event.
 */
async function createEvent(pool, { title, location, eventDate, eventType, description, coverImage, createdBy }) {
  const result = await pool.query(
    `INSERT INTO events (title, location, event_date, event_type, description, cover_image, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING *`,
    [title, location || '', eventDate, eventType || 'autre', description || '', coverImage || null, createdBy]
  );
  return result.rows[0];
}

/**
 * Update an existing event.
 */
async function updateEvent(pool, eventId, { title, location, eventDate, eventType, description, coverImage }) {
  const result = await pool.query(
    `UPDATE events SET
       title = COALESCE($2, title),
       location = COALESCE($3, location),
       event_date = COALESCE($4, event_date),
       event_type = COALESCE($5, event_type),
       description = COALESCE($6, description),
       cover_image = COALESCE($7, cover_image),
       updated_at = NOW()
     WHERE id = $1 AND is_deleted = false
     RETURNING *`,
    [eventId, title, location, eventDate, eventType, description, coverImage]
  );
  return result.rows[0] || null;
}

/**
 * Soft-delete an event and its media.
 */
async function deleteEvent(pool, eventId) {
  await pool.query(`UPDATE event_media SET is_deleted = true WHERE event_id = $1`, [eventId]);
  await pool.query(`UPDATE events SET is_deleted = true WHERE id = $1`, [eventId]);
}

/**
 * List media for an event.
 */
async function listEventMedia(pool, eventId) {
  const result = await pool.query(
    `SELECT em.id, em.event_id, em.file_type, em.type_mime, em.original_name,
            em.uploaded_by, em.uploaded_at,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom,
            (em.file_url IS NOT NULL AND em.file_url != '') AS has_file
     FROM event_media em
     LEFT JOIN users_reseau u ON u.id = em.uploaded_by
     WHERE em.event_id = $1 AND em.is_deleted = false
     ORDER BY em.uploaded_at DESC`,
    [eventId]
  );
  return result.rows;
}

/**
 * Add media to an event.
 */
async function addEventMedia(pool, { eventId, fileUrl, fileType, typeMime, originalName, uploadedBy }) {
  const result = await pool.query(
    `INSERT INTO event_media (event_id, file_url, file_type, type_mime, original_name, uploaded_by)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id, event_id, file_type, type_mime, original_name, uploaded_by, uploaded_at`,
    [eventId, fileUrl, fileType || 'photo', typeMime || '', originalName || '', uploadedBy]
  );
  // Auto-set cover image if event has none
  const event = await pool.query(`SELECT cover_image FROM events WHERE id = $1`, [eventId]);
  if (event.rows[0] && !event.rows[0].cover_image && fileType === 'photo') {
    await pool.query(`UPDATE events SET cover_image = $2 WHERE id = $1`, [eventId, fileUrl]);
  }
  return result.rows[0];
}

/**
 * Get a single media item by ID (with full file_url for download/stream).
 */
async function getMediaById(pool, mediaId) {
  const result = await pool.query(
    `SELECT * FROM event_media WHERE id = $1 AND is_deleted = false`,
    [mediaId]
  );
  return result.rows[0] || null;
}

/**
 * Delete a single media item (soft-delete).
 */
async function deleteMedia(pool, mediaId) {
  await pool.query(`UPDATE event_media SET is_deleted = true WHERE id = $1`, [mediaId]);
}

/**
 * Get distinct event types for filter UI.
 */
async function getEventTypes(pool) {
  const result = await pool.query(
    `SELECT DISTINCT event_type FROM events
     WHERE is_deleted = false AND event_type IS NOT NULL AND event_type != ''
     ORDER BY event_type`
  );
  return result.rows.map(r => r.event_type);
}

module.exports = {
  listEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent,
  listEventMedia,
  addEventMedia,
  getMediaById,
  deleteMedia,
  getEventTypes,
};
