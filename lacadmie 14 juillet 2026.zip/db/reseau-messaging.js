// db/reseau-messaging.js
// Query functions for reseau social direct messaging.
// Owns: reseau_conversations, reseau_conversation_participants, reseau_messages.

/**
 * List all conversations for a user, with participant info and last message preview.
 * Direction (president/directrice) sees all conversations.
 * @param {object} pool
 * @param {number|null} userId - null means admin view
 * @param {string|null} role - user role for admin visibility check
 */
async function listConversations(pool, userId, role) {
  let query;
  let params;

  if (userId && ['president', 'directrice'].includes(role)) {
    // Direction sees all conversations
    query = `
      SELECT
        rc.id,
        rc.created_at,
        rc.updated_at,
        -- Other participant info
        (
          SELECT json_build_object(
            'id', ur.id,
            'nom', ur.nom,
            'prenom', ur.prenom,
            'role', ur.role
          )
          FROM reseau_conversation_participants rcp
          JOIN users_reseau ur ON ur.id = rcp.user_id
          WHERE rcp.conversation_id = rc.id AND rcp.user_id != $1
          LIMIT 1
        ) AS other_participant,
        -- Last message
        (
          SELECT json_build_object(
            'id', rm.id,
            'content', LEFT(rm.content, 80),
            'sent_at', rm.sent_at,
            'sender_id', rm.sender_id
          )
          FROM reseau_messages rm
          WHERE rm.conversation_id = rc.id AND rm.is_deleted = false
          ORDER BY rm.sent_at DESC LIMIT 1
        ) AS last_message,
        -- Unread count
        (
          SELECT COUNT(*)
          FROM reseau_messages rm
          WHERE rm.conversation_id = rc.id
            AND rm.sender_id != $1
            AND rm.is_deleted = false
            AND rm.id > COALESCE(
              (SELECT MAX(read_id) FROM reseau_message_reads rmr WHERE rmr.conversation_id = rc.id AND rmr.user_id = $1),
              0
            )
        ) AS unread_count,
        -- Participant count (should be 2)
        (SELECT COUNT(*) FROM reseau_conversation_participants WHERE conversation_id = rc.id) AS participant_count
      FROM reseau_conversations rc
      ORDER BY rc.updated_at DESC`;
    params = [userId];
  } else if (userId) {
    query = `
      SELECT
        rc.id,
        rc.created_at,
        rc.updated_at,
        (
          SELECT json_build_object(
            'id', ur.id,
            'nom', ur.nom,
            'prenom', ur.prenom,
            'role', ur.role
          )
          FROM reseau_conversation_participants rcp
          JOIN users_reseau ur ON ur.id = rcp.user_id
          WHERE rcp.conversation_id = rc.id AND rcp.user_id != $1
          LIMIT 1
        ) AS other_participant,
        (
          SELECT json_build_object(
            'id', rm.id,
            'content', LEFT(rm.content, 80),
            'sent_at', rm.sent_at,
            'sender_id', rm.sender_id
          )
          FROM reseau_messages rm
          WHERE rm.conversation_id = rc.id AND rm.is_deleted = false
          ORDER BY rm.sent_at DESC LIMIT 1
        ) AS last_message,
        (
          SELECT COUNT(*)
          FROM reseau_messages rm
          WHERE rm.conversation_id = rc.id
            AND rm.sender_id != $1
            AND rm.is_deleted = false
            AND rm.id > COALESCE(
              (SELECT MAX(read_id) FROM reseau_message_reads rmr WHERE rmr.conversation_id = rc.id AND rmr.user_id = $1),
              0
            )
        ) AS unread_count,
        (SELECT COUNT(*) FROM reseau_conversation_participants WHERE conversation_id = rc.id) AS participant_count
      FROM reseau_conversations rc
      WHERE EXISTS (
        SELECT 1 FROM reseau_conversation_participants rcp
        WHERE rcp.conversation_id = rc.id AND rcp.user_id = $1
      )
      ORDER BY rc.updated_at DESC`;
    params = [userId];
  } else {
    return [];
  }

  const result = await pool.query(query, params);
  return result.rows;
}

/**
 * Get a conversation by ID, verifying participant access.
 * Direction bypasses participant check.
 * @param {object} pool
 * @param {number} conversationId
 * @param {number} userId
 * @param {string} role
 */
async function getConversation(pool, conversationId, userId, role) {
  // Verify participant OR direction
  if (!['president', 'directrice'].includes(role)) {
    const partCheck = await pool.query(
      `SELECT 1 FROM reseau_conversation_participants
       WHERE conversation_id = $1 AND user_id = $2`,
      [conversationId, userId]
    );
    if (!partCheck.rows.length) return null;
  }

  const result = await pool.query(
    `SELECT rc.*,
            (SELECT json_agg(json_build_object(
              'id', ur.id, 'nom', ur.nom, 'prenom', ur.prenom, 'role', ur.role
            ))
             FROM reseau_conversation_participants rcp
             JOIN users_reseau ur ON ur.id = rcp.user_id
             WHERE rcp.conversation_id = rc.id) AS participants
     FROM reseau_conversations rc
     WHERE rc.id = $1`,
    [conversationId]
  );
  return result.rows[0] || null;
}

/**
 * Get messages for a conversation (newest first by default for loading, reversed for display).
 * @param {object} pool
 * @param {number} conversationId
 * @param {number} userId
 * @param {string} role
 * @param {object} opts - { limit, beforeId, reversed (send chronological order) }
 */
async function getMessages(pool, conversationId, userId, role, opts = {}) {
  const { limit = 50, beforeId = null, reversed = false } = opts;

  // Verify access
  if (!['president', 'directrice'].includes(role)) {
    const partCheck = await pool.query(
      `SELECT 1 FROM reseau_conversation_participants
       WHERE conversation_id = $1 AND user_id = $2`,
      [conversationId, userId]
    );
    if (!partCheck.rows.length) return [];
  }

  let params;
  let query;

  if (beforeId) {
    params = [conversationId, beforeId, limit];
    query = `SELECT rm.id, rm.sender_id, rm.content, rm.is_deleted, rm.sent_at,
                    ur.nom AS sender_nom, ur.prenom AS sender_prenom, ur.role AS sender_role
             FROM reseau_messages rm
             JOIN users_reseau ur ON ur.id = rm.sender_id
             WHERE rm.conversation_id = $1 AND rm.id < $2 AND rm.is_deleted = false
             ORDER BY rm.sent_at DESC LIMIT $3`;
  } else {
    params = [conversationId, limit];
    query = `SELECT rm.id, rm.sender_id, rm.content, rm.is_deleted, rm.sent_at,
                    ur.nom AS sender_nom, ur.prenom AS sender_prenom, ur.role AS sender_role
             FROM reseau_messages rm
             JOIN users_reseau ur ON ur.id = rm.sender_id
             WHERE rm.conversation_id = $1 AND rm.is_deleted = false
             ORDER BY rm.sent_at DESC LIMIT $2`;
  }

  const result = await pool.query(query, params);

  // Mark conversation as read for this user
  if (result.rows.length > 0) {
    const latestId = result.rows[0].id;
    await pool.query(
      `INSERT INTO reseau_message_reads (conversation_id, user_id, read_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (conversation_id, user_id)
       DO UPDATE SET read_id = $3, updated_at = NOW()`,
      [conversationId, userId, latestId]
    );
    // Update conversation updated_at
    await pool.query(
      `UPDATE reseau_conversations SET updated_at = NOW() WHERE id = $1`,
      [conversationId]
    );
  }

  if (reversed) result.rows.reverse();
  return result.rows;
}

/**
 * Send a message in a conversation.
 * @param {object} pool
 * @param {number} conversationId
 * @param {number} senderId
 * @param {string} content
 */
async function sendMessage(pool, conversationId, senderId, content) {
  const result = await pool.query(
    `INSERT INTO reseau_messages (conversation_id, sender_id, content)
     VALUES ($1, $2, $3)
     RETURNING *`,
    [conversationId, senderId, content.trim()]
  );

  // Update conversation updated_at
  await pool.query(
    `UPDATE reseau_conversations SET updated_at = NOW() WHERE id = $1`,
    [conversationId]
  );

  return result.rows[0];
}

/**
 * Create a new DM conversation between two users, optionally with initial message.
 * @param {object} pool
 * @param {number} userId1 - initiator
 * @param {number} userId2 - recipient
 * @param {string|null} initialMessage
 */
async function createConversation(pool, userId1, userId2, initialMessage) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const convResult = await client.query(
      `INSERT INTO reseau_conversations DEFAULT VALUES RETURNING id, created_at, updated_at`
    );
    const conv = convResult.rows[0];

    await client.query(
      `INSERT INTO reseau_conversation_participants (conversation_id, user_id) VALUES ($1, $2)`,
      [conv.id, userId1]
    );
    await client.query(
      `INSERT INTO reseau_conversation_participants (conversation_id, user_id) VALUES ($1, $2)`,
      [conv.id, userId2]
    );

    let message = null;
    if (initialMessage && initialMessage.trim()) {
      const msgResult = await client.query(
        `INSERT INTO reseau_messages (conversation_id, sender_id, content)
         VALUES ($1, $2, $3)
         RETURNING *`,
        [conv.id, userId1, initialMessage.trim()]
      );
      message = msgResult.rows[0];
    }

    await client.query('COMMIT');

    return { ...conv, initial_message: message };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Get all users for starting a new conversation (excludes self).
 * Returns { id, nom, prenom, role }.
 * @param {object} pool
 * @param {number} excludeUserId
 */
async function getMembers(pool, excludeUserId) {
  const result = await pool.query(
    `SELECT id, nom, prenom, role FROM users_reseau WHERE id != $1 ORDER BY nom, prenom`,
    [excludeUserId]
  );
  return result.rows;
}

module.exports = {
  listConversations,
  getConversation,
  getMessages,
  sendMessage,
  createConversation,
  getMembers,
};