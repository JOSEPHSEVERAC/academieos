// db/boutique.js
// Query functions for the boutique module.
// Owns: boutique_products, boutique_orders, boutique_order_items tables.

// ── Products ─────────────────────────────────────────────────────────────────

async function getProducts(pool, { actif, categorie } = {}) {
  let params = [];
  let where = ['1=1'];
  if (actif !== undefined) { params.push(actif); where.push(`actif = $${params.length}`); }
  if (categorie) { params.push(categorie); where.push(`categorie = $${params.length}`); }
  const r = await pool.query(
    `SELECT * FROM boutique_products WHERE ${where.join(' AND ')} ORDER BY name`,
    params
  );
  return r.rows;
}

async function getProductById(pool, id) {
  const r = await pool.query('SELECT * FROM boutique_products WHERE id = $1', [id]);
  return r.rows[0] || null;
}

async function createProduct(pool, {
  name, description, sku_printful, printful_variant_id,
  prix_coutant_cents, prix_public_cents, remise_pourcentage,
  image_url, taille, couleur, categorie, actif,
}) {
  const r = await pool.query(
    `INSERT INTO boutique_products
       (name, description, sku_printful, printful_variant_id,
        prix_coutant_cents, prix_public_cents, remise_pourcentage,
        image_url, taille, couleur, categorie, actif)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
     RETURNING *`,
    [name, description || '', sku_printful || '', printful_variant_id || '',
     prix_coutant_cents || 0, prix_public_cents || 0, remise_pourcentage || 0,
     image_url || '', taille || '', couleur || '', categorie || 'vetements', actif !== false]
  );
  return r.rows[0];
}

async function updateProduct(pool, id, fields) {
  const allowed = ['name','description','sku_printful','printful_variant_id',
    'prix_coutant_cents','prix_public_cents','remise_pourcentage',
    'image_url','taille','couleur','categorie','actif','updated_at'];
  const setters = [];
  const values = [];
  let i = 0;
  for (const [k, v] of Object.entries(fields)) {
    if (allowed.includes(k)) {
      i++;
      setters.push(`${k} = $${i}`);
      values.push(v);
    }
  }
  if (setters.length === 0) return getProductById(pool, id);
  values.push(id);
  const r = await pool.query(
    `UPDATE boutique_products SET ${setters.join(',')}, updated_at = NOW() WHERE id = $${i + 1} RETURNING *`,
    values
  );
  return r.rows[0];
}

async function deleteProduct(pool, id) {
  await pool.query('DELETE FROM boutique_products WHERE id = $1', [id]);
}

// ── Orders ────────────────────────────────────────────────────────────────────

async function getOrders(pool, { user_id, status, limit } = {}) {
  let params = [];
  let where = ['1=1'];
  if (user_id) { params.push(user_id); where.push(`o.user_id = $${params.length}`); }
  if (status) { params.push(status); where.push(`o.status = $${params.length}`); }
  const lim = limit || 50;
  params.push(lim);
  const r = await pool.query(
    `SELECT o.*, ur.nom, ur.prenom,
            array_agg(json_build_object(
              'id', boi.id, 'name', bp.name, 'taille', boi.taille,
              'couleur', boi.couleur, 'prix_vente_cents', boi.prix_vente_cents,
              'prix_coutant_cents', boi.prix_coutant_cents
            )) as items
     FROM boutique_orders o
     JOIN users_reseau ur ON ur.id = o.user_id
     LEFT JOIN boutique_order_items boi ON boi.order_id = o.id
     LEFT JOIN boutique_products bp ON bp.id = boi.product_id
     WHERE ${where.join(' AND ')}
     GROUP BY o.id, ur.nom, ur.prenom
     ORDER BY o.created_at DESC
     LIMIT $${params.length}`,
    params
  );
  return r.rows;
}

async function getOrderById(pool, id) {
  const r = await pool.query(
    `SELECT o.*, ur.nom, ur.prenom, ur.email
     FROM boutique_orders o
     JOIN users_reseau ur ON ur.id = o.user_id
     WHERE o.id = $1`,
    [id]
  );
  if (!r.rows[0]) return null;
  const items = await pool.query(
    `SELECT boi.*, bp.name as product_name, bp.image_url
     FROM boutique_order_items boi
     JOIN boutique_products bp ON bp.id = boi.product_id
     WHERE boi.order_id = $1`,
    [id]
  );
  const order = r.rows[0];
  order.items = items.rows;
  return order;
}

async function createOrder(pool, {
  user_id,
  items, // [{ product_id, taille, couleur }]
  frais_livraison_cents = 0,
  notes = '',
}) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Calculate pricing for each item
    let prix_public_total = 0;
    let prix_adherent_total = 0;
    let cout_printful_total = 0;
    let remise_pourcentage = 0;

    const itemRows = [];
    for (const item of items) {
      const prod = await client.query('SELECT * FROM boutique_products WHERE id = $1', [item.product_id]);
      if (!prod.rows[0]) throw new Error(`Produit ${item.product_id} introuvable`);
      const p = prod.rows[0];
      remise_pourcentage = p.remise_pourcentage;
      const itemPublic = p.prix_public_cents;
      const itemAdherent = Math.round(p.prix_public_cents * (100 - p.remise_pourcentage) / 100);
      const itemCout = p.prix_coutant_cents;
      prix_public_total += itemPublic;
      prix_adherent_total += itemAdherent;
      cout_printful_total += itemCout;
      itemRows.push({ ...item, prix_vente_cents: itemAdherent, prix_coutant_cents: itemCout });
    }

    const marge_cents = prix_adherent_total - cout_printful_total - frais_livraison_cents;

    // Insert order
    const orderR = await client.query(
      `INSERT INTO boutique_orders
         (user_id, prix_public_cents, prix_adherent_cents, remise_pourcentage,
          cout_printful_cents, frais_livraison_cents, marge_cents, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [user_id, prix_public_total, prix_adherent_total, remise_pourcentage,
       cout_printful_total, frais_livraison_cents, marge_cents, notes]
    );
    const order = orderR.rows[0];

    // Insert order items
    for (const item of itemRows) {
      await client.query(
        `INSERT INTO boutique_order_items (order_id, product_id, taille, couleur, prix_vente_cents, prix_coutant_cents)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [order.id, item.product_id, item.taille || '', item.couleur || '',
         item.prix_vente_cents, item.prix_coutant_cents]
      );
    }

    await client.query('COMMIT');
    return getOrderById(pool, order.id);
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function updateOrderStatus(pool, id, { status, printful_order_id, printful_tracking_number, printful_tracking_url, notes }) {
  const fields = [];
  const vals = [];
  let i = 0;
  if (status) { i++; fields.push(`status = $${i}`); vals.push(status); }
  if (printful_order_id !== undefined) { i++; fields.push(`printful_order_id = $${i}`); vals.push(printful_order_id); }
  if (printful_tracking_number !== undefined) { i++; fields.push(`printful_tracking_number = $${i}`); vals.push(printful_tracking_number); }
  if (printful_tracking_url !== undefined) { i++; fields.push(`printful_tracking_url = $${i}`); vals.push(printful_tracking_url); }
  if (notes !== undefined) { i++; fields.push(`notes = $${i}`); vals.push(notes); }
  if (fields.length === 0) return getOrderById(pool, id);
  fields.push('updated_at = NOW()');
  vals.push(id);
  const r = await pool.query(
    `UPDATE boutique_orders SET ${fields.join(',')} WHERE id = $${i + 1} RETURNING *`,
    vals
  );
  return r.rows[0];
}

async function getOrderStats(pool) {
  const r = await pool.query(`
    SELECT
      COUNT(*) as total_orders,
      COUNT(*) FILTER (WHERE status = 'en_attente') as en_attente,
      COUNT(*) FILTER (WHERE status = 'envoyee_à_printful') as envoyee,
      COUNT(*) FILTER (WHERE status = 'en_production') as en_production,
      COUNT(*) FILTER (WHERE status = 'expediee') as expediee,
      COUNT(*) FILTER (WHERE status = 'livree') as livree,
      COALESCE(SUM(cout_printful_cents), 0) as total_cout_cents,
      COALESCE(SUM(prix_adherent_cents), 0) as total_ventes_cents,
      COALESCE(SUM(marge_cents), 0) as total_marge_cents
    FROM boutique_orders
  `);
  return r.rows[0];
}

module.exports = {
  getProducts, getProductById, createProduct, updateProduct, deleteProduct,
  getOrders, getOrderById, createOrder, updateOrderStatus, getOrderStats,
};