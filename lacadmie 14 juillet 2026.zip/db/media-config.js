// db/media-config.js
// Owns: read/write access to media_provider_config — admin-managed storage
// credentials that replace process.env.CLOUDFLARE_*, R2_*, BUNNY_* in
// services/cloudflare-stream.js and services/storage.js.
// Does NOT own: storage uploads (services/storage.js), Stream API calls
// (services/cloudflare-stream.js), admin endpoint (routes/admin-media-config.js).

const SECRET_FIELDS = ['api_token', 'secret_access_key', 'access_key_id'];
const UPDATABLE_FIELDS = [
  'provider',
  'account_id',
  'api_token',
  'bucket',
  'storage_zone',
  'endpoint',
  'access_key_id',
  'secret_access_key',
  'public_base_url',
  'cdn_host',
];
const PLACEHOLDER = '••••••••';

const VALID_PROVIDERS = new Set(['cloudflare_stream', 'bunny', 'r2', 's3', 'polsia', '']);

/**
 * Pick "is this column non-empty" — null and empty string both mean "not set".
 */
function hasDb(v) {
  return v != null && v !== '';
}

/**
 * Read the single config row. Returns null if the table is empty (cold start
 * before the migration ran, which shouldn't happen in production due to
 * auto-migration, but is safe to handle defensively).
 */
async function getActiveConfig(pool) {
  const result = await pool.query(
    `SELECT id, provider, account_id, api_token, bucket, storage_zone,
            endpoint, access_key_id, secret_access_key, public_base_url,
            cdn_host, updated_at, updated_by
       FROM media_provider_config
      WHERE id = 1
      LIMIT 1`
  );
  return result.rows[0] || null;
}

/**
 * Return the config row with secrets masked (api_token / secret_access_key /
 * access_key_id rendered as `••••••••` when present). The UI calls this;
 * internal callers that need real values should use getEffectiveStreamConfig /
 * getEffectiveStorageConfig / getActiveConfig directly.
 */
async function getEffectiveProviderConfig(pool, { includeSecrets = false } = {}) {
  const row = await getActiveConfig(pool);
  if (!row) return null;
  if (includeSecrets) return row;

  const masked = { ...row };
  for (const f of SECRET_FIELDS) {
    if (hasDb(masked[f])) masked[f] = PLACEHOLDER;
  }
  return masked;
}

/**
 * Update the single config row. Empty-string fields are written as NULL so
 * we don't keep placeholder whitespace around when an admin clears a value.
 */
async function updateConfig(pool, fields, userId) {
  const sets = [];
  const params = [];
  for (const key of UPDATABLE_FIELDS) {
    if (!Object.prototype.hasOwnProperty.call(fields, key)) continue;
    let value = fields[key];
    if (typeof value === 'string') value = value.trim();
    if (value === '') value = null;
    params.push(value);
    sets.push(`${key} = $${params.length}`);
  }
  if (sets.length === 0) {
    return getActiveConfig(pool);
  }
  params.push(userId || null);
  sets.push(`updated_by = $${params.length}`);
  sets.push(`updated_at = NOW()`);

  const result = await pool.query(
    `UPDATE media_provider_config
        SET ${sets.join(', ')}
      WHERE id = 1
      RETURNING id, provider, account_id, api_token, bucket, storage_zone,
                endpoint, access_key_id, secret_access_key, public_base_url,
                cdn_host, updated_at, updated_by`,
    params
  );
  return result.rows[0];
}

/**
 * Return the list of field names whose values actually changed between the
 * previous row and the freshly persisted one. Used by the route for the
 * audit log's `changed_keys` metadata. Secrets are compared by length only
 * to avoid leaking them through the metadata blob.
 */
function diffChangedKeys(prev, next) {
  const changed = [];
  for (const f of UPDATABLE_FIELDS) {
    const a = prev ? (prev[f] == null ? '' : String(prev[f])) : '';
    const b = next ? (next[f] == null ? '' : String(next[f])) : '';
    if (SECRET_FIELDS.includes(f)) {
      if (a.length !== b.length) changed.push(f);
    } else if (a !== b) {
      changed.push(f);
    }
  }
  return changed;
}

/**
 * Resolve CF Stream creds. Returns null if no provider is configured for it.
 * Falls back to env vars when DB row is empty or has provider=cloudflare_stream
 * but the DB columns are blank.
 */
async function getEffectiveStreamConfig(pool) {
  const row = await getActiveConfig(pool);
  if (row && row.provider && row.provider !== 'cloudflare_stream') {
    return null; // Admin picked a different provider — do not honor env either.
  }
  // row.provider is '' or 'cloudflare_stream' here → fall through to resolve.
  const dbAccount = hasDb(row?.account_id) ? row.account_id : null;
  const dbToken = hasDb(row?.api_token) ? row.api_token : null;
  const accountId = dbAccount || process.env.CLOUDFLARE_ACCOUNT_ID || null;
  const token = dbToken || process.env.CLOUDFLARE_STREAM_TOKEN || null;
  if (!accountId || !token) return null;
  return {
    provider: 'cloudflare_stream',
    accountId,
    token,
    publicBaseUrl:
      hasDb(row?.public_base_url)
        ? row.public_base_url
        : (process.env.CLOUDFLARE_PUBLIC_BASE_URL || null),
    source: dbAccount && dbToken ? 'db' : (dbAccount || dbToken ? 'partial-db' : 'env'),
  };
}

/**
 * Resolve storage provider config. Provider is picked as follows:
 *   1. media_provider_config.provider (when set non-empty).
 *   2. STORAGE_PROVIDER env var.
 *   3. Auto-detect from Bunny/R2 env presence.
 *   4. Polsia proxy fallback.
 *
 * Returns provider-grouped objects so storage.js can switch on provider
 * without re-deciding who's authoritative. Each provider block resolves
 * "DB column if non-empty, else process.env" per-field.
 */
async function getEffectiveStorageConfig(pool) {
  const row = await getActiveConfig(pool);
  const dbProvider = row?.provider || '';

  let provider = dbProvider;
  let source = 'db';
  if (!provider) {
    if (process.env.STORAGE_PROVIDER === 'r2') provider = 'r2';
    else if (process.env.STORAGE_PROVIDER === 'bunny') provider = 'bunny';
    else if (process.env.BUNNY_API_KEY && process.env.BUNNY_STORAGE_ZONE) provider = 'bunny';
    else if (
      process.env.R2_ACCOUNT_ID &&
      process.env.R2_ACCESS_KEY_ID &&
      process.env.R2_SECRET_ACCESS_KEY &&
      process.env.R2_BUCKET
    ) provider = 'r2';
    else provider = 'polsia';
    source = 'env';
  }

  // Pollisia credentials are platform-provided, never admin-managed.
  const polsia = {
    apiKey: process.env.POLSIA_API_KEY || null,
    apiUrl: process.env.POLSIA_API_URL || 'https://polsia.com/api',
    imageProxyUrl: process.env.POLSIA_IMAGE_PROXY_URL || null,
    publicHost: 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev',
  };

  // Bunny uses api_token (as Bearer key) + storage_zone + cdn_host.
  const bunny = {
    apiKey:      hasDb(row?.api_token)      ? row.api_token   : (process.env.BUNNY_API_KEY || null),
    storageZone: hasDb(row?.storage_zone)  ? row.storage_zone: (process.env.BUNNY_STORAGE_ZONE || null),
    cdnHost:     hasDb(row?.cdn_host)       ? row.cdn_host    : (process.env.BUNNY_CDN_HOST || null),
  };

  // R2 / S3 share the S3-compatible fields.
  const r2 = {
    accountId:       hasDb(row?.account_id)        ? row.account_id        : (process.env.R2_ACCOUNT_ID || null),
    accessKeyId:     hasDb(row?.access_key_id)     ? row.access_key_id     : (process.env.R2_ACCESS_KEY_ID || null),
    secretAccessKey: hasDb(row?.secret_access_key) ? row.secret_access_key : (process.env.R2_SECRET_ACCESS_KEY || null),
    bucket:          hasDb(row?.bucket)            ? row.bucket            : (process.env.R2_BUCKET || null),
    endpoint:        hasDb(row?.endpoint)          ? row.endpoint          : null,
    publicHost:      hasDb(row?.public_base_url)   ? row.public_base_url   : (process.env.R2_PUBLIC_HOST || null),
  };
  // Default the S3 endpoint when DB leaves it blank.
  if (!r2.endpoint && r2.accountId) {
    r2.endpoint = `https://${r2.accountId}.r2.cloudflarestorage.com`;
  }

  return { provider, source, bunny, r2, polsia, row };
}

module.exports = {
  getActiveConfig,
  getEffectiveProviderConfig,
  updateConfig,
  getEffectiveStreamConfig,
  getEffectiveStorageConfig,
  diffChangedKeys,
  UPDATABLE_FIELDS,
  VALID_PROVIDERS,
  SECRET_FIELDS,
  PLACEHOLDER,
};
