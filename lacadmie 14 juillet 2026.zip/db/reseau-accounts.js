// db/reseau-accounts.js
// Auth queries for the student network (reseau social) app.
// Shares DB with CRM — reads students table for adhesion verification.

/**
 * Find student by adherent number with active adhesion for current season.
 * @param {object} pool - pg Pool
 * @param {string} numeroAdherent
 * @returns {Promise<object|null>}
 */
async function findStudentByNumeroAdherent(pool, numeroAdherent) {
  const result = await pool.query(
    `SELECT id, first_name, last_name, email FROM students
     WHERE numero_adherent = $1 AND statut_adhesion = 'Payée'
       AND $2 = ANY(saisons)`,
    [numeroAdherent, '2025/2026']
  );
  return result.rows[0] || null;
}

/**
 * Find student by ID.
 * @param {object} pool
 * @param {number} eleveId
 */
async function findStudentById(pool, eleveId) {
  const result = await pool.query(
    `SELECT id, first_name, last_name, email FROM students WHERE id = $1`,
    [eleveId]
  );
  return result.rows[0] || null;
}

/**
 * Create a new reseau user.
 * @param {object} pool
 * @param {object} user - { email, passwordHash, nom, prenom, role, eleveId }
 */
async function createUser(pool, { email, passwordHash, nom, prenom, role, eleveId }) {
  const result = await pool.query(
    `INSERT INTO users_reseau (email, password_hash, nom, prenom, role, eleve_id)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id, email, nom, prenom, role, eleve_id`,
    [email, passwordHash, nom, prenom, role, eleveId]
  );
  return result.rows[0];
}

/**
 * Find reseau user by email.
 * @param {object} pool
 * @param {string} email
 */
async function findUserByEmail(pool, email) {
  const result = await pool.query(
    `SELECT id, email, password_hash, nom, prenom, role, eleve_id, last_login
     FROM users_reseau WHERE LOWER(email) = LOWER($1)`,
    [email]
  );
  return result.rows[0] || null;
}

/**
 * Find reseau user by ID.
 * @param {object} pool
 * @param {number} userId
 */
async function findUserById(pool, userId) {
  const result = await pool.query(
    `SELECT id, email, nom, prenom, role, eleve_id, last_login
     FROM users_reseau WHERE id = $1`,
    [userId]
  );
  return result.rows[0] || null;
}

/**
 * Update last_login timestamp for a user.
 * @param {object} pool
 * @param {number} userId
 */
async function updateLastLogin(pool, userId) {
  await pool.query(
    `UPDATE users_reseau SET last_login = NOW() WHERE id = $1`,
    [userId]
  );
}

/**
 * Create a new session token.
 * @param {object} pool
 * @param {number} userId
 * @param {string} token
 * @param {Date} expiresAt
 */
async function createSession(pool, userId, token, expiresAt) {
  await pool.query(
    `INSERT INTO reseau_sessions (user_id, token, expires_at) VALUES ($1, $2, $3)`,
    [userId, token, expiresAt]
  );
}

/**
 * Find valid session by token (not expired).
 * @param {object} pool
 * @param {string} token
 */
async function findValidSession(pool, token) {
  const result = await pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role, ur.eleve_id
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  );
  return result.rows[0] || null;
}

/**
 * Delete session by token.
 * @param {object} pool
 * @param {string} token
 */
async function deleteSession(pool, token) {
  await pool.query(`DELETE FROM reseau_sessions WHERE token = $1`, [token]);
}

/**
 * Delete all sessions for a user (logout all devices).
 * @param {object} pool
 * @param {number} userId
 */
async function deleteAllUserSessions(pool, userId) {
  await pool.query(`DELETE FROM reseau_sessions WHERE user_id = $1`, [userId]);
}

module.exports = {
  findStudentByNumeroAdherent,
  findStudentById,
  createUser,
  findUserByEmail,
  findUserById,
  updateLastLogin,
  createSession,
  findValidSession,
  deleteSession,
  deleteAllUserSessions,
};