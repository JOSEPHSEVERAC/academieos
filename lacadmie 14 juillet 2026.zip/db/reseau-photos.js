// db/reseau-photos.js
// Query functions for the reseau social photo gallery.
// Owns: reseau_photos table.

/**
 * Create a photo entry.
 * @param {object} pool
 * @param {object} photo - { uploaderId, uploaderRole, titre, lieu, evenementType, jour, imageUrl, isPrivate, privateEleveId, eventId, description, balletTitle, thumbnailUrl, thumbnailData }
 */
async function createPhoto(pool, { uploaderId, uploaderRole, titre, lieu, evenementType, jour, imageUrl, isPrivate, privateEleveId, eventId, description, balletTitle, thumbnailUrl, thumbnailData }) {
  const result = await pool.query(
    `INSERT INTO reseau_photos
       (uploader_id, uploader_role, titre, lieu, evenement_type, jour, image_url, is_private, private_eleve_id, event_id, description, ballet_title, thumbnail_url, thumbnail_data)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
     RETURNING *`,
    [uploaderId, uploaderRole, titre.trim(), lieu.trim(), evenementType.trim(), jour, imageUrl, isPrivate, privateEleveId || null, eventId || null, description || null, balletTitle || null, thumbnailUrl || null, thumbnailData || null]
  );
  return result.rows[0];
}

/**
 * Get photos visible to a user, with optional filters.
 * @param {object} pool
 * @param {object} opts - { userId, userRole, filterEvenementType, filterLieu, filterEventId }
 *   filterEventId: null = no filter, 0 = event_id IS NULL (hors événement), number = specific event
 */
async function getPhotos(pool, { userId, userRole, filterEvenementType, filterLieu, filterEventId }) {
  const isDirection = ['president', 'directrice', 'professeur'].includes(userRole);

  let params = [];
  let whereClauses = ['is_deleted = false'];

  if (!isDirection) {
    whereClauses.push(`(is_private = false OR (is_private = true AND private_eleve_id = $1))`);
    params.push(userId);
  }

  if (filterEvenementType) {
    params.push(filterEvenementType);
    whereClauses.push(`evenement_type = $${params.length}`);
  }
  if (filterLieu) {
    params.push(filterLieu);
    whereClauses.push(`lieu = $${params.length}`);
  }
  if (filterEventId !== null && filterEventId !== undefined) {
    if (filterEventId === 0) {
      whereClauses.push(`event_id IS NULL`);
    } else {
      params.push(filterEventId);
      whereClauses.push(`event_id = $${params.length}`);
    }
  }

  params.push(30); // limit
  const result = await pool.query(
    `SELECT rp.id, rp.titre, rp.lieu, rp.evenement_type, rp.jour, rp.image_url,
            rp.is_private, rp.private_eleve_id, rp.created_at,
            rp.uploader_id, rp.uploader_role,
            rp.event_id, rp.description, rp.ballet_title,
            rp.thumbnail_url, rp.thumbnail_data,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom
     FROM reseau_photos rp
     LEFT JOIN users_reseau u ON u.id = rp.uploader_id
     WHERE ${whereClauses.join(' AND ')}
     ORDER BY rp.ballet_title ASC NULLS LAST, rp.jour DESC NULLS LAST, rp.created_at DESC
     LIMIT $${params.length}`,
    params
  );
  return result.rows;
}

/**
 * Get a single photo by ID with visibility check.
 * Returns null if not visible to user.
 * @param {object} pool
 * @param {number} photoId
 * @param {object} opts - { userId, userRole }
 */
async function getPhotoById(pool, photoId, { userId, userRole }) {
  const isDirection = ['president', 'directrice', 'professeur'].includes(userRole);

  let params = [photoId];
  // Visibility: Direction sees all. Others see public photos + their own private portraits.
  // Note: private_eleve_id IS NULL for public photos, so we must use IS NOT DISTINCT FROM
  // instead of = to correctly match public photos (NULL = $X is always FALSE in SQL).
  let visibilityClause = isDirection
    ? `is_deleted = false AND rp.id = $1`
    : `is_deleted = false AND rp.id = $1 AND (is_private = false OR (is_private = true AND private_eleve_id IS NOT DISTINCT FROM $2))`;

  if (!isDirection) params.push(userId);

  const result = await pool.query(
    `SELECT rp.id, rp.titre, rp.lieu, rp.evenement_type, rp.jour, rp.image_url,
            rp.is_private, rp.private_eleve_id, rp.created_at,
            rp.uploader_id, rp.uploader_role,
            rp.event_id, rp.description, rp.ballet_title,
            rp.thumbnail_url, rp.thumbnail_data,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom
     FROM reseau_photos rp
     LEFT JOIN users_reseau u ON u.id = rp.uploader_id
     WHERE ${visibilityClause}`,
    params
  );
  return result.rows[0] || null;
}

/**
 * Delete a photo (soft-delete).
 * @param {object} pool
 * @param {number} photoId
 */
async function deletePhoto(pool, photoId) {
  await pool.query(`UPDATE reseau_photos SET is_deleted = true WHERE id = $1`, [photoId]);
}

/**
 * Update thumbnail columns for a photo (non-destructive, called after creation).
 * @param {object} pool
 * @param {number} photoId
 * @param {string|null} thumbnailUrl — R2 CDN URL or null
 * @param {Buffer|null} thumbnailData — bytea JPEG or null
 */
async function updatePhotoThumbnail(pool, photoId, thumbnailUrl, thumbnailData) {
  await pool.query(
    `UPDATE reseau_photos SET thumbnail_url = $2, thumbnail_data = $3 WHERE id = $1`,
    [photoId, thumbnailUrl || null, thumbnailData || null]
  );
}

/**
 * Get distinct evenement_type values for filter UI.
 * @param {object} pool
 */
async function getEvenementTypes(pool) {
  const result = await pool.query(
    `SELECT DISTINCT evenement_type FROM reseau_photos
     WHERE is_deleted = false AND evenement_type IS NOT NULL AND evenement_type != ''
     ORDER BY evenement_type`
  );
  return result.rows.map(r => r.evenement_type);
}

/**
 * Get distinct lieu values for filter UI.
 * @param {object} pool
 */
async function getLieux(pool) {
  const result = await pool.query(
    `SELECT DISTINCT lieu FROM reseau_photos
     WHERE is_deleted = false AND lieu IS NOT NULL AND lieu != ''
     ORDER BY lieu`
  );
  return result.rows.map(r => r.lieu);
}

/**
 * List all photos for admin management (no visibility filter — direction sees all).
 * @param {object} pool
 * @param {object} opts - { filterEvenementType, filterLieu, limit, offset }
 */
async function listPhotosAdmin(pool, { filterEvenementType, filterLieu, limit = 50, offset = 0 }) {
  let params = [];
  let whereClauses = ['is_deleted = false'];

  if (filterEvenementType) {
    params.push(filterEvenementType);
    whereClauses.push(`evenement_type = $${params.length}`);
  }
  if (filterLieu) {
    params.push(filterLieu);
    whereClauses.push(`lieu = $${params.length}`);
  }

  params.push(limit, offset);
  const result = await pool.query(
    `SELECT rp.id, rp.titre, rp.lieu, rp.evenement_type, rp.jour, rp.image_url,
            rp.is_private, rp.private_eleve_id, rp.created_at,
            rp.uploader_id, rp.uploader_role,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom,
            s.first_name AS eleve_first_name, s.last_name AS eleve_last_name
     FROM reseau_photos rp
     LEFT JOIN users_reseau u ON u.id = rp.uploader_id
     LEFT JOIN students s ON s.id = rp.private_eleve_id
     WHERE ${whereClauses.join(' AND ')}
     ORDER BY rp.created_at DESC
     LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  return result.rows;
}

/**
 * Count total photos for pagination.
 * @param {object} pool
 * @param {object} opts - { filterEvenementType, filterLieu }
 */
async function countPhotosAdmin(pool, { filterEvenementType, filterLieu }) {
  let params = [];
  let whereClauses = ['is_deleted = false'];
  if (filterEvenementType) {
    params.push(filterEvenementType);
    whereClauses.push(`evenement_type = $${params.length}`);
  }
  if (filterLieu) {
    params.push(filterLieu);
    whereClauses.push(`lieu = $${params.length}`);
  }
  const result = await pool.query(
    `SELECT COUNT(*) FROM reseau_photos WHERE ${whereClauses.join(' AND ')}`,
    params
  );
  return parseInt(result.rows[0].count, 10);
}

/**
 * Get a single photo by ID for admin (no visibility filter).
 * @param {object} pool
 * @param {number} photoId
 */
async function getPhotoByIdAdmin(pool, photoId) {
  const result = await pool.query(
    `SELECT rp.id, rp.titre, rp.lieu, rp.evenement_type, rp.jour, rp.image_url,
            rp.is_private, rp.private_eleve_id, rp.created_at,
            rp.uploader_id, rp.uploader_role,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom,
            s.first_name AS eleve_first_name, s.last_name AS eleve_last_name
     FROM reseau_photos rp
     LEFT JOIN users_reseau u ON u.id = rp.uploader_id
     LEFT JOIN students s ON s.id = rp.private_eleve_id
     WHERE rp.id = $1 AND rp.is_deleted = false`,
    [photoId]
  );
  return result.rows[0] || null;
}

/**
 * Search students by name or numero_adherent for the portrait autocomplete.
 * @param {object} pool
 * @param {string} query
 */
async function searchStudents(pool, query) {
  if (!query || query.trim().length < 2) return [];
  const q = '%' + query.trim() + '%';
  const result = await pool.query(
    `SELECT id, first_name, last_name, numero_adherent
     FROM students
     WHERE (first_name ILIKE $1 OR last_name ILIKE $1 OR numero_adherent ILIKE $1)
       AND active = true
     ORDER BY last_name, first_name
     LIMIT 10`,
    [q]
  );
  return result.rows;
}

module.exports = {
  createPhoto,
  getPhotos,
  getPhotoById,
  getPhotoByIdAdmin,
  deletePhoto,
  updatePhotoThumbnail,
  getEvenementTypes,
  getLieux,
  listPhotosAdmin,
  countPhotosAdmin,
  searchStudents,
};