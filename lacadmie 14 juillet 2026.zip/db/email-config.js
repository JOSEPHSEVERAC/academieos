// db/email-config.js
// Owns: read/write access to email_smtp_config — admin-managed SMTP creds
// (and provider switch) that replaces process.env.SMTP_* / RESEND_API_KEY for
// the runtime email path in services/email.js.
// Does NOT own: actual send (services/email.js), admin endpoint
// (routes/admin-email-config.js), per-recipient envelope (email_sender_config).

const SECRET_FIELDS = ['smtp_password'];
const UPDATABLE_FIELDS = [
  'provider',
  'smtp_host',
  'smtp_port',
  'smtp_secure',
  'smtp_user',
  'smtp_password',
  'from_address',
  'from_name',
];
const PLACEHOLDER = '••••••••';

const VALID_PROVIDERS = new Set(['resend', 'smtp', '']);

// 'resend' = default; 'smtp' = use the SMTP_* columns below.
// Empty string is allowed so the table can boot unconfigured and the admin
// later flips the switch.

function hasDb(v) {
  return v != null && v !== '';
}

/**
 * Read the single config row. Returns null when the table is empty
 * (cold start before migration ran — safe to handle defensively).
 */
async function getActiveConfig(pool) {
  const result = await pool.query(
    `SELECT id, provider, smtp_host, smtp_port, smtp_secure, smtp_user,
            smtp_password, from_address, from_name,
            updated_at, updated_by
       FROM email_smtp_config
      WHERE id = 1
      LIMIT 1`
  );
  return result.rows[0] || null;
}

/**
 * Return the config row with smtp_password masked unless `includeSecrets=true`.
 * Internal callers that need the real password should use
 * getEffectiveTransportConfig() directly.
 */
async function getEffectiveConfig(pool, { includeSecrets = false } = {}) {
  const row = await getActiveConfig(pool);
  if (!row) return null;
  if (includeSecrets) return row;
  const masked = { ...row };
  for (const f of SECRET_FIELDS) {
    if (hasDb(masked[f])) masked[f] = PLACEHOLDER;
  }
  return masked;
}

/**
 * Update the single config row. Empty-string fields are written as NULL so
 * cleared values don't sit around as placeholder whitespace.
 * Booleans and int fields are coerced before binding.
 */
async function updateConfig(pool, fields, userId) {
  const sets = [];
  const params = [];
  for (const key of UPDATABLE_FIELDS) {
    if (!Object.prototype.hasOwnProperty.call(fields, key)) continue;
    let value = fields[key];
    if (typeof value === 'string') value = value.trim();
    if (value === '') value = null;
    if (key === 'smtp_port' && value !== null && value !== undefined) {
      const n = Number(value);
      value = Number.isFinite(n) ? Math.trunc(n) : null;
    }
    if (key === 'smtp_secure' && value !== null && value !== undefined) {
      // Accept JS booleans or the strings 'true' / 'false'.
      if (typeof value === 'boolean') value = value;
      else if (value === 'true' || value === '1') value = true;
      else if (value === 'false' || value === '0') value = false;
      else value = null;
    }
    params.push(value);
    sets.push(`${key} = $${params.length}`);
  }
  if (sets.length === 0) {
    return getActiveConfig(pool);
  }
  params.push(userId || null);
  sets.push(`updated_by = $${params.length}`);
  sets.push(`updated_at = NOW()`);

  const result = await pool.query(
    `UPDATE email_smtp_config
        SET ${sets.join(', ')}
      WHERE id = 1
      RETURNING id, provider, smtp_host, smtp_port, smtp_secure, smtp_user,
                smtp_password, from_address, from_name,
                updated_at, updated_by`,
    params
  );
  return result.rows[0];
}

/**
 * Return the names of fields whose values actually changed after a write —
 * used by the route to populate the EMAIL_CONFIG_UPDATED audit metadata.
 * Secrets are compared by length only so their value never reaches the log.
 */
function diffChangedKeys(prev, next) {
  const changed = [];
  for (const f of UPDATABLE_FIELDS) {
    const a = prev ? (prev[f] == null ? '' : String(prev[f])) : '';
    const b = next ? (next[f] == null ? '' : String(next[f])) : '';
    if (SECRET_FIELDS.includes(f)) {
      if (a.length !== b.length) changed.push(f);
    } else if (a !== b) {
      changed.push(f);
    }
  }
  return changed;
}

/**
 * Resolve the effective transport config for a send. Returns explicit nulls
 * (not process.env) so the admin can swap providers without env churn.
 *
 * - provider: 'resend' | 'smtp' | '' (empty ⇒ resend default path)
 * - host/port/secure/user/password: only meaningful when provider === 'smtp'
 * - fromAddress / fromName: override Resend's from-selection at send time
 * - source: one of { 'db', 'partial-db', 'default' } for diagnostics
 */
async function getEffectiveTransportConfig(pool) {
  const row = await getActiveConfig(pool);
  const provider = hasDb(row?.provider) ? row.provider : 'resend';
  const fromAddress = hasDb(row?.from_address) ? row.from_address : null;
  const fromName = hasDb(row?.from_name) ? row.from_name : null;

  if (provider !== 'smtp') {
    return {
      provider,
      host: null,
      port: null,
      secure: null,
      user: null,
      password: null,
      fromAddress,
      fromName,
      source: 'default',
    };
  }

  const host = hasDb(row?.smtp_host) ? row.smtp_host : null;
  const port = row?.smtp_port != null ? Number(row.smtp_port) : null;
  const secure = row && typeof row.smtp_secure === 'boolean' ? row.smtp_secure : null;
  const user = hasDb(row?.smtp_user) ? row.smtp_user : null;
  const password = hasDb(row?.smtp_password) ? row.smtp_password : null;

  const knownFields = [host, port, user, password, secure].filter(v => v !== null && v !== '').length;
  let source = 'default';
  if (knownFields === 5) source = 'db';
  else if (knownFields > 0) source = 'partial-db';

  return {
    provider,
    host,
    port,
    secure,
    user,
    password,
    fromAddress,
    fromName,
    source,
  };
}

// Memoized SMTP transport cache lives in services/email.js so the
// transport-build concern stays next to the send path.

module.exports = {
  getActiveConfig,
  getEffectiveConfig,
  updateConfig,
  diffChangedKeys,
  getEffectiveTransportConfig,
  UPDATABLE_FIELDS,
  VALID_PROVIDERS,
  SECRET_FIELDS,
  PLACEHOLDER,
};
