// db/app-settings.js
// Owns: read/write access to app_settings — single-row table holding the
// app-wide toggles that the PRÉSIDENT manages from the CRM
// (two_factor_enabled, passwordless_magic_link_enabled,
// magic_link_ttl_hours, magic_link_template, two_factor_method).
// Does NOT own: per-user TOTP enrollment (app_users.totp_enabled),
// authentication flow logic (server.js), admin endpoints.

const UPDATABLE_FIELDS = [
  'two_factor_enabled',
  'passwordless_magic_link_enabled',
  'magic_link_ttl_hours',
  'magic_link_template',
  'two_factor_method',
];

// Bounds for magic_link_ttl_hours — mirrors the DB CHECK constraint so a
// bad value is rejected before it reaches the wire.
const MAGIC_LINK_TTL_MIN = 1;
const MAGIC_LINK_TTL_MAX = 168;

// Whitelist for two_factor_method — the DB CHECK constrains it to ('totp')
// today; this list keeps the JS layer aligned so a typo doesn't blow up the
// constraint and bounce the write.
const VALID_2FA_METHODS = new Set(['totp']);

function coerceMagicLinkTtlHours(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  if (!Number.isFinite(n) || !Number.isInteger(n)) return null;
  if (n < MAGIC_LINK_TTL_MIN || n > MAGIC_LINK_TTL_MAX) return null;
  return n;
}

async function getSettings(pool) {
  const result = await pool.query(
    `SELECT id, two_factor_enabled, passwordless_magic_link_enabled,
            magic_link_ttl_hours, magic_link_template, two_factor_method,
            updated_at, updated_by
       FROM app_settings
      WHERE id = 1
      LIMIT 1`
  );
  return result.rows[0] || null;
}

/**
 * Update one or more fields. Booleans are coerced from JS booleans or the
 * strings 'true'/'false'/'1'/'0'. magic_link_ttl_hours is bounds-checked
 * in JS (mirrors the DB CHECK). magic_link_template is trimmed and
 * stored as NULL when blank. two_factor_method is whitelisted before
 * binding so a typo cannot violate the constraint.
 *
 * Cache is invalidated automatically after a successful write so the
 * "admin flipped the switch" propagation is immediate.
 */
async function updateSettings(pool, fields, userId) {
  const sets = [];
  const params = [];
  for (const key of UPDATABLE_FIELDS) {
    if (!Object.prototype.hasOwnProperty.call(fields, key)) continue;
    let value = fields[key];

    if (key === 'two_factor_enabled' || key === 'passwordless_magic_link_enabled') {
      if (value === 'true' || value === '1') value = true;
      else if (value === 'false' || value === '0') value = false;
    } else if (key === 'magic_link_ttl_hours') {
      const n = coerceMagicLinkTtlHours(value);
      if (n === null) {
        // Throw so the route can map this to a 400 instead of silently
        // writing NULL — the DB would also reject 0/negative via CHECK.
        const err = new Error(`magic_link_ttl_hours doit être un entier entre ${MAGIC_LINK_TTL_MIN} et ${MAGIC_LINK_TTL_MAX}`);
        err.statusCode = 400;
        throw err;
      }
      value = n;
    } else if (key === 'magic_link_template') {
      if (typeof value === 'string') value = value.trim();
      if (value === '') value = null;
    } else if (key === 'two_factor_method') {
      if (typeof value === 'string') value = value.trim();
      if (!VALID_2FA_METHODS.has(value)) {
        const err = new Error(`two_factor_method invalide — valeurs acceptées: ${[...VALID_2FA_METHODS].join(', ')}`);
        err.statusCode = 400;
        throw err;
      }
    }

    params.push(value);
    sets.push(`${key} = $${params.length}`);
  }
  if (sets.length === 0) {
    return getSettings(pool);
  }
  params.push(userId || null);
  sets.push(`updated_by = $${params.length}`);
  sets.push(`updated_at = NOW()`);

  const result = await pool.query(
    `UPDATE app_settings
        SET ${sets.join(', ')}
      WHERE id = 1
      RETURNING id, two_factor_enabled, passwordless_magic_link_enabled,
                magic_link_ttl_hours, magic_link_template, two_factor_method,
                updated_at, updated_by`,
    params
  );
  // Force the next read to bypass the per-process cache so the admin sees
  // their own write immediately.
  invalidateSettingsCache();
  return result.rows[0];
}

// Per-process cache so a single login burst doesn't blast the DB. The login
// flow reads this once per request, so the cache TTL is short — keeps the
// "admin flipped the switch" propagation tight while still coalescing
// simultaneous reads behind one query.
const TTL_MS = 60_000;
let _cached = null;
let _cachedAt = 0;
let _cachedPool = null;

async function getEffectiveSettings(pool, { bypassCache = false } = {}) {
  if (!bypassCache && _cached && _cachedPool === pool && Date.now() - _cachedAt < TTL_MS) {
    return _cached;
  }
  const row = await getSettings(pool);
  _cached = row;
  _cachedAt = Date.now();
  _cachedPool = pool;
  return row;
}

function invalidateSettingsCache() {
  _cached = null;
  _cachedAt = 0;
  _cachedPool = null;
}

module.exports = {
  getSettings,
  updateSettings,
  getEffectiveSettings,
  invalidateSettingsCache,
  UPDATABLE_FIELDS,
  MAGIC_LINK_TTL_MIN,
  MAGIC_LINK_TTL_MAX,
  VALID_2FA_METHODS,
};
