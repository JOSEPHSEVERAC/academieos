// db/reseau-videos.js
// Query functions for the reseau social video gallery.
// Owns: reseau_videos table.

/**
 * Create a video entry.
 * @param {object} pool
 * @param {object} video - { uploaderId, uploaderRole, titre, lieu, evenementType, jour, videoUrl, typeMime, isPrivate, privateEleveId, eventId, description, balletTitle, thumbnailUrl, thumbnailData, cloudflareUid, streamPlaybackId }
 */
async function createVideo(pool, { uploaderId, uploaderRole, titre, lieu, evenementType, jour, videoUrl, typeMime, isPrivate, privateEleveId, eventId, description, balletTitle, thumbnailUrl, thumbnailData, cloudflareUid, streamPlaybackId }) {
  const result = await pool.query(
    `INSERT INTO reseau_videos
       (uploader_id, uploader_role, titre, lieu, evenement_type, jour, video_url, type_mime, is_private, private_eleve_id, event_id, description, ballet_title, thumbnail_url, thumbnail_data, cloudflare_uid, stream_playback_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
     RETURNING *`,
    [uploaderId, uploaderRole, titre.trim(), lieu.trim(), evenementType.trim(), jour, videoUrl, typeMime || 'video/mp4', isPrivate, privateEleveId || null, eventId || null, description || null, balletTitle || null, thumbnailUrl || null, thumbnailData || null, cloudflareUid || null, streamPlaybackId || null]
  );
  return result.rows[0];
}

/**
 * Finalize a Cloudflare Stream video row once the upload has completed.
 * Sets the thumbnail URL (Cloudflare-hosted) and persists the stream playback ID.
 *
 * @param {object} pool
 * @param {number} id
 * @param {object} opts - { cloudflareUid, streamPlaybackId, thumbnailUrl }
 */
async function finalizeStreamVideo(pool, id, { cloudflareUid, streamPlaybackId, thumbnailUrl }) {
  await pool.query(
    `UPDATE reseau_videos
       SET cloudflare_uid      = $2,
           stream_playback_id  = $3,
           thumbnail_url       = COALESCE($4, thumbnail_url)
     WHERE id = $1`,
    [id, cloudflareUid || null, streamPlaybackId || null, thumbnailUrl || null]
  );
}

/**
 * Get videos visible to a user, with optional filters.
 * @param {object} pool
 * @param {object} opts - { userId, userRole, filterEvenementType, filterLieu, filterEventId }
 *   filterEventId: null = no filter, 0 = event_id IS NULL (hors événement), number = specific event
 */
async function getVideos(pool, { userId, userRole, filterEvenementType, filterLieu, filterEventId }) {
  const isDirection = ['president', 'directrice', 'professeur'].includes(userRole);

  const params = [];
  const whereClauses = ['is_deleted = false'];

  if (!isDirection) {
    whereClauses.push(`(is_private = false OR (is_private = true AND private_eleve_id = $1))`);
    params.push(userId);
  }

  if (filterEvenementType) {
    params.push(filterEvenementType);
    whereClauses.push(`evenement_type = $${params.length}`);
  }
  if (filterLieu) {
    params.push(filterLieu);
    whereClauses.push(`lieu = $${params.length}`);
  }
  if (filterEventId !== null && filterEventId !== undefined) {
    if (filterEventId === 0) {
      whereClauses.push(`event_id IS NULL`);
    } else {
      params.push(filterEventId);
      whereClauses.push(`event_id = $${params.length}`);
    }
  }

  params.push(30);
  const result = await pool.query(
    `SELECT rv.id, rv.titre, rv.lieu, rv.evenement_type, rv.jour, rv.video_url,
            rv.type_mime, rv.is_private, rv.private_eleve_id, rv.created_at,
            rv.uploader_id, rv.uploader_role,
            rv.event_id, rv.description, rv.ballet_title,
            rv.thumbnail_url, rv.thumbnail_data,
            rv.cloudflare_uid, rv.stream_playback_id,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom
     FROM reseau_videos rv
     LEFT JOIN users_reseau u ON u.id = rv.uploader_id
     WHERE ${whereClauses.join(' AND ')}
     ORDER BY rv.ballet_title ASC NULLS LAST, rv.jour DESC NULLS LAST, rv.created_at DESC
     LIMIT $${params.length}`,
    params
  );
  return result.rows;
}

/**
 * Get a single video by ID with visibility check.
 * Returns null if not visible to user.
 * @param {object} pool
 * @param {number} videoId
 * @param {object} opts - { userId, userRole }
 */
async function getVideoById(pool, videoId, { userId, userRole }) {
  const isDirection = ['president', 'directrice', 'professeur'].includes(userRole);

  const params = [videoId];
  const visibilityClause = isDirection
    ? `is_deleted = false AND rv.id = $1`
    : `is_deleted = false AND rv.id = $1 AND (is_private = false OR (is_private = true AND private_eleve_id = $2))`;

  if (!isDirection) params.push(userId);

  const result = await pool.query(
    `SELECT rv.id, rv.titre, rv.lieu, rv.evenement_type, rv.jour, rv.video_url,
            rv.type_mime, rv.is_private, rv.private_eleve_id, rv.created_at,
            rv.uploader_id, rv.uploader_role,
            rv.event_id, rv.description, rv.ballet_title,
            rv.thumbnail_url, rv.thumbnail_data,
            rv.cloudflare_uid, rv.stream_playback_id,
            u.nom AS uploader_nom, u.prenom AS uploader_prenom
     FROM reseau_videos rv
     LEFT JOIN users_reseau u ON u.id = rv.uploader_id
     WHERE ${visibilityClause}`,
    params
  );
  return result.rows[0] || null;
}

/**
 * Delete a video (soft-delete).
 * @param {object} pool
 * @param {number} videoId
 */
async function deleteVideo(pool, videoId) {
  await pool.query(`UPDATE reseau_videos SET is_deleted = true WHERE id = $1`, [videoId]);
}

/**
 * Get distinct evenement_type values for filter UI.
 * @param {object} pool
 */
async function getEvenementTypes(pool) {
  const result = await pool.query(
    `SELECT DISTINCT evenement_type FROM reseau_videos
     WHERE is_deleted = false AND evenement_type IS NOT NULL AND evenement_type != ''
     ORDER BY evenement_type`
  );
  return result.rows.map(r => r.evenement_type);
}

/**
 * Get distinct lieu values for filter UI.
 * @param {object} pool
 */
async function getLieux(pool) {
  const result = await pool.query(
    `SELECT DISTINCT lieu FROM reseau_videos
     WHERE is_deleted = false AND lieu IS NOT NULL AND lieu != ''
     ORDER BY lieu`
  );
  return result.rows.map(r => r.lieu);
}

/**
 * Search students by name or numero_adherent for the portrait autocomplete.
 * @param {object} pool
 * @param {string} query
 */
async function searchStudents(pool, query) {
  if (!query || query.trim().length < 2) return [];
  const q = '%' + query.trim() + '%';
  const result = await pool.query(
    `SELECT id, first_name, last_name, numero_adherent
     FROM students
     WHERE (first_name ILIKE $1 OR last_name ILIKE $1 OR numero_adherent ILIKE $1)
       AND active = true
     ORDER BY last_name, first_name
     LIMIT 10`,
    [q]
  );
  return result.rows;
}

module.exports = {
  createVideo,
  finalizeStreamVideo,
  getVideos,
  getVideoById,
  deleteVideo,
  getEvenementTypes,
  getLieux,
  searchStudents,
};