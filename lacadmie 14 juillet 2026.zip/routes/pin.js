// routes/pin.js
// Tablet PIN authentication and PIN management for the /appel PWA.
// Does NOT own: CRM user auth, session management.
module.exports = function createPinRouter({ pool, requireAuth, logAudit }) {
  const router = require('express').Router();

  // POST /api/pin/auth — authenticate with a PIN code, issue tablet session
  router.post('/auth', async (req, res) => {
    try {
      const { pin_id, pin_code } = req.body;
      if (!pin_id || !pin_code) return res.status(400).json({ error: 'pin_id et pin_code requis' });

      const pinResult = await pool.query(
        'SELECT * FROM tablet_pins WHERE id = $1 AND active = true',
        [pin_id]
      );
      if (pinResult.rows.length === 0) return res.status(404).json({ error: 'PIN introuvable' });
      const pin = pinResult.rows[0];

      const valid = await require('bcryptjs').compare(pin_code, pin.pin_hash);
      if (!valid) return res.status(401).json({ error: 'Code PIN incorrect' });

      const token = require('crypto').randomBytes(32).toString('hex');
      const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');

      await pool.query(
        `INSERT INTO tablet_sessions (pin_id, token_hash, expires_at)
         VALUES ($1, $2, NOW() + INTERVAL '30 days')`,
        [pin_id, tokenHash]
      );

      res.json({ token, pin_label: pin.label });
    } catch (err) {
      console.error('[pin/auth] Error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/pin/verify — verify a tablet session token
  router.get('/verify', async (req, res) => {
    try {
      const token = req.headers.authorization?.startsWith('Bearer ')
        ? req.headers.authorization.slice(7) : null;
      if (!token) return res.status(401).json({ valid: false });
      const hash = require('crypto').createHash('sha256').update(token).digest('hex');
      const result = await pool.query(
        `SELECT ts.id FROM tablet_sessions ts
         JOIN tablet_pins tp ON tp.id = ts.pin_id
         WHERE ts.token_hash = $1 AND ts.expires_at > NOW() AND tp.active = true`,
        [hash]
      );
      res.json({ valid: result.rows.length > 0 });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/admin/pins — list all PINs (PRÉSIDENT only)
  router.get('/admin/pins', requireAuth(['PRÉSIDENT']), async (_req, res) => {
    try {
      const result = await pool.query(
        'SELECT id, label, active, created_at, revoked_at FROM tablet_pins ORDER BY created_at DESC'
      );
      res.json(result.rows);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/admin/pins — create a new PIN (PRÉSIDENT only)
  router.post('/admin/pins', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const { label, pin_code } = req.body;
      if (!label || !pin_code) return res.status(400).json({ error: 'label et pin_code requis' });
      const pinHash = await require('bcryptjs').hash(pin_code, 10);
      const result = await pool.query(
        'INSERT INTO tablet_pins (label, pin_hash) VALUES ($1, $2) RETURNING id, label, active, created_at',
        [label, pinHash]
      );
      await logAudit(req.user.id, req.user.email, req.user.role, 'CREATE_TABLET_PIN', 'tablet_pins', result.rows[0].id, { label }, req.ip);
      res.status(201).json(result.rows[0]);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/admin/pins/:id — revoke a PIN (PRÉSIDENT only)
  router.delete('/admin/pins/:id', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const { id } = req.params;
      const result = await pool.query(
        'UPDATE tablet_pins SET active = false, revoked_at = NOW() WHERE id = $1 AND active = true RETURNING id, label',
        [id]
      );
      if (result.rows.length === 0) return res.status(404).json({ error: 'PIN introuvable ou déjà révoqué' });
      await pool.query('DELETE FROM tablet_sessions WHERE pin_id = $1', [id]);
      await logAudit(req.user.id, req.user.email, req.user.role, 'REVOKE_TABLET_PIN', 'tablet_pins', id, { label: result.rows[0].label }, req.ip);
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
};