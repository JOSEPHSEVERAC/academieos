// routes/reseau-events.js
// Owns: events gallery CRUD — container model for grouping photos/videos by occasion.
// Does NOT own: standalone photo/video galleries (reseau-photos.js, reseau-videos.js), auth (reseau-auth.js).

const ev = require('../db/events');
const storage = require('../services/storage');
const { uploadFile, uploadVideoToR2, isConfigured } = require('../services/r2');

// ── Middleware: require valid reseau session ──────────────────────────────────
function requireReseauAuth(pool, req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization' });
  }
  const token = authHeader.slice(7);
  pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(result => {
    if (!result.rows[0]) {
      return res.status(401).json({ error: 'Session expired or invalid' });
    }
    const row = result.rows[0];
    req.sessionUser = {
      id: row.user_id,
      sessionId: row.session_id,
      email: row.email,
      nom: row.nom,
      prenom: row.prenom,
      role: row.role,
    };
    next();
  }).catch(err => {
    console.error('Reseau events session error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });
}

function requireDirection(req, res, next) {
  if (!['president', 'directrice', 'professeur'].includes(req.sessionUser.role)) {
    return res.status(403).json({ error: 'Action réservée à la direction' });
  }
  next();
}

const VALID_EVENT_TYPES = ['spectacle', 'competition', 'repetition', 'soiree', 'atelier', 'sortie', 'autre'];
function isR2Url(url) {
  return !!(url && url.startsWith(storage.publicHost()));
}

/**
 * Upload base64 file_data to R2 proxy and return the public URL.
 * @param {string} file_data   — base64 data URL (data:image/...;base64,...)
 * @param {string} subdir     — R2 subdirectory
 * @param {string} mimeType   — MIME type
 * @returns {Promise<string>} public R2 URL
 */
async function uploadBase64ToR2(file_data, subdir, mimeType) {
  const ext = mimeType === 'image/png' ? 'png'
    : mimeType === 'video/mp4' ? 'mp4'
    : mimeType === 'video/webm' ? 'webm'
    : 'jpg';
  const rawBase64 = file_data.replace(/^data:[^;]+;base64,/, '');
  return uploadFile(rawBase64, subdir, `file.${ext}`, mimeType);
}

module.exports = function createReseauEventsRouter({ pool }) {
  const router = require('express').Router();

  router.use((req, res, next) => requireReseauAuth(pool, req, res, next));

  // ── GET /reseau/api/events — list all events ──────────────────────────────
  router.get('/', async (req, res) => {
    try {
      const events = await ev.listEvents(pool, {
        filterType: req.query.type || null,
        sort: req.query.sort || 'recent',
      });
      res.json({ events });
    } catch (err) {
      console.error('GET /reseau/api/events error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/events/types — available event types for filter ───────
  router.get('/types', async (req, res) => {
    try {
      const types = await ev.getEventTypes(pool);
      res.json({ types });
    } catch (err) {
      console.error('GET /reseau/api/events/types error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/events — create event (direction only) ───────────────
  router.post('/', requireDirection, async (req, res) => {
    try {
      const { title, location, event_date, event_type, description, cover_image } = req.body;

      if (!title || !title.trim()) {
        return res.status(400).json({ error: 'Titre requis' });
      }
      if (!event_date) {
        return res.status(400).json({ error: 'Date requise' });
      }
      if (event_type && !VALID_EVENT_TYPES.includes(event_type)) {
        return res.status(400).json({ error: "Type d'événement invalide" });
      }
      if (cover_image && cover_image.length > 8 * 1024 * 1024) {
        return res.status(400).json({ error: 'Image de couverture trop volumineuse (max 8 Mo)' });
      }

      let coverImageUrl = null;
      if (cover_image) {
        if (isR2Url(cover_image)) {
          coverImageUrl = cover_image;
        } else if (cover_image.startsWith('data:')) {
          if (!isConfigured()) {
            return res.status(503).json({ error: 'Stockage non configuré — contactez le support.' });
          }
          const mimeMatch = cover_image.match(/^data:([^;]+);/);
          const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
          try {
            coverImageUrl = await uploadBase64ToR2(cover_image, 'event-covers', mimeType);
          } catch (r2Err) {
            console.warn('[reseau-events] R2 upload failed, storing as base64 in DB:', r2Err.message);
            // Platform bug: POLSIA_API_KEY rejected by image proxy (401 for all auth formats).
            coverImageUrl = cover_image; // store data URI directly
          }
        }
      }

      const event = await ev.createEvent(pool, {
        title: title.trim(),
        location: (location || '').trim(),
        eventDate: event_date,
        eventType: event_type || 'autre',
        description: (description || '').trim(),
        coverImage: coverImageUrl,
        createdBy: req.sessionUser.id,
      });

      res.status(201).json(event);
    } catch (err) {
      console.error('POST /reseau/api/events error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/events/:id — event detail + media ─────────────────────
  router.get('/:id', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const event = await ev.getEventById(pool, eventId);
      if (!event) return res.status(404).json({ error: 'Événement introuvable' });

      const media = await ev.listEventMedia(pool, eventId);

      res.json({ event, media });
    } catch (err) {
      console.error('GET /reseau/api/events/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── PUT /reseau/api/events/:id — update event (direction only) ────────────
  router.put('/:id', requireDirection, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const { title, location, event_date, event_type, description, cover_image } = req.body;

      if (event_type && !VALID_EVENT_TYPES.includes(event_type)) {
        return res.status(400).json({ error: "Type d'événement invalide" });
      }

      let coverImageUrl;
      if (cover_image !== undefined) {
        if (cover_image === null || cover_image === '') {
          coverImageUrl = null;
        } else if (isR2Url(cover_image)) {
          coverImageUrl = cover_image;
        } else if (cover_image.startsWith('data:')) {
          if (!isConfigured()) {
            return res.status(503).json({ error: 'Stockage non configuré — contactez le support.' });
          }
          const mimeMatch = cover_image.match(/^data:([^;]+);/);
          const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
          try {
            coverImageUrl = await uploadBase64ToR2(cover_image, 'event-covers', mimeType);
          } catch (r2Err) {
            console.warn('[reseau-events] R2 upload failed, storing as base64 in DB:', r2Err.message);
            // Platform bug: POLSIA_API_KEY rejected by image proxy (401 for all auth formats).
            coverImageUrl = cover_image;
          }
        } else {
          coverImageUrl = undefined;
        }
      } else {
        coverImageUrl = undefined;
      }

      const updated = await ev.updateEvent(pool, eventId, {
        title: title ? title.trim() : undefined,
        location: location !== undefined ? (location || '').trim() : undefined,
        eventDate: event_date || undefined,
        eventType: event_type || undefined,
        description: description !== undefined ? (description || '').trim() : undefined,
        coverImage: coverImageUrl,
      });

      if (!updated) return res.status(404).json({ error: 'Événement introuvable' });
      res.json(updated);
    } catch (err) {
      console.error('PUT /reseau/api/events/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── DELETE /reseau/api/events/:id — delete event + all media (direction) ──
  router.delete('/:id', requireDirection, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      await ev.deleteEvent(pool, eventId);
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /reseau/api/events/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/events/:id/media — upload media to event (direction) ─
  router.post('/:id/media', requireDirection, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const event = await ev.getEventById(pool, eventId);
      if (!event) return res.status(404).json({ error: 'Événement introuvable' });

      const { file_data, file_type, original_name } = req.body;

      if (!file_data || !file_data.trim()) {
        return res.status(400).json({ error: 'Fichier requis' });
      }

      const resolvedType = file_type === 'video' ? 'video' : 'photo';

      // Validate format
      if (resolvedType === 'photo' && !file_data.startsWith('data:image/')) {
        return res.status(400).json({ error: 'Format image invalide' });
      }
      if (resolvedType === 'video' && !file_data.startsWith('data:video/')) {
        return res.status(400).json({ error: 'Format vidéo invalide' });
      }

      const maxSize = resolvedType === 'video' ? 500 * 1024 * 1024 : 8 * 1024 * 1024;
      if (file_data.length > maxSize) {
        const label = resolvedType === 'video' ? '500 Mo' : '8 Mo';
        return res.status(400).json({ error: `Fichier trop volumineux (max ${label})` });
      }

      const mimeMatch = file_data.match(/^data:([^;]+);/);
      const typeMime = mimeMatch ? mimeMatch[1] : (resolvedType === 'video' ? 'video/mp4' : 'image/jpeg');

      // Already an R2 URL?
      if (isR2Url(file_data)) {
        const media = await ev.addEventMedia(pool, {
          eventId,
          fileUrl: file_data,
          fileType: resolvedType,
          typeMime,
          originalName: (original_name || '').trim(),
          uploadedBy: req.sessionUser.id,
        });
        return res.status(201).json(media);
      }

      if (!isConfigured()) {
        return res.status(503).json({ error: 'Stockage non configuré — contactez le support.' });
      }

      let fileUrl;
      try {
        if (resolvedType === 'video') {
          const ext = typeMime === 'video/webm' ? 'webm' : 'mp4';
          const rawBase64 = file_data.replace(/^data:[^;]+;base64,/, '');
          fileUrl = await uploadVideoToR2(rawBase64, `video.${ext}`, typeMime);
        } else {
          fileUrl = await uploadBase64ToR2(file_data, 'event-media', typeMime);
        }
        console.log(`[reseau-events] Uploaded ${resolvedType} to R2 → ${fileUrl}`);
      } catch (r2Err) {
        console.warn('[reseau-events] R2 upload failed, storing as base64 in DB:', r2Err.message);
        // Platform bug: POLSIA_API_KEY rejected by image proxy (401 for all auth formats).
        fileUrl = file_data; // store data URI directly
      }

      const media = await ev.addEventMedia(pool, {
        eventId,
        fileUrl,
        fileType: resolvedType,
        typeMime,
        originalName: (original_name || '').trim(),
        uploadedBy: req.sessionUser.id,
      });

      res.status(201).json(media);
    } catch (err) {
      console.error('POST /reseau/api/events/:id/media error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/events/:id/media — list media for event ───────────────
  router.get('/:id/media', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const media = await ev.listEventMedia(pool, eventId);
      res.json({ media });
    } catch (err) {
      console.error('GET /reseau/api/events/:id/media error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/events/:eventId/media/:mediaId/file — full file data ──
  router.get('/:eventId/media/:mediaId/file', async (req, res) => {
    try {
      const mediaId = parseInt(req.params.mediaId, 10);
      if (isNaN(mediaId)) return res.status(400).json({ error: 'ID invalide' });

      const media = await ev.getMediaById(pool, mediaId);
      if (!media || !media.file_url) return res.status(404).json({ error: 'Média introuvable' });

      // R2 URL → return direct URL (browser loads from R2)
      if (isR2Url(media.file_url)) {
        return res.json({ url: media.file_url, file_type: media.file_type, type_mime: media.type_mime });
      }
      // Legacy base64 → return as data URI
      res.json({ file_data: media.file_url, file_type: media.file_type, type_mime: media.type_mime });
    } catch (err) {
      console.error('GET /reseau/api/events/:eventId/media/:mediaId/file error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── DELETE /reseau/api/events/:eventId/media/:mediaId — delete media ──────
  router.delete('/:eventId/media/:mediaId', requireDirection, async (req, res) => {
    try {
      const mediaId = parseInt(req.params.mediaId, 10);
      if (isNaN(mediaId)) return res.status(400).json({ error: 'ID invalide' });

      await ev.deleteMedia(pool, mediaId);
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /reseau/api/events/:eventId/media/:mediaId error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};