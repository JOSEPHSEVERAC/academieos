// routes/admin-sender-config.js
// Owns: PRÉSIDENT-facing admin endpoint to flip the transactional sender
// between Resend-verified aliases (contact@lacademie.art / gregory@lacademie.art)
// without redeploying.
//
// Does NOT own: email composition (services/email.js), Resend wiring
// (services/resend.js), sender-row seeding (migrations/2010…).

module.exports = function createAdminSenderConfigRouter({ pool, requireAuth, logAudit }) {
  const router = require('express').Router();
  const { ALLOWED_FROM_DOMAINS, ALLOWED_FROM_ADDRESSES } = require('../services/resend');

  // GET /api/admin/email-sender — current sender row (PRESIDENT only)
  router.get('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT id, sender_email, sender_name, updated_at, updated_by
           FROM email_sender_config ORDER BY id LIMIT 1`
      );
      res.json(result.rows[0] || null);
    } catch (err) {
      console.error('[admin-sender-config] GET error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/email-sender — flip sender row (PRESIDENT only)
  // Reject anything outside ALLOWED_FROM_* so the failure surfaces in the UI
  // before Resend returns its opaque "address not verified" error.
  router.put('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const { sender_email, sender_name } = req.body || {};
      if (!sender_email || typeof sender_email !== 'string') {
        return res.status(400).json({ error: 'sender_email requis' });
      }
      if (typeof sender_name !== 'string' || sender_name.trim().length === 0) {
        return res.status(400).json({ error: 'sender_name requis' });
      }
      const normalized = sender_email.trim().toLowerCase();
      const domain = normalized.split('@')[1] || '';
      if (!ALLOWED_FROM_DOMAINS.includes(domain)) {
        return res.status(400).json({
          error: `Domaine « ${domain} » non autorisé — seuls ${ALLOWED_FROM_DOMAINS.join(', ')} sont acceptés`,
        });
      }
      if (!ALLOWED_FROM_ADDRESSES.includes(normalized)) {
        return res.status(400).json({
          error: `Adresse « ${normalized} » non autorisée — vérifiez le tableau Resend (uniquement ${ALLOWED_FROM_ADDRESSES.join(', ')})`,
        });
      }

      const updated = await pool.query(
        `UPDATE email_sender_config
            SET sender_email = $1,
                sender_name  = $2,
                updated_at   = NOW(),
                updated_by   = $3
          WHERE id = 1
          RETURNING id, sender_email, sender_name, updated_at, updated_by`,
        [normalized, sender_name.trim(), req.user.id]
      );

      if (logAudit) {
        await logAudit(req.user.id, req.user.email, req.user.role, 'EMAIL_SENDER_UPDATED',
          'email_sender_config', updated.rows[0]?.id || 1,
          { new_sender: normalized, new_name: sender_name.trim() }, req.ip);
      }

      res.json(updated.rows[0]);
    } catch (err) {
      console.error('[admin-sender-config] PUT error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};
