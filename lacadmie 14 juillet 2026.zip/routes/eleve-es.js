// routes/eleve-es.js
// Public page: /eleve-es — photo gallery of academy students by discipline.
// No auth required. Serves static page + data API.
// Does NOT own: authenticated routes, student CRUD (admin-eleves.js), photo uploads (admin-photos.js).
module.exports = function createEleveEsRouter({ pool, rootDir }) {
  const router = require('express').Router();
  const path = require('path');

  // GET /eleve-es — serve the public page
  router.get('/', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'eleve-es.html'));
  });

  // GET /api/eleve-es/students — list active students with image rights
  // Returns students grouped by discipline for the gallery
  router.get('/students', async (_req, res) => {
    try {
      const result = await pool.query(`
        SELECT
          s.id,
          s.first_name,
          s.last_name,
          s.sexe,
          s.level,
          s.disciplines,
          s.formule,
          s.active,
          s.droit_image,
          ss.nombre_inscrits
        FROM (
          SELECT
            s.*,
            (SELECT COUNT(*) FROM student_saisons ss WHERE ss.student_id = s.id) as nombre_inscrits
          FROM students s
          WHERE s.active = true AND s.droit_image = true
        ) s
        LEFT JOIN LATERAL (
          SELECT 1 as num
          FROM student_saisons ss2
          JOIN saisons sa ON ss2.saison_id = sa.id
          WHERE sa.statut = 'active' AND ss2.student_id = s.id
          LIMIT 1
        ) ss ON true
        ORDER BY s.last_name, s.first_name
      `);
      res.json(result.rows);
    } catch (err) {
      console.error('[eleve-es/students] Error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/eleve-es/disciplines — list disciplines with student counts for filter tabs
  router.get('/disciplines', async (_req, res) => {
    try {
      // Extract unique discipline names from all active students with image rights
      const result = await pool.query(`
        SELECT DISTINCT d.name, COUNT(*) OVER (PARTITION BY d.name) as student_count
        FROM students s, jsonb_array_elements_text(s.disciplines) AS disc(name)
        JOIN disciplines d ON d.name = disc
        WHERE s.active = true AND s.droit_image = true
        ORDER BY d.name
      `);
      res.json(result.rows);
    } catch (err) {
      console.error('[eleve-es/disciplines] Error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/eleve-es/stats — aggregate stats for the page header
  router.get('/stats', async (_req, res) => {
    try {
      const [total, withPhoto, activeSaison] = await Promise.all([
        pool.query("SELECT COUNT(*) as count FROM students WHERE active = true AND droit_image = true"),
        pool.query("SELECT COUNT(*) as count FROM students WHERE active = true AND droit_image = true"),
        pool.query(`
          SELECT COUNT(DISTINCT ss.student_id) as count
          FROM student_saisons ss
          JOIN saisons s ON ss.saison_id = s.id
          WHERE s.statut = 'active'
        `),
      ]);
      res.json({
        total_eleves: parseInt(total.rows[0]?.count || 0),
        with_photo: parseInt(withPhoto.rows[0]?.count || 0),
        active_saison: parseInt(activeSaison.rows[0]?.count || 0),
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
};