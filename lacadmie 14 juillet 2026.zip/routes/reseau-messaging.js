// routes/reseau-messaging.js
// Owns: reseau social direct messaging — conversations, messages, read receipts.
// Does NOT own: auth (reseau-auth.js), feed (reseau-feed.js).
// Access: all authenticated reseau users. Direction (president/directrice) sees all.

const rm = require('../db/reseau-messaging');

function requireReseauAuth(pool, req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization' });
  }
  const token = authHeader.slice(7);
  pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(result => {
    if (!result.rows[0]) {
      return res.status(401).json({ error: 'Session expired or invalid' });
    }
    const row = result.rows[0];
    req.sessionUser = {
      id: row.user_id,
      sessionId: row.session_id,
      email: row.email,
      nom: row.nom,
      prenom: row.prenom,
      role: row.role,
    };
    next();
  }).catch(err => {
    console.error('Reseau messaging session error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });
}

module.exports = function createReseauMessagingRouter({ pool }) {
  const router = require('express').Router();
  router.use((req, res, next) => requireReseauAuth(pool, req, res, next));

  // ── GET /reseau/api/messaging/conversations ──────────────────────────────────
  // List all conversations for the current user (direction sees all).
  router.get('/conversations', async (req, res) => {
    try {
      const conversations = await rm.listConversations(pool, req.sessionUser.id, req.sessionUser.role);
      res.json(conversations);
    } catch (err) {
      console.error('GET /conversations error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/messaging/conversations/:id ───────────────────────────────
  // Get a single conversation with participants.
  router.get('/conversations/:id', async (req, res) => {
    try {
      const convId = parseInt(req.params.id, 10);
      if (isNaN(convId)) return res.status(400).json({ error: 'ID invalide' });

      const conv = await rm.getConversation(pool, convId, req.sessionUser.id, req.sessionUser.role);
      if (!conv) return res.status(404).json({ error: 'Conversation introuvable' });

      res.json(conv);
    } catch (err) {
      console.error('GET /conversations/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/messaging/conversations/:id/messages ─────────────────────
  // Get messages for a conversation. Supports pagination via ?before=id.
  router.get('/conversations/:id/messages', async (req, res) => {
    try {
      const convId = parseInt(req.params.id, 10);
      if (isNaN(convId)) return res.status(400).json({ error: 'ID invalide' });

      const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
      const beforeId = req.query.before ? parseInt(req.query.before, 10) : null;

      const messages = await rm.getMessages(pool, convId, req.sessionUser.id, req.sessionUser.role, {
        limit,
        beforeId,
        reversed: true, // chronological for display
      });

      res.json(messages);
    } catch (err) {
      console.error('GET /conversations/:id/messages error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/messaging/conversations/:id/messages ────────────────────
  // Send a message.
  router.post('/conversations/:id/messages', async (req, res) => {
    try {
      const convId = parseInt(req.params.id, 10);
      if (isNaN(convId)) return res.status(400).json({ error: 'ID invalide' });

      const { content } = req.body;
      if (!content || !content.trim()) return res.status(400).json({ error: 'Message vide' });

      if (content.trim().length > 1000) return res.status(400).json({ error: 'Message limité à 1000 caractères' });

      // Verify access (createConversation does this, but for direct send we also check)
      const conv = await rm.getConversation(pool, convId, req.sessionUser.id, req.sessionUser.role);
      if (!conv) return res.status(403).json({ error: 'Accès non autorisé' });

      const message = await rm.sendMessage(pool, convId, req.sessionUser.id, content.trim());

      // Fetch sender info for response
      const senderRow = await pool.query(
        `SELECT nom, prenom, role FROM users_reseau WHERE id = $1`,
        [req.sessionUser.id]
      );
      const sender = senderRow.rows[0];

      res.status(201).json({
        id: message.id,
        conversation_id: message.conversation_id,
        sender_id: message.sender_id,
        content: message.content,
        sent_at: message.sent_at,
        sender_nom: sender.nom,
        sender_prenom: sender.prenom,
        sender_role: sender.role,
      });
    } catch (err) {
      console.error('POST /conversations/:id/messages error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/messaging/conversations ─────────────────────────────────
  // Start a new DM conversation. Reuses existing if one exists between the two users.
  router.post('/conversations', async (req, res) => {
    try {
      const { user_id, content } = req.body;

      if (!user_id) return res.status(400).json({ error: 'Destinataire requis' });

      const recipientId = parseInt(user_id, 10);
      if (isNaN(recipientId)) return res.status(400).json({ error: 'ID destinataire invalide' });

      if (recipientId === req.sessionUser.id) {
        return res.status(400).json({ error: 'Impossible de se écrire à soi-même' });
      }

      // Check if recipient exists
      const recipientRow = await pool.query(`SELECT id FROM users_reseau WHERE id = $1`, [recipientId]);
      if (!recipientRow.rows.length) return res.status(404).json({ error: 'Utilisateur introuvable' });

      // Check for existing 1-on-1 conversation between these two users
      const existing = await pool.query(
        `SELECT rc.id FROM reseau_conversations rc
         WHERE (
           SELECT COUNT(*) FROM reseau_conversation_participants rcp
           WHERE rcp.conversation_id = rc.id AND rcp.user_id IN ($1, $2)
         ) = 2`,
        [req.sessionUser.id, recipientId]
      );

      let conv;
      if (existing.rows.length > 0) {
        conv = existing.rows[0];
        // If initial_message provided and there's an existing conversation, send the message
        if (content && content.trim()) {
          const msgResult = await pool.query(
            `INSERT INTO reseau_messages (conversation_id, sender_id, content)
             VALUES ($1, $2, $3) RETURNING *`,
            [conv.id, req.sessionUser.id, content.trim()]
          );
          await pool.query(
            `UPDATE reseau_conversations SET updated_at = NOW() WHERE id = $1`,
            [conv.id]
          );
        }
      } else {
        conv = await rm.createConversation(pool, req.sessionUser.id, recipientId, content);
      }

      res.status(201).json({ id: conv.id, created_at: conv.created_at });
    } catch (err) {
      console.error('POST /conversations error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/messaging/members ───────────────────────────────────────
  // Get all members for starting a new conversation.
  router.get('/members', async (req, res) => {
    try {
      const members = await rm.getMembers(pool, req.sessionUser.id);
      res.json(members);
    } catch (err) {
      console.error('GET /members error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};