// routes/public-api.js
// Public read-only data endpoints (no auth required).
// Does NOT own: authenticated routes, mutations, auth logic.
// Extracted from server.js (was: lines 1209-1328+)

module.exports = function createPublicApiRouter({ pool }) {
  const router = require('express').Router();

  // GET /api/disciplines — list all disciplines
  router.get('/disciplines', async (_req, res) => {
    try {
      const result = await pool.query('SELECT * FROM disciplines ORDER BY name');
      res.json(result.rows);
    } catch (err) {
      console.error('Error fetching disciplines:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/locations — list all locations
  router.get('/locations', async (_req, res) => {
    try {
      const result = await pool.query('SELECT * FROM locations ORDER BY name');
      res.json(result.rows);
    } catch (err) {
      console.error('Error fetching locations:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/formulas — list all active formulas
  router.get('/formulas', async (_req, res) => {
    try {
      const result = await pool.query(
        'SELECT * FROM formulas WHERE actif = true ORDER BY prix_mensuel_cents ASC'
      );
      res.json(result.rows);
    } catch (err) {
      console.error('Error fetching formulas:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/formulas — create formula (admin-initiated on first setup)
  router.post('/formulas', async (req, res) => {
    try {
      const { name, description, prix_mensuel_cents, duree_mois, nombre_seances, actif } = req.body;
      if (!name || !prix_mensuel_cents) {
        return res.status(400).json({ error: 'name et prix_mensuel_cents requis' });
      }
      const result = await pool.query(
        `INSERT INTO formulas (name, description, prix_mensuel_cents, duree_mois, nombre_seances, actif)
         VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
        [name, description || null, prix_mensuel_cents, duree_mois || null, nombre_seances || null, actif !== false]
      );
      res.status(201).json(result.rows[0]);
    } catch (err) {
      console.error('Error creating formula:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/formulas/:id
  router.delete('/formulas/:id', async (req, res) => {
    try {
      const result = await pool.query(
        'UPDATE formulas SET actif = false WHERE id = $1 RETURNING id',
        [req.params.id]
      );
      if (result.rows.length === 0) return res.status(404).json({ error: 'Formule introuvable' });
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/schedule — weekly class schedule (public, no auth)
  router.get('/schedule', async (req, res) => {
    try {
      const { location_id, day_of_week } = req.query;
      let query = `
        SELECT c.*,
          d.name AS discipline_name, d.color AS discipline_color,
          l.name AS location_name, l.city AS location_city
        FROM classes c
        JOIN disciplines d ON c.discipline_id = d.id
        JOIN locations l ON c.location_id = l.id
        WHERE c.active = true
      `;
      const params = [];
      let idx = 1;
      if (location_id) {
        query += ` AND c.location_id = $${idx++}`;
        params.push(location_id);
      }
      if (day_of_week) {
        query += ` AND c.day_of_week = $${idx++}`;
        params.push(day_of_week);
      }
      query += ' ORDER BY c.start_time ASC';
      const result = await pool.query(query, params);
      res.json(result.rows);
    } catch (err) {
      console.error('Error fetching schedule:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/schedule/levels — weekly schedule grouped by level tier
  // Level is inferred from discipline name since DB stores only "tous niveaux"
  router.get('/schedule/levels', async (req, res) => {
    try {
      const { level } = req.query;
      const result = await pool.query(`
        SELECT c.*,
          d.name AS discipline_name, d.color AS discipline_color,
          l.name AS location_name, l.city AS location_city
        FROM classes c
        JOIN disciplines d ON c.discipline_id = d.id
        JOIN locations l ON c.location_id = l.id
        WHERE c.active = true
        ORDER BY c.day_of_week ASC, c.start_time ASC
      `);
      // Classify by discipline name into level tiers
      const ENFANTS = ['eveil', 'initiation'];
      const ADOS = ['hip-hop', 'break', 'ragga', 'jazz latino'];
      const ADULTES = ['barre', 'pilates', 'stretching'];

      let classes = result.rows.map(cls => {
        const name = (cls.discipline_name || '').toLowerCase();
        let tier = 'adultes';
        if (ENFANTS.some(k => name.includes(k))) tier = 'enfants';
        else if (ADOS.some(k => name.includes(k))) tier = 'ados';
        return { ...cls, _tier: tier };
      });

      if (level) {
        classes = classes.filter(c => c._tier === level);
      }

      res.json(classes);
    } catch (err) {
      console.error('Error fetching schedule/levels:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/saisons/active
  router.get('/saisons/active', async (_req, res) => {
    try {
      const result = await pool.query(
        "SELECT * FROM saisons WHERE statut = 'active' ORDER BY start_date DESC LIMIT 1"
      );
      res.json(result.rows[0] || null);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
};