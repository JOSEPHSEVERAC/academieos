// routes/reseau-pages.js
// Serves static HTML pages for the reseau social PWA.
// Does NOT own: API routes, auth logic, business logic.
// Phase 3 ready — reseau-app.html route active
const path = require('path');

module.exports = function createReseauPagesRouter({ rootDir }) {
  const router = require('express').Router();

  router.get('/login', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'reseau-login.html'));
  });
  router.get('/register', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'reseau-register.html'));
  });
  router.get('/app', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'reseau-app.html'));
  });
  router.get('/manifest.json', (_req, res) => {
    res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
    res.sendFile(path.join(rootDir, 'public', 'reseau-manifest.json'));
  });
  router.get('/', (_req, res) => res.redirect('/reseau/login'));

  return router;
};