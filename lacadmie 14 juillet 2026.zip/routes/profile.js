// routes/profile.js
// Authenticated user profile and self-service endpoints.
// Does NOT own: admin user management, auth middleware (uses requireAuth from server.js).
module.exports = function createProfileRouter({ pool, requireAuth, generateToken, hashToken, logAudit }) {
  const router = require('express').Router();
  const bcrypt = require('bcryptjs');
  const crypto = require('crypto');
  const { authenticator } = require('otplib');
  const { sendEmail } = require('../services/email');

  // GET /api/profile
  router.get('/', requireAuth(), async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT id, email, first_name, last_name, role, teacher_name, phone, address, birth_date,
                legal_guardian, sizes, profile_photo_url, onboarding_completed_at, created_at, totp_enabled
         FROM app_users WHERE id = $1`,
        [req.user.id]
      );
      if (result.rows.length === 0) return res.status(404).json({ error: 'Profil non trouvé' });
      res.json(result.rows[0]);
    } catch (err) {
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/profile
  router.put('/', requireAuth(), async (req, res) => {
    try {
      const { first_name, last_name, phone, address, birth_date, legal_guardian, sizes } = req.body;
      const updates = [];
      const params = [];
      let idx = 1;

      if (first_name !== undefined) { updates.push(`first_name = $${idx++}`); params.push(first_name.trim()); }
      if (last_name !== undefined) { updates.push(`last_name = $${idx++}`); params.push(last_name.trim()); }
      if (phone !== undefined) { updates.push(`phone = $${idx++}`); params.push(phone || null); }
      if (address !== undefined) { updates.push(`address = $${idx++}`); params.push(address || null); }
      if (birth_date !== undefined) { updates.push(`birth_date = $${idx++}`); params.push(birth_date || null); }
      if (legal_guardian !== undefined) { updates.push(`legal_guardian = $${idx++}`); params.push(legal_guardian || null); }
      if (sizes !== undefined) { updates.push(`sizes = $${idx++}`); params.push(sizes ? JSON.stringify(sizes) : null); }

      if (updates.length === 0) return res.status(400).json({ error: 'Aucun champ à modifier' });

      updates.push(`updated_at = NOW()`);
      params.push(req.user.id);

      const result = await pool.query(
        `UPDATE app_users SET ${updates.join(', ')} WHERE id = $${idx}
         RETURNING id, email, first_name, last_name, role, phone, address, birth_date, legal_guardian, sizes, profile_photo_url, onboarding_completed_at`,
        params
      );
      res.json(result.rows[0]);
    } catch (err) {
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/profile/onboarding-complete
  router.post('/onboarding-complete', requireAuth(), async (req, res) => {
    try {
      await pool.query(
        `UPDATE app_users SET onboarding_completed_at = COALESCE(onboarding_completed_at, NOW()), updated_at = NOW() WHERE id = $1`,
        [req.user.id]
      );
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/profile/request-password-change
  router.post('/request-password-change', requireAuth(), async (req, res) => {
    try {
      const userId = req.user.id;
      const userResult = await pool.query('SELECT * FROM app_users WHERE id = $1 AND active = true', [userId]);
      if (userResult.rows.length === 0) return res.status(404).json({ error: 'Utilisateur non trouvé' });
      const user = userResult.rows[0];

      const token = generateToken(40);
      const tokenHash = hashToken(token);
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

      await pool.query(
        `UPDATE app_users SET invitation_token_hash = $1, invitation_expires_at = $2, updated_at = NOW() WHERE id = $3`,
        [tokenHash, expiresAt, userId]
      );

      const resetUrl = `${req.protocol}://${req.get('host')}/accept-invite?token=${token}&mode=reset`;

      const emailResult = await sendEmail(
        user.email,
        'Académie — Réinitialisation de votre mot de passe',
        `Cliquez sur le lien suivant pour réinitialiser votre mot de passe (valide 24h):\n${resetUrl}\n\nSi vous n'êtes pas à l'origine de cette demande, ignorez ce message.`
      );
      console.log(`[magic-link] sent kind=password-reset to=${user.email} messageId=${emailResult?.id || 'n/a'}`);

      // Invalidate all existing sessions for this user (they must re-auth with new password)
      await pool.query(`DELETE FROM auth_tokens WHERE user_id = $1`, [userId]);

      res.json({ success: true });
    } catch (err) {
      console.error('Password change request error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/profile/totp/setup
  // Generates a new pending TOTP secret; returns otpauth URI + QR data URI.
  // The secret is not yet active — /totp/enable must be called with a valid code.
  router.post('/totp/setup', requireAuth(), async (req, res) => {
    try {
      const QRCode = require('qrcode');
      const secret = authenticator.generateSecret();
      const uri = authenticator.keyuri(req.user.email, 'AcadémieOS', secret);
      const qrDataUri = await QRCode.toDataURL(uri);
      await pool.query('UPDATE app_users SET totp_pending_secret = $1 WHERE id = $2', [secret, req.user.id]);
      res.json({ uri, secret, qr: qrDataUri });
    } catch (err) {
      console.error('TOTP setup error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/profile/totp/enable
  // Body: { code } — verifies code against pending secret, promotes to active, generates 8 backup codes.
  // Backup codes are returned in plaintext only this once.
  router.post('/totp/enable', requireAuth(), async (req, res) => {
    try {
      const { code } = req.body;
      if (!code) return res.status(400).json({ error: 'Code requis' });
      const { rows } = await pool.query(
        'SELECT totp_pending_secret FROM app_users WHERE id = $1', [req.user.id]
      );
      const secret = rows[0]?.totp_pending_secret;
      if (!secret) return res.status(400).json({ error: 'Aucune configuration TOTP en attente' });
      if (!authenticator.check(String(code).trim(), secret))
        return res.status(400).json({ error: 'Code invalide — vérifiez l\'heure de votre téléphone' });

      const rawCodes = Array.from({ length: 8 }, () =>
        crypto.randomBytes(5).toString('hex').toUpperCase()
      );
      const hashedCodes = await Promise.all(rawCodes.map(c => bcrypt.hash(c, 10)));

      await pool.query(
        `UPDATE app_users SET totp_enabled = true, totp_secret = $1,
         totp_pending_secret = NULL, totp_backup_codes = $2 WHERE id = $3`,
        [secret, JSON.stringify(hashedCodes), req.user.id]
      );
      await logAudit(req.user.id, req.user.email, req.user.role, 'TOTP_ENABLED', 'app_users', req.user.id, null, req.ip);
      res.json({ ok: true, backup_codes: rawCodes.map(c => `${c.slice(0,5)}-${c.slice(5)}`) });
    } catch (err) {
      console.error('TOTP enable error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/profile/totp/disable
  // Body: { code } or { backup_code } — requires current TOTP or backup code before clearing.
  router.post('/totp/disable', requireAuth(), async (req, res) => {
    try {
      const { code, backup_code } = req.body;
      const { rows } = await pool.query(
        'SELECT totp_secret, totp_backup_codes FROM app_users WHERE id = $1', [req.user.id]
      );
      const user = rows[0];
      if (!user?.totp_secret) return res.status(400).json({ error: 'TOTP non configuré' });

      let verified = false;
      if (backup_code) {
        const codes = user.totp_backup_codes || [];
        const results = await Promise.all(
          codes.map(h => bcrypt.compare(String(backup_code).trim().toUpperCase(), h))
        );
        verified = results.some(Boolean);
      } else if (code) {
        verified = authenticator.check(String(code).trim(), user.totp_secret);
      }
      if (!verified) return res.status(401).json({ error: 'Code invalide' });

      await pool.query(
        `UPDATE app_users SET totp_enabled = false, totp_secret = NULL,
         totp_pending_secret = NULL, totp_backup_codes = NULL WHERE id = $1`,
        [req.user.id]
      );
      await logAudit(req.user.id, req.user.email, req.user.role, 'TOTP_DISABLED', 'app_users', req.user.id, null, req.ip);
      res.json({ ok: true });
    } catch (err) {
      console.error('TOTP disable error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/profile/totp/regenerate-backup
  // Body: { code } — requires valid TOTP code; invalidates old backup codes and returns 8 new ones.
  router.post('/totp/regenerate-backup', requireAuth(), async (req, res) => {
    try {
      const { code } = req.body;
      if (!code) return res.status(400).json({ error: 'Code requis' });
      const { rows } = await pool.query('SELECT totp_secret FROM app_users WHERE id = $1', [req.user.id]);
      const secret = rows[0]?.totp_secret;
      if (!secret) return res.status(400).json({ error: 'TOTP non configuré' });
      if (!authenticator.check(String(code).trim(), secret))
        return res.status(401).json({ error: 'Code TOTP invalide' });

      const rawCodes = Array.from({ length: 8 }, () =>
        crypto.randomBytes(5).toString('hex').toUpperCase()
      );
      const hashedCodes = await Promise.all(rawCodes.map(c => bcrypt.hash(c, 10)));
      await pool.query('UPDATE app_users SET totp_backup_codes = $1 WHERE id = $2',
        [JSON.stringify(hashedCodes), req.user.id]);
      await logAudit(req.user.id, req.user.email, req.user.role, 'TOTP_BACKUP_REGENERATED', 'app_users', req.user.id, null, req.ip);
      res.json({ ok: true, backup_codes: rawCodes.map(c => `${c.slice(0,5)}-${c.slice(5)}`) });
    } catch (err) {
      console.error('TOTP regenerate-backup error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};