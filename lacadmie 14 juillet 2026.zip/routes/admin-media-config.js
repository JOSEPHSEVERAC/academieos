// routes/admin-media-config.js
// Owns: PRÉSIDENT-facing admin endpoint to manage video/photo storage
// provider credentials in `media_provider_config` (Cloudflare Stream, Bunny,
// R2, S3, Polsia proxy) without touching Render env vars or redeploying.
//
// Does NOT own: provider API calls (services/cloudflare-stream.js), storage
// uploads (services/storage.js), raw config table (migrations/2021…).

const mediaConfig = require('../db/media-config');

module.exports = function createAdminMediaConfigRouter({ pool, requireAuth, logAudit }) {
  const router = require('express').Router();

  // GET /api/admin/media-config — current provider config (PRESIDENT only)
  // Secrets are masked to "••••••••" so the UI never receives a plaintext token.
  router.get('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const row = await mediaConfig.getEffectiveProviderConfig(pool, { includeSecrets: false });
      res.json(row);
    } catch (err) {
      console.error('[admin-media-config] GET error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/media-config — upsert provider config (PRESIDENT only)
  // Validation mirrors routes/admin-sender-config.js so that misconfiguration
  // surfaces in the UI with a clear 400 instead of an opaque upstream error.
  router.put('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const body = req.body || {};

      // 1. Validate provider if provided (allow empty string = unconfigured).
      if (body.provider != null && !mediaConfig.VALID_PROVIDERS.has(body.provider)) {
        return res.status(400).json({
          error: `provider invalide — valeurs acceptées: ${[...mediaConfig.VALID_PROVIDERS].filter(Boolean).join(', ')}`,
        });
      }

      // 2. Validate public_base_url presence for providers that need a CDN host.
      const provider = (body.provider || '').trim();
      if ((provider === 'cloudflare_stream' || provider === 'r2') && !(body.public_base_url || '').trim()) {
        return res.status(400).json({
          error: 'public_base_url requis pour ce provider (URL du CDN public)',
        });
      }

      // 3. Preserve existing secrets when the UI sends them masked/blank.
      // The admin form replaces password fields with the placeholder on load,
      // and leaves them empty on submit if the user didn't type a new secret.
      // Both forms must be treated as "do not overwrite".
      const secretKeys = mediaConfig.SECRET_FIELDS; // ['api_token','secret_access_key','access_key_id']
      const current = await mediaConfig.getActiveConfig(pool);
      const fields = {};
      for (const key of mediaConfig.UPDATABLE_FIELDS) {
        if (!Object.prototype.hasOwnProperty.call(body, key)) continue;
        const v = body[key];
        if (v == null) continue;
        if (typeof v !== 'string') {
          return res.status(400).json({ error: `${key} doit être une chaîne` });
        }
        if (secretKeys.includes(key)) {
          // Only adopt the new value if the admin actually typed one
          // (placeholder text is detected by the same mask we render).
          const trimmed = v.trim();
          if (trimmed === '' || trimmed === mediaConfig.PLACEHOLDER) {
            if (current && current[key] != null) {
              // Drop the key from `fields` so updateConfig leaves it alone.
              continue;
            }
            // No existing value either — drop the key so we don't store empty string.
            continue;
          }
          fields[key] = trimmed;
        } else {
          fields[key] = v;
        }
      }

      const next = await mediaConfig.updateConfig(pool, fields, req.user.id);

      // 4. Audit + respond with the masked row (never echo tokens back).
      if (logAudit) {
        const changedKeys = mediaConfig.diffChangedKeys(current, next);
        const new_provider = next ? next.provider : null;
        await logAudit(
          req.user.id,
          req.user.email,
          req.user.role,
          'MEDIA_PROVIDER_CONFIG_UPDATED',
          'media_provider_config',
          next?.id || 1,
          { new_provider, changed_keys: changedKeys },
          req.ip
        );
      }

      const masked = await mediaConfig.getEffectiveProviderConfig(pool, { includeSecrets: false });
      res.json(masked);
    } catch (err) {
      console.error('[admin-media-config] PUT error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};
