// routes/saisons-classes.js
// Season-scoped class management — list and create classes grouped by age tier.

const { listClassesBySaison, createClass } = require('../db/classes');
const { getActiveSaison } = require('../db/saisons');

const TIER_MAP = {
  enfants:         ['eveil', 'initiation'],
  'pré-adolescents': ['pré-ados', 'pre-adolescent'],
  adolescents:     ['ados', 'adolescent'],
  adultes:         ['barre', 'pilates', 'stretching', 'contemporain', 'classique advance'],
};

/**
 * Classify a class into a tier based on its practice_levels array.
 * Returns one of: enfants | pré-adolescents | adolescents | adultes | null
 */
function classifyTier(practiceLevels) {
  if (!practiceLevels || !practiceLevels.length) return null;
  for (const [tier, levels] of Object.entries(TIER_MAP)) {
    if (levels.some(l => practiceLevels.includes(l))) return tier;
  }
  return null;
}

/**
 * Group an array of class objects by their tier.
 * Returns: { enfants: [...], pré-adolescents: [...], adolescents: [...], adultes: [...] }
 */
function groupByTier(classes) {
  const groups = { enfants: [], 'pré-adolescents': [], adolescents: [], adultes: [] };
  for (const cls of classes) {
    const tier = classifyTier(cls.practice_levels);
    if (tier) groups[tier].push(cls);
  }
  return groups;
}

module.exports = function createSaisonsClassesRouter({ pool, requireAuth, logAudit }) {
  const express = require('express');
  const router = express.Router();

  // GET /api/saisons/classes — list classes for the active saison, grouped by age tier
  router.get('/', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const active = await getActiveSaison(pool);
      if (!active) return res.status(404).json({ error: 'Aucune saison active' });

      const classes = await listClassesBySaison(pool, { saisonId: active.id });
      const grouped = groupByTier(classes);

      res.json(grouped);
    } catch (err) {
      console.error('[saisons-classes] GET / error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/saisons/classes — create a class for the active saison
  router.post('/', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const { discipline_id, location_id, teacher_name, day_of_week, start_time, end_time, level, max_students, secondary_label, practice_levels } = req.body;

      if (!discipline_id || !location_id || day_of_week === undefined || !start_time || !end_time) {
        return res.status(400).json({ error: 'Champs requis manquants' });
      }
      if (!practice_levels || !Array.isArray(practice_levels) || !practice_levels.length) {
        return res.status(400).json({ error: "Au moins un groupe d'age requis" });
      }

      const active = await getActiveSaison(pool);
      if (!active) return res.status(404).json({ error: 'Aucune saison active' });

      const cls = await createClass(pool, {
        saison_id:      active.id,
        discipline_id,
        location_id,
        teacher_name,
        day_of_week,
        start_time,
        end_time,
        level:          level || 'tous niveaux',
        max_students:   max_students || 20,
        secondary_label,
        practice_levels,
      });

      await logAudit(
        req.user.id, req.user.email, req.user.role,
        'CREATE_CLASS', 'classes', cls.id,
        { saison_id: active.id, discipline_id, practice_levels },
        req.ip
      );

      res.status(201).json(cls);
    } catch (err) {
      console.error('[saisons-classes] POST / error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/saisons/classes/:id — update a class
  router.put('/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const { id } = req.params;
      const { discipline_id, location_id, teacher_name, day_of_week, start_time, end_time, level, max_students, secondary_label, practice_levels } = req.body;

      const existing = await pool.query(
        'SELECT id FROM classes WHERE id = $1 AND active = true',
        [id]
      );
      if (!existing.rows.length) return res.status(404).json({ error: 'Cours non trouvé' });

      const result = await pool.query(
        `UPDATE classes SET
           discipline_id = COALESCE($1, discipline_id),
           location_id = COALESCE($2, location_id),
           teacher_name = $3,
           day_of_week = COALESCE($4, day_of_week),
           start_time = $5,
           end_time = $6,
           level = COALESCE($7, level),
           max_students = COALESCE($8, max_students),
           secondary_label = $9,
           practice_levels = COALESCE($10, practice_levels),
           updated_at = NOW()
         WHERE id = $11 RETURNING *`,
        [
          discipline_id || null, location_id || null,
          teacher_name !== undefined ? (teacher_name || null) : undefined,
          day_of_week !== undefined ? day_of_week : undefined,
          start_time || null, end_time || null,
          level || null, max_students || null,
          secondary_label !== undefined ? (secondary_label || null) : undefined,
          practice_levels !== undefined ? (Array.isArray(practice_levels) ? practice_levels : []) : undefined,
          id
        ]
      );

      if (req.user) await logAudit(req.user.id, req.user.email, req.user.role, 'UPDATE_CLASS', 'classes', id,
        { teacher_name: result.rows[0].teacher_name }, req.ip);

      const fullClass = await pool.query(
        `SELECT c.*, d.name as discipline_name, d.color as discipline_color, l.name as location_name, l.city as location_city
         FROM classes c JOIN disciplines d ON c.discipline_id = d.id JOIN locations l ON c.location_id = l.id
         WHERE c.id = $1`,
        [id]
      );
      res.json(fullClass.rows[0]);
    } catch (err) {
      console.error('[saisons-classes] PUT /:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // DELETE /api/saisons/classes/:id — soft-delete a class
  router.delete('/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const { id } = req.params;
      const result = await pool.query(
        'UPDATE classes SET active = false WHERE id = $1 RETURNING id, teacher_name',
        [id]
      );
      if (!result.rows.length) return res.status(404).json({ error: 'Cours non trouvé' });

      if (req.user) await logAudit(req.user.id, req.user.email, req.user.role, 'DELETE_CLASS', 'classes', id,
        { teacher_name: result.rows[0].teacher_name }, req.ip);

      res.json({ deleted: true });
    } catch (err) {
      console.error('[saisons-classes] DELETE /:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};