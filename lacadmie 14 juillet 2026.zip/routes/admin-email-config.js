// routes/admin-email-config.js
// Owns: PRÉSIDENT-facing admin endpoints for the email provider (Resend ↔ SMTP)
// and the two app-wide toggles (global 2FA, passwordless magic link).
//
// Does NOT own: send dispatch (services/email.js), raw config table
// (migrations/203…_email_smtp_config_and_app_settings.js), per-user TOTP
// enrollment (routes/profile.js).

const emailConfig = require('../db/email-config');
const appSettings = require('../db/app-settings');

function invalidProviderError() {
  return {
    error: `provider invalide — valeurs acceptées: ${[...emailConfig.VALID_PROVIDERS].filter(Boolean).join(', ')}`,
  };
}

module.exports = function createAdminEmailConfigRouter({ pool, requireAuth, logAudit }) {
  const express = require('express');
  // Two separate routers so server.js can mount the email-config endpoints
  // under /api/admin/email-config and the toggle endpoints under
  // /api/admin/settings — without path collisions on router.get('/').
  const emailRouter = express.Router();
  const settingsRouter = express.Router();

  // ── /api/admin/email-config ──────────────────────────────────────────────

  // GET /api/admin/email-config — current SMTP/Resend config (PRESIDENT only)
  emailRouter.get('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const row = await emailConfig.getEffectiveConfig(pool, { includeSecrets: false });
      res.json(row);
    } catch (err) {
      console.error('[admin-email-config] GET error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/email-config — upsert SMTP/provider config (PRESIDENT only)
  // Mirrors routes/admin-media-config.js: skip empty/placeholder on secret
  // fields so the UI's password-mask-on-load idiom doesn't clobber creds.
  emailRouter.put('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const body = req.body || {};

      // 1. Validate provider if provided.
      if (body.provider != null && !emailConfig.VALID_PROVIDERS.has(body.provider)) {
        return res.status(400).json(invalidProviderError());
      }

      // 2. Validate smtp_port if present.
      if (body.smtp_port != null && body.smtp_port !== '') {
        const n = Number(body.smtp_port);
        if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1 || n > 65535) {
          return res.status(400).json({ error: 'smtp_port doit être un entier entre 1 et 65535' });
        }
      }

      // 3. When switching to provider=smtp, all four core creds must be set.
      //    from_address is required so the From header never resolves to
      //    process.env.FROM_EMAIL silently.
      const targetProvider = ((body.provider ?? '').toString().trim()) || '';
      if (targetProvider === 'smtp') {
        const current = await emailConfig.getActiveConfig(pool);
        const next = {};
        for (const k of emailConfig.UPDATABLE_FIELDS) {
          if (!Object.prototype.hasOwnProperty.call(body, k)) continue;
          if (typeof body[k] === 'string') next[k] = body[k].trim();
          else next[k] = body[k];
        }
        const merged = {
          smtp_host: next.smtp_host ?? current?.smtp_host,
          smtp_port: next.smtp_port ?? current?.smtp_port,
          smtp_user: next.smtp_user ?? current?.smtp_user,
          smtp_password: next.smtp_password ?? current?.smtp_password,
          from_address: next.from_address ?? current?.from_address,
        };
        const missing = [];
        if (!merged.smtp_host) missing.push('smtp_host');
        if (!merged.smtp_port) missing.push('smtp_port');
        if (!merged.smtp_user) missing.push('smtp_user');
        if (!merged.smtp_password) missing.push('smtp_password');
        if (!merged.from_address) missing.push('from_address');
        if (missing.length) {
          return res.status(400).json({ error: `Champs requis pour SMTP: ${missing.join(', ')}` });
        }
      }

      // 4. Preserve existing secrets when the UI sends them masked/blank.
      const secretKeys = emailConfig.SECRET_FIELDS; // ['smtp_password']
      const current = await emailConfig.getActiveConfig(pool);
      const fields = {};
      for (const key of emailConfig.UPDATABLE_FIELDS) {
        if (!Object.prototype.hasOwnProperty.call(body, key)) continue;
        const v = body[key];
        if (v == null) continue;
        if (typeof v !== 'string') {
          return res.status(400).json({ error: `${key} doit être une chaîne` });
        }
        if (secretKeys.includes(key)) {
          const trimmed = v.trim();
          if (trimmed === '' || trimmed === emailConfig.PLACEHOLDER) {
            // Either the admin left it blank or kept the placeholder mask —
            // both mean "leave current value alone".
            continue;
          }
          fields[key] = trimmed;
        } else {
          fields[key] = v;
        }
      }

      const next = await emailConfig.updateConfig(pool, fields, req.user.id);

      // 5. If the SMTP password / host / port actually changed, drop the
      //    cached nodemailer transport so the next send picks up the new
      //    credentials without a restart.
      const changed = emailConfig.diffChangedKeys(current, next);
      if (changed.some((k) => ['smtp_password', 'smtp_host', 'smtp_port', 'smtp_user', 'smtp_secure'].includes(k))) {
        try {
          const { invalidateSmtpTransport } = require('../services/email');
          invalidateSmtpTransport();
        } catch (err) {
          // non-fatal: email service might not be loaded in unit tests
        }
      }

      // 6. Audit + respond with the masked row (never echo password).
      if (logAudit) {
        await logAudit(
          req.user.id,
          req.user.email,
          req.user.role,
          'EMAIL_CONFIG_UPDATED',
          'email_smtp_config',
          next?.id || 1,
          { new_provider: next ? next.provider : null, changed_keys: changed },
          req.ip
        );
      }

      const masked = await emailConfig.getEffectiveConfig(pool, { includeSecrets: false });
      res.json(masked);
    } catch (err) {
      console.error('[admin-email-config] PUT error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/admin/email-config/test — send a probe email through the same
  // path magic-link / invites use. Doesn't mutate the row. Surfaces the
  // upstream SMTP/Resend error to the admin verbatim so 535 vs 550 are
  // distinguishable in the UI.
  emailRouter.post('/test', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const { to } = req.body || {};
      if (!to || typeof to !== 'string' || !to.includes('@')) {
        return res.status(400).json({ error: 'Champ "to" requis (email)' });
      }
      const subject = '[TEST] AcadémieOS — SMTP test';
      const body =
        `Cet email confirme que la configuration SMTP/Resend de votre CRM\n` +
        `AcadémieOS fonctionne.\n\n` +
        `Envoyé le ${new Date().toISOString()}\n\n— L'Académie`;
      try {
        const { sendEmail } = require('../services/email');
        const result = await sendEmail(to, subject, body);
        if (logAudit) {
          await logAudit(
            req.user.id,
            req.user.email,
            req.user.role,
            'EMAIL_TEST_SENT',
            'email_smtp_config',
            1,
            { to, message_id: result?.id || null },
            req.ip
          );
        }
        res.json({ ok: true, messageId: result?.id || null });
      } catch (sendErr) {
        console.error('[admin-email-config] test send error:', sendErr.message);
        if (logAudit) {
          await logAudit(
            req.user.id,
            req.user.email,
            req.user.role,
            'EMAIL_TEST_FAILED',
            'email_smtp_config',
            1,
            { to, code: sendErr.code || null, error: sendErr.message || null },
            req.ip
          );
        }
        res.json({
          ok: false,
          error: sendErr.message || 'envoi échoué',
          code: sendErr.code || null,
        });
      }
    } catch (err) {
      console.error('[admin-email-config] POST /test error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── /api/admin/settings ─────────────────────────────────────────────────

  // GET /api/admin/settings — currently toggled flags. Force fresh read so
  // the admin sees their own last write instantly (the 60s cache would
  // otherwise hide it).
  settingsRouter.get('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const row = await appSettings.getSettings(pool);
      res.json(row || {
        two_factor_enabled: false,
        passwordless_magic_link_enabled: false,
        magic_link_ttl_hours: 24,
        magic_link_template: null,
        two_factor_method: 'totp',
      });
    } catch (err) {
      console.error('[admin-email-config] GET /settings error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/settings/two-factor — toggle global 2FA enforcement.
  // This is the global "should be enforced" flag. Per-user
  // app_users.totp_enabled is the "user has enrolled a secret" flag.
  // Login only demands a TOTP code when BOTH are true.
  settingsRouter.put('/two-factor', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const { enabled } = req.body || {};
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ error: 'enabled (boolean) requis' });
      }
      const next = await appSettings.updateSettings(pool, { two_factor_enabled: enabled }, req.user.id);
      appSettings.invalidateSettingsCache();
      if (logAudit) {
        await logAudit(
          req.user.id,
          req.user.email,
          req.user.role,
          'TWO_FACTOR_GLOBAL_TOGGLED',
          'app_settings',
          1,
          { new_value: enabled },
          req.ip
        );
      }
      res.json(next);
    } catch (err) {
      console.error('[admin-email-config] PUT /two-factor error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/settings/magic-link — edit the magic-link TTL and template.
  // `{ ttl_hours, template }` — both optional but at least one required so a
  // stray empty PUT can't silently no-op. TTL bounds match the DB CHECK
  // (1..168). Template is plain TEXT, stored as NULL when blank so the
  // server falls back to the default French body. Distinct audit event from
  // MAGIC_LINK_TOGGLED so the two concerns stay separate in the log.
  settingsRouter.put('/magic-link', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const body = req.body || {};
      const fields = {};
      if (Object.prototype.hasOwnProperty.call(body, 'ttl_hours')) {
        fields.magic_link_ttl_hours = body.ttl_hours;
      }
      if (Object.prototype.hasOwnProperty.call(body, 'template')) {
        fields.magic_link_template = body.template;
      }
      if (Object.keys(fields).length === 0) {
        return res.status(400).json({ error: 'ttl_hours ou template requis' });
      }
      let next;
      try {
        next = await appSettings.updateSettings(pool, fields, req.user.id);
      } catch (err) {
        if (err && err.statusCode === 400) {
          return res.status(400).json({ error: err.message });
        }
        throw err;
      }
      // updateSettings() already invalidates, but call explicitly so a future
      // refactor that moves invalidation back to the caller still works.
      appSettings.invalidateSettingsCache();
      if (logAudit) {
        const meta = {};
        if ('magic_link_ttl_hours' in fields) meta.new_ttl_hours = next?.magic_link_ttl_hours ?? null;
        if ('magic_link_template' in fields) meta.template_changed = !!fields.magic_link_template;
        await logAudit(
          req.user.id,
          req.user.email,
          req.user.role,
          'MAGIC_LINK_CONFIG_UPDATED',
          'app_settings',
          1,
          meta,
          req.ip
        );
      }
      res.json(next);
    } catch (err) {
      console.error('[admin-email-config] PUT /magic-link error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/settings/two-factor-method — switch the active 2FA method.
  // Whitelisted to 'totp' today (mirrors the DB CHECK). Persisting the column
  // now means SMS / WebAuthn can land later without a migration.
  settingsRouter.put('/two-factor-method', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const { method } = req.body || {};
      if (typeof method !== 'string') {
        return res.status(400).json({ error: 'method (string) requis' });
      }
      const trimmed = method.trim();
      if (!appSettings.VALID_2FA_METHODS.has(trimmed)) {
        return res.status(400).json({
          error: `method invalide — valeurs acceptées: ${[...appSettings.VALID_2FA_METHODS].join(', ')}`,
        });
      }
      let next;
      try {
        next = await appSettings.updateSettings(pool, { two_factor_method: trimmed }, req.user.id);
      } catch (err) {
        if (err && err.statusCode === 400) {
          return res.status(400).json({ error: err.message });
        }
        throw err;
      }
      appSettings.invalidateSettingsCache();
      if (logAudit) {
        await logAudit(
          req.user.id,
          req.user.email,
          req.user.role,
          'TWO_FACTOR_METHOD_CHANGED',
          'app_settings',
          1,
          { new_method: trimmed },
          req.ip
        );
      }
      res.json(next);
    } catch (err) {
      console.error('[admin-email-config] PUT /two-factor-method error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/settings/passwordless-magic-link — toggle the global
  // passwordless login endpoint.
  settingsRouter.put('/passwordless-magic-link', requireAuth(['PRÉSIDENT']), async (req, res) => {
    try {
      const { enabled } = req.body || {};
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ error: 'enabled (boolean) requis' });
      }
      const next = await appSettings.updateSettings(
        pool,
        { passwordless_magic_link_enabled: enabled },
        req.user.id
      );
      appSettings.invalidateSettingsCache();
      if (logAudit) {
        await logAudit(
          req.user.id,
          req.user.email,
          req.user.role,
          'MAGIC_LINK_TOGGLED',
          'app_settings',
          1,
          { new_value: enabled },
          req.ip
        );
      }
      res.json(next);
    } catch (err) {
      console.error('[admin-email-config] PUT /passwordless-magic-link error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return { emailRouter, settingsRouter };
};
