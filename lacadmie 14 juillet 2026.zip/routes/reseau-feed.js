// routes/reseau-feed.js
// Owns: reseau social news feed — posts, comments, reactions.
// Does NOT own: auth (reseau-auth.js), DMs (reseau-messaging.js).

const rf = require('../db/reseau-feed');
const storage = require('../services/storage');
const { uploadFile, isConfigured } = require('../services/r2');
const { notifySocialEvent } = require('../services/notifications');

function isR2Url(url) {
  return !!(url && url.startsWith(storage.publicHost()));
}

// ── Middleware: require valid reseau session ──────────────────────────────────
function requireReseauAuth(pool, req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization' });
  }
  const token = authHeader.slice(7);
  pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(result => {
    if (!result.rows[0]) {
      return res.status(401).json({ error: 'Session expired or invalid' });
    }
    const row = result.rows[0];
    req.sessionUser = {
      id: row.user_id,
      sessionId: row.session_id,
      email: row.email,
      nom: row.nom,
      prenom: row.prenom,
      role: row.role,
    };
    next();
  }).catch(err => {
    console.error('Reseau feed session error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });
}

function requireModerator(req, res, next) {
  if (!['president', 'directrice'].includes(req.sessionUser.role)) {
    return res.status(403).json({ error: 'Modération réservée à la direction' });
  }
  next();
}

const REACTION_EMOJIS = ['👍', '❤️', '🎉', '😂', '😮'];

module.exports = function createReseauFeedRouter({ pool }) {
  const router = require('express').Router();

  // All routes require auth
  router.use((req, res, next) => requireReseauAuth(pool, req, res, next));

  // ── GET /reseau/api/feed ────────────────────────────────────────────────────
  // Paginated feed, cursor-based (id < beforeId).
  router.get('/', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit, 10) || 10, 50);
      const beforeId = req.query.before ? parseInt(req.query.before, 10) : null;

      const posts = await rf.getFeed(pool, limit, beforeId);

      // Attach comments for each post (top-level only, for performance)
      const enriched = await Promise.all(posts.map(async (post) => {
        const comments = await rf.getComments(pool, post.id);
        // Trim comments to 3 for feed preview
        const previewComments = comments.slice(0, 3);
        return {
          ...post,
          comments: previewComments,
          comment_count: comments.length,
        };
      }));

      res.json({ posts: enriched, next_cursor: posts.length === limit ? posts[posts.length - 1].id : null });
    } catch (err) {
      console.error('GET /reseau/api/feed error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/feed/posts ─────────────────────────────────────────────
  router.post('/posts', async (req, res) => {
    try {
      const { content, image_data } = req.body;
      if (!content || !content.trim()) {
        return res.status(400).json({ error: 'Contenu requis' });
      }
      if (content.trim().length > 2000) {
        return res.status(400).json({ error: 'Message limité à 2000 caractères' });
      }
      // Image data is base64 — validate it's not absurdly large (max ~200KB)
      if (image_data && image_data.length > 280000) {
        return res.status(400).json({ error: 'Image trop volumineuse (max 200 Ko)' });
      }

      let imageUrl = null;
      if (image_data) {
        if (isR2Url(image_data)) {
          imageUrl = image_data;
        } else if (image_data.startsWith('data:image/')) {
          if (!isConfigured()) {
            return res.status(503).json({ error: 'Stockage non configuré.' });
          }
          const mimeMatch = image_data.match(/^data:([^;]+);/);
          const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
          const ext = mimeType === 'image/png' ? 'png' : 'jpg';
          const rawBase64 = image_data.replace(/^data:[^;]+;base64,/, '');
          try {
            imageUrl = await uploadFile(rawBase64, 'feed-posts', `post.${ext}`, mimeType);
          } catch (r2Err) {
            console.warn('[reseau-feed] R2 upload failed, storing as base64 in DB:', r2Err.message);
            // Platform bug: POLSIA_API_KEY rejected by image proxy (401 for all auth formats).
            imageUrl = image_data; // store data URI directly — post still visible
          }
        }
      }

      const post = await rf.createPost(pool, {
        authorId: req.sessionUser.id,
        content: content.trim(),
        imageData: imageUrl,
      });

      // Notification seam — fires for every post (recipient resolution +
      // @mention parsing land in a later change). Today: log-only.
      notifySocialEvent(pool, {
        kind: 'post_created',
        actorId: req.sessionUser.id,
        entityType: 'post',
        entityId: post.id,
      }).catch(() => {});

      res.status(201).json({
        id: post.id,
        content: post.content,
        image_data: post.image_data,
        created_at: post.created_at,
        author_id: req.sessionUser.id,
        author_nom: req.sessionUser.nom,
        author_prenom: req.sessionUser.prenom,
        author_role: req.sessionUser.role,
        reaction_counts: {},
        comment_count: 0,
        comments: [],
      });
    } catch (err) {
      console.error('POST /reseau/api/feed/posts error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/feed/posts/:id ──────────────────────────────────────────
  // Full post with all comments (for detail view).
  router.get('/posts/:id', async (req, res) => {
    try {
      const postId = parseInt(req.params.id, 10);
      if (isNaN(postId)) return res.status(400).json({ error: 'ID invalide' });

      const post = await rf.getPost(pool, postId);
      if (!post) return res.status(404).json({ error: 'Post introuvable' });

      const comments = await rf.getComments(pool, postId);
      res.json({ ...post, comments, comment_count: comments.length });
    } catch (err) {
      console.error('GET /reseau/api/feed/posts/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/feed/posts/:id/image ───────────────────────────────────
  // Returns base64 image_data for a single post (lazy-load, keeps feed JSON small).
  router.get('/posts/:id/image', async (req, res) => {
    try {
      const postId = parseInt(req.params.id, 10);
      if (isNaN(postId)) return res.status(400).json({ error: 'ID invalide' });

      const result = await pool.query(
        `SELECT image_data FROM reseau_posts WHERE id = $1 AND is_deleted = false`,
        [postId]
      );
      if (!result.rows[0]) return res.status(404).json({ error: 'Post introuvable' });
      if (!result.rows[0].image_data) return res.status(404).json({ error: 'Pas d image' });

      res.json({ image_data: result.rows[0].image_data });
    } catch (err) {
      console.error('GET /reseau/api/feed/posts/:id/image error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/feed/posts/:id/comments ────────────────────────────────
  router.post('/posts/:id/comments', async (req, res) => {
    try {
      const postId = parseInt(req.params.id, 10);
      if (isNaN(postId)) return res.status(400).json({ error: 'ID invalide' });

      const { content } = req.body;
      if (!content || !content.trim()) {
        return res.status(400).json({ error: 'Commentaire vide' });
      }
      if (content.trim().length > 1000) {
        return res.status(400).json({ error: 'Commentaire limité à 1000 caractères' });
      }

      const comment = await rf.createComment(pool, {
        postId,
        authorId: req.sessionUser.id,
        content: content.trim(),
      });

      // Mention seam — fires for every comment today. When @mention parsing
      // ships, the call will be conditioned on whether any @user tokens are
      // present and resolve to recipient IDs.
      notifySocialEvent(pool, {
        kind: 'mention',
        actorId: req.sessionUser.id,
        entityType: 'comment',
        entityId: comment.id,
        post_id: postId,
      }).catch(() => {});

      res.status(201).json({
        id: comment.id,
        content: comment.content,
        created_at: comment.created_at,
        author_id: req.sessionUser.id,
        author_nom: req.sessionUser.nom,
        author_prenom: req.sessionUser.prenom,
        author_role: req.sessionUser.role,
      });
    } catch (err) {
      console.error('POST /reseau/api/feed/posts/:id/comments error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/feed/posts/:id/react ───────────────────────────────────
  // Toggle reaction (add if not present, remove if already reacted).
  router.post('/posts/:id/react', async (req, res) => {
    try {
      const postId = parseInt(req.params.id, 10);
      if (isNaN(postId)) return res.status(400).json({ error: 'ID invalide' });

      const { emoji } = req.body;
      if (!emoji || !REACTION_EMOJIS.includes(emoji)) {
        return res.status(400).json({ error: 'Emoji invalide' });
      }

      const result = await rf.toggleReaction(pool, {
        postId,
        authorId: req.sessionUser.id,
        emoji,
      });

      res.json(result);
    } catch (err) {
      console.error('POST /reseau/api/feed/posts/:id/react error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── DELETE /reseau/api/feed/posts/:id ───────────────────────────────────────
  // Moderator delete (president / directrice only).
  router.delete('/posts/:id', requireModerator, async (req, res) => {
    try {
      const postId = parseInt(req.params.id, 10);
      if (isNaN(postId)) return res.status(400).json({ error: 'ID invalide' });

      await rf.deletePost(pool, postId);
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /reseau/api/feed/posts/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── DELETE /reseau/api/feed/comments/:id ───────────────────────────────────
  // Moderator delete (president / directrice only).
  router.delete('/comments/:id', requireModerator, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id, 10);
      if (isNaN(commentId)) return res.status(400).json({ error: 'ID invalide' });

      await rf.deleteComment(pool, commentId);
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /reseau/api/feed/comments/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};