// routes/boutique.js
// Boutique catalogue (products) and Printful POD orders.
// Owns: boutique_products, boutique_orders, boutique_order_items.
// Auth: CRM Bearer for admin; reseau Bearer for adherents.

const bq = require('../db/boutique');
const printful = require('../services/printful');
const { sendOrderConfirmation } = require('../db/enrollment-notifications');

// ── Reseau session middleware ─────────────────────────────────────────────────

function requireReseauAuth(pool, req, res, next) {
  const auth = req.headers.authorization || '';
  if (!auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing authorization' });
  const token = auth.slice(7);
  pool.query(
    `SELECT rs.id, rs.user_id, rs.expires_at, ur.id, ur.nom, ur.prenom, ur.role
     FROM reseau_sessions rs JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(r => {
    if (!r.rows[0]) return res.status(401).json({ error: 'Session expired' });
    const row = r.rows[0];
    req.sessionUser = { id: row.user_id, nom: row.nom, prenom: row.prenom, role: row.role };
    next();
  }).catch(() => res.status(500).json({ error: 'Internal error' }));
}

function requireDirection(req, res, next) {
  if (!['president', 'directrice', 'professeur'].includes(req.sessionUser?.role)) {
    return res.status(403).json({ error: 'Action réservée à la direction' });
  }
  next();
}

// ── CRM Admin routes — /api/boutique ─────────────────────────────────────────

function createBoutiqueRouter({ pool, requireAuth }) {
  const router = require('express').Router();

  // Products: list
  router.get('/products', async (req, res) => {
    try {
      const { actif, categorie } = req.query;
      const products = await bq.getProducts(pool, {
        actif: actif === undefined ? undefined : actif === 'true',
        categorie: categorie || undefined,
      });
      res.json(products);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  // Products: create (admin)
  router.post('/products', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const p = req.body;
      const product = await bq.createProduct(pool, {
        name: p.name,
        description: p.description || '',
        sku_printful: p.sku_printful || '',
        printful_variant_id: p.printful_variant_id || '',
        prix_coutant_cents: Math.round(parseFloat(p.prix_coutant || 0) * 100),
        prix_public_cents: Math.round(parseFloat(p.prix_public || 0) * 100),
        remise_pourcentage: Math.round(parseFloat(p.remise_pourcentage || 20)),
        image_url: p.image_url || '',
        taille: p.taille || '',
        couleur: p.couleur || '',
        categorie: p.categorie || 'vetements',
        actif: p.actif !== false,
      });
      res.status(201).json(product);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur: ' + err.message });
    }
  });

  // Products: update (admin)
  router.put('/products/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const p = req.body;
      const fields = {};
      if (p.name !== undefined) fields.name = p.name;
      if (p.description !== undefined) fields.description = p.description;
      if (p.sku_printful !== undefined) fields.sku_printful = p.sku_printful;
      if (p.printful_variant_id !== undefined) fields.printful_variant_id = p.printful_variant_id;
      if (p.prix_coutant !== undefined) fields.prix_coutant_cents = Math.round(parseFloat(p.prix_coutant) * 100);
      if (p.prix_public !== undefined) fields.prix_public_cents = Math.round(parseFloat(p.prix_public) * 100);
      if (p.remise_pourcentage !== undefined) fields.remise_pourcentage = Math.round(parseFloat(p.remise_pourcentage));
      if (p.image_url !== undefined) fields.image_url = p.image_url;
      if (p.taille !== undefined) fields.taille = p.taille;
      if (p.couleur !== undefined) fields.couleur = p.couleur;
      if (p.categorie !== undefined) fields.categorie = p.categorie;
      if (p.actif !== undefined) fields.actif = p.actif;
      const product = await bq.updateProduct(pool, id, fields);
      if (!product) return res.status(404).json({ error: 'Produit introuvable' });
      res.json(product);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur: ' + err.message });
    }
  });

  // Products: delete (admin)
  router.delete('/products/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      await bq.deleteProduct(pool, parseInt(req.params.id, 10));
      res.json({ ok: true });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  // Orders: list (admin)
  router.get('/orders', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const { status, limit } = req.query;
      const orders = await bq.getOrders(pool, {
        status: status || undefined,
        limit: limit ? parseInt(limit, 10) : 50,
      });
      res.json(orders);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  // Orders: single (admin)
  router.get('/orders/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const order = await bq.getOrderById(pool, parseInt(req.params.id, 10));
      if (!order) return res.status(404).json({ error: 'Commande introuvable' });
      res.json(order);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  // Orders: update status (admin)
  router.put('/orders/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const p = req.body;
      const order = await bq.updateOrderStatus(pool, id, {
        status: p.status,
        printful_order_id: p.printful_order_id,
        printful_tracking_number: p.printful_tracking_number,
        printful_tracking_url: p.printful_tracking_url,
        notes: p.notes,
      });
      if (!order) return res.status(404).json({ error: 'Commande introuvable' });
      res.json(order);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur: ' + err.message });
    }
  });

  // Orders: stats (admin)
  router.get('/stats', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const stats = await bq.getOrderStats(pool);
      res.json(stats);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  // ── Printful integration ──────────────────────────────────────────────────

  // Diagnostic: ping Printful API to verify token works
  router.get('/test-printful', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const syncProducts = await printful.getSyncProducts();
      res.json({ ok: true, token_status: 'active', count: syncProducts.length });
    } catch (err) {
      if (err.message.includes('not configured')) {
        return res.status(422).json({ ok: false, token_status: 'missing', error: err.message });
      }
      if (err.message.includes('Unauthorized') || err.message.includes('401')) {
        return res.status(401).json({ ok: false, token_status: 'invalid', error: err.message });
      }
      res.status(502).json({ ok: false, token_status: 'error', error: err.message });
    }
  });

  // Import products from Printful sync catalog
  router.post('/import-printful', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const syncProducts = await printful.getSyncProducts();

      let imported = 0;
      let skipped = 0;

      for (const sp of syncProducts) {
        // Check if already imported (match by sync_product_id / external_id)
        const existing = await bq.getProducts(pool, {});
        const alreadyImported = existing.find(p =>
          p.sku_printful === sp.id.toString() || p.printful_variant_id === sp.id.toString()
        );
        if (alreadyImported) { skipped++; continue; }

        // Extract first variant for pricing — Printful sync products include the variant data
        const variant = sp.variants?.[0];
        if (!variant) { skipped++; continue; }

        const priceRetail = parseFloat(variant.retail_price || 0);
        const priceCost = parseFloat(variant.cost || 0);
        const percent = priceRetail > 0 ? Math.round((1 - priceCost / priceRetail) * 100) : 20;

        await bq.createProduct(pool, {
          name: sp.name || 'Produit Printful',
          description: sp.description || '',
          sku_printful: sp.id?.toString() || '',
          printful_variant_id: variant.id?.toString() || '',
          prix_coutant_cents: Math.round(priceCost * 100),
          prix_public_cents: Math.round(priceRetail * 100),
          remise_pourcentage: Math.min(percent, 80),
          image_url: variant.image_url || '',
          taille: variant.size || '',
          couleur: variant.color || '',
          categorie: req.body.categorie || 'vetements',
          actif: true,
        });
        imported++;
      }

      res.json({ imported, skipped, total: syncProducts.length });
    } catch (err) {
      console.error('[boutique] import-printful:', err);
      if (err.message.includes('not configured')) {
        return res.status(422).json({ error: err.message });
      }
      res.status(500).json({ error: 'Erreur: ' + err.message });
    }
  });

  // Send a single order to Printful (auto-creates the Printful order)
  router.post('/orders/:id/send-to-printful', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const orderId = parseInt(req.params.id, 10);
      const order = await bq.getOrderById(pool, orderId);
      if (!order) return res.status(404).json({ error: 'Commande introuvable' });

      // Get adhéré's shipping address from users_reseau
      const userRows = await pool.query(
        'SELECT nom, prenom, email FROM users_reseau WHERE id = $1', [order.user_id]
      );
      const user = userRows.rows[0];
      if (!user) return res.status(404).json({ error: 'Adhérent introuvable' });

      // Build items list from order items — requires sync_variant_id on boutique_order_items
      // Fall back to sku matching if not set
      const printfulItems = (order.items || [])
        .filter(i => i.id)
        .map(item => ({
          sync_variant_id: item.sync_variant_id || item.printful_variant_id ? parseInt(item.printful_variant_id, 10) : null,
          variant_id: item.printful_variant_id ? parseInt(item.printful_variant_id, 10) : null,
          quantity: 1,
        }))
        .filter(item => item.sync_variant_id || item.variant_id);

      if (printfulItems.length === 0) {
        return res.status(422).json({
          error: 'Aucun article n a de variant Printful — importez depuis Printful d abord',
        });
      }

      const pfOrder = await printful.createOrder({
        recipientName: `${user.prenom} ${user.nom}`,
        recipientEmail: user.email,
        recipientAddress: req.body.address || 'Non renseignée',
        recipientCity: req.body.city || 'France',
        recipientCountryCode: req.body.country || 'FR',
        recipientZip: req.body.zip || '00000',
        items: printfulItems,
        retailLine: 'true',
      });

      await bq.updateOrderStatus(pool, orderId, {
        status: 'envoyee_à_printful',
        printful_order_id: pfOrder.id?.toString() || pfOrder.order_id?.toString(),
        printful_status: pfOrder.status || 'pending',
      });

      // Fire-and-forget status update email to the adhèrent.
      (async () => {
        try {
          const fresh = await bq.getOrderById(pool, orderId);
          await sendOrderConfirmation(pool, fresh, user);
        } catch (err) {
          console.warn('[boutique] send-to-printful status email failed:', err.message);
        }
      })();

      res.json({ ok: true, printful_order_id: pfOrder.id || pfOrder.order_id });
    } catch (err) {
      console.error('[boutique] send-to-printful:', err);
      if (err.message.includes('not configured')) {
        return res.status(422).json({ error: err.message });
      }
      res.status(500).json({ error: 'Erreur Printful: ' + err.message });
    }
  });

  // Sync Printful order status for all orders that have a printful_order_id
  router.post('/sync-printful-orders', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const orders = await bq.getOrders(pool, {});
      const withPfId = orders.filter(o => o.printful_order_id);
      let updated = 0;

      for (const order of withPfId) {
        try {
          const pfOrder = await printful.getOrder(order.printful_order_id);
          const fields = {};
          if (pfOrder.status) fields.printful_status = pfOrder.status;
          if (pfOrder.tracking_number) fields.printful_tracking_number = pfOrder.tracking_number;
          if (pfOrder.tracking_url) fields.printful_tracking_url = pfOrder.tracking_url;

          if (Object.keys(fields).length > 0) {
            // Map Printful status to our status
            const statusMap = {
              'pending': 'en_attente',
              'processing': 'en_production',
              'in_production': 'en_production',
              'shipped': 'expediee',
              'delivered': 'livree',
              'cancelled': 'livree',
            };
            if (statusMap[pfOrder.status]) fields.status = statusMap[pfOrder.status];
            await bq.updateOrderStatus(pool, order.id, fields);
            updated++;
          }
        } catch (_) { /* skip orders with invalid PF ID */ }
      }

      res.json({ synced: updated });
    } catch (err) {
      console.error('[boutique] sync-printful-orders:', err);
      res.status(500).json({ error: 'Erreur: ' + err.message });
    }
  });

  return router;
}

// ── Reseau routes — /reseau/api/boutique (adhérents) ─────────────────────────

function createReseauBoutiqueRouter({ pool }) {
  const router = require('express').Router();

  // Products: public catalogue (actifs)
  router.get('/products', async (req, res) => {
    try {
      const { categorie } = req.query;
      const products = await bq.getProducts(pool, { actif: true, categorie: categorie || undefined });
      // Return only what's needed for display (no internal cost data for adherent)
      const displayProducts = products.map(p => ({
        id: p.id,
        name: p.name,
        description: p.description,
        image_url: p.image_url,
        taille: p.taille,
        couleur: p.couleur,
        categorie: p.categorie,
        prix_public_cents: p.prix_public_cents,
        prix_adherent_cents: Math.round(p.prix_public_cents * (100 - p.remise_pourcentage) / 100),
        remise_pourcentage: p.remise_pourcentage,
        cout_printful_cents: p.prix_coutant_cents,
        sku_printful: p.sku_printful,
        printful_variant_id: p.printful_variant_id,
      }));
      res.json(displayProducts);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  // Place order (adhérent) — auto-creates Printful order if token is configured
  router.post('/orders', requireReseauAuth, async (req, res) => {
    try {
      const { items, frais_livraison_cents, notes, shipping_address } = req.body;
      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Panier vide' });
      }

      const order = await bq.createOrder(pool, {
        user_id: req.sessionUser.id,
        items,
        frais_livraison_cents: Math.round(parseFloat(frais_livraison_cents || 0) * 100),
        notes: notes || '',
      });

      // Try to auto-create Printful order if token is configured
      let refreshedOrder = order;
      if (process.env.PRINTFUL_API_TOKEN) {
        try {
          const addr = shipping_address || {};
          const userRows = await pool.query(
            'SELECT nom, prenom, email FROM users_reseau WHERE id = $1', [req.sessionUser.id]
          );
          const user = userRows.rows[0];
          if (user && addr.address) {
            const printfulItems = items
              .filter(i => i.printful_variant_id)
              .map(i => ({
                sync_variant_id: parseInt(i.printful_variant_id, 10),
                quantity: i.quantity || 1,
              }));

            if (printfulItems.length > 0) {
              const pfOrder = await printful.createOrder({
                recipientName: `${user.prenom} ${user.nom}`,
                recipientEmail: user.email,
                recipientAddress: addr.address || '',
                recipientCity: addr.city || '',
                recipientCountryCode: addr.country_code || 'FR',
                recipientZip: addr.zip || '',
                items: printfulItems,
              });

              await bq.updateOrderStatus(pool, order.id, {
                status: 'envoyee_à_printful',
                printful_order_id: String(pfOrder.id || pfOrder.order_id || ''),
                printful_status: pfOrder.status || 'pending',
              });

              // Refresh order with updated data
              refreshedOrder = await bq.getOrderById(pool, order.id);
            }
          }
        } catch (pfErr) {
          console.warn('[boutique] Printful auto-order failed, order saved locally:', pfErr.message);
        }
      }

      // Fire-and-forget confirmation email — failure does not block the order:201.
      (async () => {
        try {
          const userRows = await pool.query(
            'SELECT id, nom, prenom, email FROM users_reseau WHERE id = $1', [req.sessionUser.id]
          );
          const user = userRows.rows[0];
          if (!user) return;
          const finalOrder = refreshedOrder || await bq.getOrderById(pool, order.id);
          await sendOrderConfirmation(pool, finalOrder, user);
        } catch (err) {
          console.warn('[boutique] order confirmation email failed:', err.message);
        }
      })();

      if (refreshedOrder !== order) {
        return res.status(201).json({ ...refreshedOrder, printful_auto_sent: true });
      }
      res.status(201).json(order);
    } catch (err) {
      console.error(err);
      res.status(400).json({ error: err.message });
    }
  });

  // My orders (adhérent)
  router.get('/orders', requireReseauAuth, async (req, res) => {
    try {
      const orders = await bq.getOrders(pool, { user_id: req.sessionUser.id });
      res.json(orders);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  // My order detail (adhérent)
  router.get('/orders/:id', requireReseauAuth, async (req, res) => {
    try {
      const order = await bq.getOrderById(pool, parseInt(req.params.id, 10));
      if (!order) return res.status(404).json({ error: 'Commande introuvable' });
      if (order.user_id !== req.sessionUser.id && !['president', 'directrice', 'professeur'].includes(req.sessionUser.role)) {
        return res.status(403).json({ error: 'Accès non autorisé' });
      }
      res.json(order);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Erreur' });
    }
  });

  return router;
}

module.exports = { createBoutiqueRouter, createReseauBoutiqueRouter };