// routes/public-pages.js
// Serves static HTML pages for the public-facing CRM and admin UI.
// Does NOT own: API routes, auth logic, business logic.
// All routes are simple sendFile — no middleware, no auth.
// Extracted from server.js (was: 3338-3410+)
const path = require('path');

module.exports = function createPublicPagesRouter({ rootDir }) {
  const router = require('express').Router();

  router.get('/accept-invite', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'accept-invite.html'));
  });
  router.get('/onboarding', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'onboarding.html'));
  });
  router.get('/profile', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'profile.html'));
  });
  router.get('/login', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'login.html'));
  });
  router.get('/verify-2fa', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'verify-2fa.html'));
  });
  router.get('/users', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'users.html'));
  });
  router.get('/dashboard', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'dashboard.html'));
  });
  router.get('/crm', (_req, res) => {
    res.redirect('/dashboard?view=attendance');
  });
  router.get('/tarifs', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'tarifs.html'));
  });
  router.get('/schedule', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'schedule.html'));
  });
  router.get('/parents', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'parents.html'));
  });
  router.get('/admin/eleves', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin', 'eleves.html'));
  });
  router.get('/admin/eleves/:id', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin', 'eleves.html'));
  });
  // Unifies the previous /admin/media-config + /admin/email-config under a
  // single PRESIDENT-only hub. Auth is enforced client-side via the same
  // requireAuth(['PRÉSIDENT']) chain that the underlying API endpoints use —
  // a non-PRESIDENT who guesses the URL still sees /login.html after the
  // page's checkAuth() failure.
  router.get('/admin', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin', 'index.html'));
  });
  router.get('/admin/media-config', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin', 'media-config.html'));
  });
  router.get('/admin/email-config', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin', 'email-config.html'));
  });
  router.get('/admin/boutique.html', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin', 'boutique.html'));
  });
  router.get('/admin/boutique2.html', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin', 'boutique2.html'));
  });
  router.get('/admin/migration-formules', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'admin-migration-formules.html'));
  });
  router.get('/archives', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'archives.html'));
  });
  router.get('/sante-base', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'sante-base.html'));
  });
  router.get('/messagerie', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'messagerie.html'));
  });
  router.get('/fiche-prix', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'fiche-prix.html'));
  });
  router.get('/appel', (_req, res) => {
    res.sendFile(path.join(rootDir, 'public', 'appel.html'));
  });

  return router;
};