// routes/reseau-auth.js
// Auth endpoints for the student network app.
// Handles register/login/me/logout with real-time adhesion verification.
const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const ra = require('../db/reseau-accounts');

const SESSION_DURATION_DAYS = 30;

// ── Middleware: require valid session ────────────────────────────────────────
function requireAuth(pool, req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization header' });
  }
  const token = authHeader.slice(7);
  pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role, ur.eleve_id
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(result => {
    if (!result.rows[0]) {
      return res.status(401).json({ error: 'Session expired or invalid' });
    }
    const row = result.rows[0];
    req.sessionUser = {
      id: row.user_id,
      sessionId: row.session_id,
      email: row.email,
      nom: row.nom,
      prenom: row.prenom,
      role: row.role,
      eleveId: row.eleve_id,
    };
    next();
  }).catch(err => {
    console.error('Session validation error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });
}

module.exports = function createReseauAuthRouter({ pool }) {
  const router = express.Router();

  // ── POST /auth/register ──────────────────────────────────────────────────
  router.post('/register', async (req, res) => {
    try {
      const { email, password, nom, prenom, role, numero_adherent } = req.body;

      if (!email || !password || !nom || !prenom || !role) {
        return res.status(400).json({ error: 'Champs requis manquants' });
      }
      if (!['eleve', 'professeur', 'directrice', 'president'].includes(role)) {
        return res.status(400).json({ error: 'Role invalide' });
      }
      if (password.length < 8) {
        return res.status(400).json({ error: 'Mot de passe : minimum 8 caractères' });
      }

      const existing = await ra.findUserByEmail(pool, email);
      if (existing) {
        return res.status(409).json({ error: 'Un compte existe déjà avec cet email' });
      }

      let eleveId = null;

      if (role === 'eleve') {
        if (!numero_adherent) {
          return res.status(400).json({ error: 'Numéro d adhèrent requis pour les élèves' });
        }
        const student = await ra.findStudentByNumeroAdherent(pool, numero_adherent);
        if (!student) {
          return res.status(409).json({
            error: 'Numéro d adhèrent non trouvé ou adhésion inactive pour 2025/2026',
          });
        }
        eleveId = student.id;
      }

      const passwordHash = await bcrypt.hash(password, 10);
      const user = await ra.createUser(pool, {
        email: email.toLowerCase().trim(),
        passwordHash,
        nom: nom.trim(),
        prenom: prenom.trim(),
        role,
        eleveId,
      });

      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + SESSION_DURATION_DAYS * 86400 * 1000);
      await ra.createSession(pool, user.id, token, expiresAt);
      await ra.updateLastLogin(pool, user.id);

      return res.status(201).json({
        token,
        user: { id: user.id, nom: user.nom, prenom: user.prenom, role: user.role, email: user.email },
      });
    } catch (err) {
      console.error('Register error:', err);
      if (err.code === '23505') {
        return res.status(409).json({ error: 'Un compte existe déjà avec cet email' });
      }
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /auth/login ─────────────────────────────────────────────────────
  router.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email et mot de passe requis' });
      }

      const user = await ra.findUserByEmail(pool, email.toLowerCase().trim());
      if (!user) {
        return res.status(401).json({ error: 'Identifiants incorrects' });
      }

      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: 'Identifiants incorrects' });
      }

      if (user.role === 'eleve' && user.eleve_id) {
        const adhesionCheck = await pool.query(
          `SELECT 1 FROM students WHERE id = $1 AND statut_adhesion = 'Payée' AND '2025/2026' = ANY(saisons)`,
          [user.eleve_id]
        );
        if (adhesionCheck.rows.length === 0) {
          return res.status(403).json({
            error: 'Votre adhésion a expiré. Merci de la renouveler pour accéder à l application.',
          });
        }
      }

      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + SESSION_DURATION_DAYS * 86400 * 1000);
      await ra.createSession(pool, user.id, token, expiresAt);
      await ra.updateLastLogin(pool, user.id);

      return res.json({
        token,
        user: { id: user.id, nom: user.nom, prenom: user.prenom, role: user.role, email: user.email },
      });
    } catch (err) {
      console.error('Login error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /auth/me ──────────────────────────────────────────────────────────
  router.get('/me', (req, res, next) => requireAuth(pool, req, res, next), (req, res) => {
    res.json({ user: req.sessionUser });
  });

  // ── POST /auth/logout ─────────────────────────────────────────────────────
  router.post('/logout', (req, res, next) => requireAuth(pool, req, res, next), async (req, res) => {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.slice(7);
    await ra.deleteSession(pool, token);
    res.json({ message: 'Déconnexion réussie' });
  });

  return router;
};