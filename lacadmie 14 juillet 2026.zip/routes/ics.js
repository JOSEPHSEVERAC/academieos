// routes/ics.js
// Public ICS calendar endpoints — no auth required.
// Returns RFC 5545 VCALENDAR data for each class group in the active saison.

module.exports = function createIcsRouter({ pool }) {
  const router = require('express').Router();

  // ISO day (DB: 1=Mon … 7=Sun) → JS Date getDay() (0=Sun … 6=Sat)
  function dbDowToJs(dbDow) {
    return dbDow % 7; // 1→1, 2→2, …, 6→6, 7→0
  }

  // ISO BYDAY abbreviations indexed by DB day_of_week (1-based, Monday first)
  const BYDAY = ['', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU'];

  // Format a Date as YYYYMMDDTHHMMSS (local, no Z)
  function fmtLocal(date, hhmm) {
    const [hh, mm] = hhmm.split(':');
    const y = date.getFullYear();
    const mo = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}${mo}${d}T${hh}${mm}00`;
  }

  // Format a Date as YYYYMMDDTHHMMSSZ for UNTIL (UTC-ish end-of-day)
  function fmtUntil(date) {
    const y = date.getFullYear();
    const mo = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}${mo}${d}T235959Z`;
  }

  // Find the first date >= baseDate whose JS getDay() === targetJsDay
  function firstOccurrence(baseDate, targetJsDay) {
    const d = new Date(baseDate);
    d.setHours(0, 0, 0, 0);
    while (d.getDay() !== targetJsDay) {
      d.setDate(d.getDate() + 1);
    }
    return d;
  }

  // Fold long ICS lines at 75 octets per RFC 5545
  function foldLine(line) {
    const bytes = Buffer.from(line, 'utf8');
    if (bytes.length <= 75) return line;
    const chunks = [];
    let pos = 0;
    let first = true;
    while (pos < bytes.length) {
      const limit = first ? 75 : 74;
      chunks.push(bytes.slice(pos, pos + limit).toString('utf8'));
      pos += limit;
      first = false;
    }
    return chunks.join('\r\n ');
  }

  function buildIcs(cls, saison, occurrences) {
    const lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//LAcademie//FR',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      foldLine(`X-WR-CALNAME:${cls.discipline_name} — ${cls.location_city || cls.location_name}`),
    ];

    for (const first of occurrences) {
      const dtstart = fmtLocal(first, cls.start_time.substring(0, 5));
      const dtend = fmtLocal(first, cls.end_time ? cls.end_time.substring(0, 5) : cls.start_time.substring(0, 5));
      const until = fmtUntil(new Date(saison.date_fin));
      const byday = BYDAY[cls.day_of_week];

      const descParts = [];
      if (cls.teacher_name) descParts.push(`Professeur : ${cls.teacher_name}`);
      descParts.push(saison.nom);
      const description = descParts.join(' | ');

      lines.push(
        'BEGIN:VEVENT',
        `UID:class-${cls.id}-${dtstart}@lacademie`,
        `DTSTART:${dtstart}`,
        `DTEND:${dtend}`,
        `RRULE:FREQ=WEEKLY;BYDAY=${byday};UNTIL=${until}`,
        foldLine(`SUMMARY:${cls.discipline_name}${cls.secondary_label ? ' — ' + cls.secondary_label : ''}`),
        foldLine(`LOCATION:${cls.location_name}, ${cls.location_city || ''}`),
        foldLine(`DESCRIPTION:${description}`),
        'END:VEVENT',
      );
    }

    lines.push('END:VCALENDAR');
    return lines.join('\r\n') + '\r\n';
  }

  // GET /api/ics/classes — JSON index of all active classes with ics_url
  // Optional ?group= filters by discipline name (partial match, case-insensitive)
  router.get('/classes', async (req, res) => {
    try {
      const group = req.query.group || '';
      const hasFilter = group.trim().length > 0;

      const query = hasFilter
        ? `SELECT c.id, c.day_of_week, c.start_time, c.end_time, c.teacher_name,
                  d.name AS discipline_name,
                  l.name AS location_name, l.city AS location_city
           FROM classes c
           JOIN disciplines d ON c.discipline_id = d.id
           JOIN locations l ON c.location_id = l.id
           WHERE c.active = true AND d.name ILIKE $1
           ORDER BY c.day_of_week, c.start_time`
        : `SELECT c.id, c.day_of_week, c.start_time, c.end_time, c.teacher_name,
                  d.name AS discipline_name,
                  l.name AS location_name, l.city AS location_city
           FROM classes c
           JOIN disciplines d ON c.discipline_id = d.id
           JOIN locations l ON c.location_id = l.id
           WHERE c.active = true
           ORDER BY c.day_of_week, c.start_time`;

      const params = hasFilter ? ['%' + group + '%'] : [];
      const result = await pool.query(query, params);

      const classes = result.rows.map(cls => ({
        id: cls.id,
        discipline_name: cls.discipline_name,
        location_name: cls.location_name,
        location_city: cls.location_city,
        day_of_week: cls.day_of_week,
        start_time: cls.start_time,
        end_time: cls.end_time,
        teacher_name: cls.teacher_name,
        ics_url: `/api/ics/classes/${cls.id}.ics`,
        group: hasFilter ? group : null,
      }));

      res.json(classes);
    } catch (err) {
      console.error('[ics] Error fetching class index:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/ics/classes/:classId.ics — ICS calendar for a single class
  router.get('/classes/:classId.ics', async (req, res) => {
    try {
      const { classId } = req.params;

      const classRes = await pool.query(`
        SELECT c.id, c.day_of_week, c.start_time, c.end_time, c.teacher_name,
               c.secondary_label, c.active,
               d.name AS discipline_name,
               l.name AS location_name, l.city AS location_city
        FROM classes c
        JOIN disciplines d ON c.discipline_id = d.id
        JOIN locations l ON c.location_id = l.id
        WHERE c.id = $1
      `, [classId]);

      if (!classRes.rows.length || !classRes.rows[0].active) {
        return res.status(404).type('text/plain').send('Cours introuvable.');
      }

      const cls = classRes.rows[0];

      const saisonRes = await pool.query(
        'SELECT * FROM saisons WHERE active = TRUE LIMIT 1'
      );

      if (!saisonRes.rows.length) {
        return res.status(404).type('text/plain').send('Aucune saison active.');
      }

      const saison = saisonRes.rows[0];
      const baseDate = new Date(saison.date_debut);
      const endDate = new Date(saison.date_fin);

      if (isNaN(baseDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(404).type('text/plain').send('Dates de saison invalides.');
      }

      const jsDay = dbDowToJs(cls.day_of_week);
      const firstDate = firstOccurrence(baseDate, jsDay);

      if (firstDate > endDate) {
        return res.status(404).type('text/plain').send('Aucune occurrence dans la saison.');
      }

      const icsText = buildIcs(cls, saison, [firstDate]);

      res.set('Content-Type', 'text/calendar; charset=utf-8');
      res.set('Content-Disposition', `attachment; filename="cours-${classId}.ics"`);
      res.send(icsText);
    } catch (err) {
      console.error('[ics] Error generating ICS for class', req.params.classId, err);
      res.status(500).type('text/plain').send('Erreur serveur.');
    }
  });

  return router;
};
