// routes/admin-photos.js
// Admin-back-office photo upload and management — uses CRM session auth.
// Does NOT own: reseau student-facing routes (reseau-photos.js), auth (server.js).

const rp = require('../db/reseau-photos');
const storage = require('../services/storage');
const { uploadFile, isConfigured } = require('../services/r2');

function isR2Url(url) {
  return !!(url && url.startsWith(storage.publicHost()));
}

module.exports = function createAdminPhotosRouter({ pool, requireAuth }) {
  const router = require('express').Router();

  // All routes require CRM auth + direction role
  router.use((req, res, next) => {
    requireAuth(['PRÉSIDENT', 'DIRECTRICE', 'PROFESSEUR'])(req, res, (err) => {
      if (err) return next(err);
      next();
    });
  });

  // GET /api/admin/photos — list all photos (admin view, no visibility filter)
  router.get('/', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit, 10) || 50, 100);
      const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
      const offset = (page - 1) * limit;

      const [photos, total] = await Promise.all([
        rp.listPhotosAdmin(pool, {
          filterEvenementType: req.query.evenement_type || null,
          filterLieu: req.query.lieu || null,
          limit,
          offset,
        }),
        rp.countPhotosAdmin(pool, {
          filterEvenementType: req.query.evenement_type || null,
          filterLieu: req.query.lieu || null,
        }),
      ]);

      // Strip base64 from list (lazy load)
      const safe = photos.map(p => ({
        id: p.id,
        titre: p.titre,
        lieu: p.lieu,
        evenement_type: p.evenement_type,
        jour: p.jour,
        is_private: p.is_private,
        private_eleve_id: p.private_eleve_id,
        eleve_name: p.eleve_first_name && p.eleve_last_name
          ? `${p.eleve_first_name} ${p.eleve_last_name}`
          : null,
        created_at: p.created_at,
        uploader_nom: p.uploader_nom,
        uploader_prenom: p.uploader_prenom,
        has_image: !!p.image_url,
      }));

      res.json({ photos: safe, total, page, limit });
    } catch (err) {
      console.error('GET /api/admin/photos error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // POST /api/admin/photos — upload photo
  router.post('/', async (req, res) => {
    try {
      const { titre, lieu, evenement_type, jour, image_data, is_private, private_eleve_id } = req.body;

      if (!titre || !titre.trim()) {
        return res.status(400).json({ error: 'Titre requis' });
      }
      if (!jour) {
        return res.status(400).json({ error: 'Date requise' });
      }
      if (!image_data || !image_data.trim()) {
        return res.status(400).json({ error: 'Photo requise' });
      }
      if (!image_data.startsWith('data:image/')) {
        return res.status(400).json({ error: 'Format image invalide' });
      }
      if (image_data.length > 8 * 1024 * 1024) {
        return res.status(400).json({ error: 'Image trop volumineuse (max 8 Mo)' });
      }

      if (is_private && !private_eleve_id) {
        return res.status(400).json({ error: 'Sélectionnez un membre pour un portrait privé' });
      }

      // Already an R2 URL (re-upload of existing)?
      if (isR2Url(image_data)) {
        const photo = await rp.createPhoto(pool, {
          uploaderId: 0,
          uploaderRole: req.user.role,
          titre: titre.trim(),
          lieu: (lieu || '').trim(),
          evenementType: (evenement_type || '').trim(),
          jour,
          imageUrl: image_data,
          isPrivate: !!is_private,
          privateEleveId: is_private ? private_eleve_id : null,
        });
        return res.status(201).json({
          id: photo.id, titre: photo.titre, lieu: photo.lieu,
          evenement_type: photo.evenement_type, jour: photo.jour,
          is_private: photo.is_private, created_at: photo.created_at,
          has_image: true,
        });
      }

      if (!isConfigured()) {
        return res.status(503).json({
          error: 'Stockage photo non configuré.',
          detail: 'POLSIA_API_KEY non défini sur le serveur.',
        });
      }

      const mimeMatch = image_data.match(/^data:([^;]+);/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
      const ext = mimeType === 'image/png' ? 'png' : 'jpg';
      const rawBase64 = image_data.replace(/^data:[^;]+;base64,/, '');

      let imageUrl;
      try {
        imageUrl = await uploadFile(rawBase64, 'admin-photos', `photo.${ext}`, mimeType);
        console.log(`[admin-photos] Uploaded to R2 (${(rawBase64.length / 1024).toFixed(0)} KB base64) → ${imageUrl}`);
      } catch (r2Err) {
        console.warn('[admin-photos] R2 upload failed, storing as base64 in DB:', r2Err.message);
        // Platform bug: POLSIA_API_KEY rejected by image proxy (401 for all auth formats).
        // Fallback: store data URI directly in DB — photos still work.
        imageUrl = image_data;
      }

      const photo = await rp.createPhoto(pool, {
        uploaderId: 0,
        uploaderRole: req.user.role,
        titre: titre.trim(),
        lieu: (lieu || '').trim(),
        evenementType: (evenement_type || '').trim(),
        jour,
        imageUrl,
        isPrivate: !!is_private,
        privateEleveId: is_private ? private_eleve_id : null,
      });

      res.status(201).json({
        id: photo.id,
        titre: photo.titre,
        lieu: photo.lieu,
        evenement_type: photo.evenement_type,
        jour: photo.jour,
        is_private: photo.is_private,
        created_at: photo.created_at,
        has_image: true,
      });
    } catch (err) {
      console.error('POST /api/admin/photos error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/admin/photos/students/search — portrait autocomplete
  router.get('/students/search', async (req, res) => {
    try {
      const students = await rp.searchStudents(pool, req.query.q || '');
      res.json(students);
    } catch (err) {
      console.error('GET /api/admin/photos/students/search error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // DELETE /api/admin/photos/:id — delete photo
  router.delete('/:id', async (req, res) => {
    try {
      const photoId = parseInt(req.params.id, 10);
      if (isNaN(photoId)) return res.status(400).json({ error: 'ID invalide' });

      await rp.deletePhoto(pool, photoId);
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /api/admin/photos/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/admin/photos/:id/image — full-resolution image (lightbox / download)
  router.get('/:id/image', async (req, res) => {
    try {
      const photoId = parseInt(req.params.id, 10);
      if (isNaN(photoId)) return res.status(400).json({ error: 'ID invalide' });

      const photo = await rp.getPhotoByIdAdmin(pool, photoId);
      if (!photo) return res.status(404).json({ error: 'Photo introuvable' });
      if (!photo.image_url) return res.status(404).json({ error: 'Pas d image' });

      // R2 URL → return direct URL (browser loads from R2)
      if (isR2Url(photo.image_url)) {
        return res.json({ url: photo.image_url });
      }
      // Legacy base64 → return as data URI
      res.json({ image_data: photo.image_url });
    } catch (err) {
      console.error('GET /api/admin/photos/:id/image error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/admin/photos/:id/thumb — thumbnail (grid preview)
  router.get('/:id/thumb', async (req, res) => {
    try {
      const photoId = parseInt(req.params.id, 10);
      if (isNaN(photoId)) return res.status(400).json({ error: 'ID invalide' });

      const photo = await rp.getPhotoByIdAdmin(pool, photoId);
      if (!photo || !photo.image_url) {
        res.status(404).type('text/plain').send('Not found');
        return;
      }

      // R2 URL → redirect to R2 for the image
      if (isR2Url(photo.image_url)) {
        res.setHeader('Location', photo.image_url);
        return res.redirect(302, photo.image_url);
      }

      const mime = photo.image_url.startsWith('data:image/png')
        ? 'image/png' : 'image/jpeg';
      res.type(mime).send(photo.image_url);
    } catch (err) {
      console.error('GET /api/admin/photos/:id/thumb error:', err);
      res.status(500).type('text/plain').send('Error');
    }
  });

  return router;
};