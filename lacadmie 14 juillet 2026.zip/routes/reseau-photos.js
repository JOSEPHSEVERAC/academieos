// routes/reseau-photos.js
// Owns: reseau photo gallery — upload, listing, download, filters.
// Does NOT own: auth (reseau-auth.js), feed posts (reseau-feed.js), DMs (reseau-messaging.js).

const rp = require('../db/reseau-photos');
const me = require('../db/media-events');
const storage = require('../services/storage');
const { isConfigured } = require('../services/r2');
const { generateAndUpload } = require('../services/photo-thumb');
const { uploadLog } = require('../services/log-buffer');

// ── Middleware: require valid reseau session ──────────────────────────────────
function requireReseauAuth(pool, req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization' });
  }
  const token = authHeader.slice(7);
  pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(result => {
    if (!result.rows[0]) {
      return res.status(401).json({ error: 'Session expired or invalid' });
    }
    const row = result.rows[0];
    req.sessionUser = {
      id: row.user_id,
      sessionId: row.session_id,
      email: row.email,
      nom: row.nom,
      prenom: row.prenom,
      role: row.role,
    };
    next();
  }).catch(err => {
    console.error('Reseau photos session error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });
}

function requireDirection(req, res, next) {
  if (!['president', 'directrice', 'professeur'].includes(req.sessionUser.role)) {
    return res.status(403).json({ error: 'Action réservée à la direction' });
  }
  next();
}

function isR2Url(url) {
  try {
    const host = storage.publicHost();
    return !!(host && url && url.startsWith(host));
  } catch {
    return false;
  }
}

module.exports = function createReseauPhotosRouter({ pool }) {
  const router = require('express').Router();

  // All routes require auth
  router.use((req, res, next) => requireReseauAuth(pool, req, res, next));

  // ── GET /reseau/api/photos — list visible photos with filters ───────────────
  router.get('/', async (req, res) => {
    try {
      let filterEventId = null;
      if (req.query.event_id === 'none') {
        filterEventId = 0; // photos with no event_id
      } else if (req.query.event_id) {
        filterEventId = parseInt(req.query.event_id, 10) || null;
      }
      const photos = await rp.getPhotos(pool, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
        filterEvenementType: req.query.evenement_type || null,
        filterLieu: req.query.lieu || null,
        filterEventId,
      });
      // Strip base64 image_data from list response (lazy load)
      const safe = photos.map(p => ({
        id: p.id, titre: p.titre, lieu: p.lieu, evenement_type: p.evenement_type,
        jour: p.jour, is_private: p.is_private, created_at: p.created_at,
        event_id: p.event_id, description: p.description, ballet_title: p.ballet_title,
        uploader_nom: p.uploader_nom, uploader_prenom: p.uploader_prenom,
        thumbnail_url: p.thumbnail_url || null,
        has_image: !!p.image_url,
      }));
      res.json({ photos: safe });
    } catch (err) {
      console.error('GET /reseau/api/photos error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/photos/filters — available filter values ─────────────────
  router.get('/filters', async (req, res) => {
    try {
      const [evenementTypes, lieux] = await Promise.all([
        rp.getEvenementTypes(pool),
        rp.getLieux(pool),
      ]);
      res.json({ evenement_types: evenementTypes, lieux });
    } catch (err) {
      console.error('GET /reseau/api/photos/filters error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/photos — upload photo (direction only) ─────────────────
  router.post('/', requireDirection, async (req, res) => {
    const routeDeadline = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('upload_route_timeout')), 60000)
    );
    try {
      await Promise.race([
        (async () => {
          const { titre, lieu, evenement_type, jour, image_data, is_private, private_eleve_id, event_id, description, ballet_title } = req.body;
          uploadLog(`START — requête reçue, image_data: ${image_data ? image_data.length : 0} chars`);

          if (!titre || !titre.trim()) {
            if (res.headersSent) return;
            return res.status(400).json({ error: 'Titre requis' });
          }
          if (!jour) {
            if (res.headersSent) return;
            return res.status(400).json({ error: 'Date requise' });
          }
          if (!image_data || !image_data.trim()) {
            if (res.headersSent) return;
            return res.status(400).json({ error: 'Photo requise' });
          }
          if (!image_data.startsWith('data:image/')) {
            if (res.headersSent) return;
            return res.status(400).json({ error: 'Format image invalide' });
          }
          if (image_data.length > 8 * 1024 * 1024) {
            if (res.headersSent) return;
            return res.status(400).json({ error: 'Image trop volumineuse (max 8 Mo)' });
          }

          if (is_private && !private_eleve_id) {
            if (res.headersSent) return;
            return res.status(400).json({ error: 'Veuillez sélectionner un membre pour le portrait privé' });
          }

          // Resolve ballet_title → media_events.id before creating photo
          let resolvedEventId = event_id ? parseInt(event_id, 10) : null;
          if (resolvedEventId && ballet_title && ballet_title.trim()) {
            try {
              const balletId = await me.resolveBalletEntry(pool, resolvedEventId, ballet_title.trim(), req.sessionUser.id);
              if (balletId) resolvedEventId = balletId;
            } catch (balletErr) {
              console.warn('[reseau-photos] ballet resolve failed (non-fatal):', balletErr.message);
            }
          }

          // Already an R2 URL (re-upload of existing)?
          if (isR2Url(image_data)) {
            const photo = await rp.createPhoto(pool, {
              uploaderId: req.sessionUser.id,
              uploaderRole: req.sessionUser.role,
              titre: titre.trim(),
              lieu: (lieu || '').trim(),
              evenementType: (evenement_type || '').trim(),
              jour,
              imageUrl: image_data,
              isPrivate: !!is_private,
              privateEleveId: is_private ? private_eleve_id : null,
              eventId: resolvedEventId,
              description: description || null,
              balletTitle: ballet_title || null,
            });
            return res.status(201).json({
              id: photo.id, titre: photo.titre, lieu: photo.lieu,
              evenement_type: photo.evenement_type, jour: photo.jour,
              is_private: photo.is_private, created_at: photo.created_at,
              event_id: photo.event_id, description: photo.description, ballet_title: photo.ballet_title,
              has_image: true,
            });
          }

          if (!isConfigured()) {
            if (res.headersSent) return;
            return res.status(503).json({
              error: 'Stockage photo non configuré — contactez le support.',
              detail: 'POLSIA_API_KEY non défini sur le serveur.',
            });
          }

          const mimeMatch = image_data.match(/^data:([^;]+);/);
          const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
          const ext = mimeType === 'image/png' ? 'png' : 'jpg';
          const rawBase64 = image_data.replace(/^data:[^;]+;base64,/, '');

          let imageUrl;
          try {
            uploadLog(`Avant upload storage — taille buffer: ${Math.round(rawBase64.length * 3 / 4)} bytes`);
            imageUrl = await storage.upload(Buffer.from(rawBase64, 'base64'), `photos/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`, mimeType);
            console.log(`[reseau-photos] Uploaded to storage (${(rawBase64.length / 1024).toFixed(0)} KB base64) → ${imageUrl}`);
            uploadLog(`Upload storage terminé — URL: ${imageUrl}`);
          } catch (r2Err) {
            uploadLog(`ERREUR upload storage: ${r2Err.message}`);
            console.warn('[reseau-photos] R2 upload failed, storing as base64 in DB:', r2Err.message);
            // Platform bug: POLSIA_API_KEY rejected by image proxy (401 for all auth formats).
            // Fallback: store data URI directly in DB — photos still work.
            imageUrl = image_data;
          }

          const photo = await rp.createPhoto(pool, {
            uploaderId: req.sessionUser.id,
            uploaderRole: req.sessionUser.role,
            titre: titre.trim(),
            lieu: (lieu || '').trim(),
            evenementType: (evenement_type || '').trim(),
            jour,
            imageUrl,
            isPrivate: !!is_private,
            privateEleveId: is_private ? private_eleve_id : null,
            eventId: resolvedEventId,
            description: description || null,
            balletTitle: ballet_title || null,
          });
          uploadLog(`Photo créée en DB — id: ${photo.id}`);

          // Defer thumbnail generation to after response — never block res.json()
          if (image_data.startsWith('data:image/')) {
            setImmediate(async () => {
              try {
                const thumb = await generateAndUpload(image_data);
                if (thumb && thumb.jpeg) {
                  try {
                    await rp.updatePhotoThumbnail(pool, photo.id, thumb.r2Url, thumb.jpeg);
                  } catch (dbErr) {
                    console.warn('[reseau-photos] thumbnail DB write failed (non-fatal):', dbErr.message);
                  }
                }
              } catch (thumbErr) {
                console.warn('[reseau-photos] thumbnail generation failed (non-fatal):', thumbErr.message);
              }
            });
          }

          return res.status(201).json({
            id: photo.id, titre: photo.titre, lieu: photo.lieu,
            evenement_type: photo.evenement_type, jour: photo.jour,
            is_private: photo.is_private, created_at: photo.created_at,
            event_id: photo.event_id, description: photo.description, ballet_title: photo.ballet_title,
            has_image: true,
          });
        })(),
        routeDeadline,
      ]);
    } catch (err) {
      if (err.message === 'upload_route_timeout') {
        uploadLog('TIMEOUT 60s atteint — route timed out');
        console.error('[reseau-photos] route handler timed out after 60s');
        if (res.headersSent) return;
        return res.status(504).json({ error: "Délai d'upload expiré — veuillez réessayer" });
      }
      console.error('POST /reseau/api/photos error:', err);
      if (res.headersSent) return;
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/photos/:id/image — full-resolution image (for lightbox/download) ──
  router.get('/:id/image', async (req, res) => {
    try {
      const photoId = parseInt(req.params.id, 10);
      if (isNaN(photoId)) return res.status(400).json({ error: 'ID invalide' });

      const photo = await rp.getPhotoById(pool, photoId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });

      if (!photo) return res.status(404).json({ error: 'Photo introuvable' });
      if (!photo.image_url) return res.status(404).json({ error: 'Pas d image' });

      // R2 URL → build a data URI from the URL (front reads image_data consistently)
      // Alternative: redirect to R2 URL directly and update front to use .url
      if (isR2Url(photo.image_url)) {
        return res.json({ image_data: photo.image_url });
      }
      // Legacy base64 → return as data URI
      res.json({ image_data: photo.image_url });
    } catch (err) {
      console.error('GET /reseau/api/photos/:id/image error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── DELETE /reseau/api/photos/:id — delete photo (direction only) ───────────
  router.delete('/:id', requireDirection, async (req, res) => {
    try {
      const photoId = parseInt(req.params.id, 10);
      if (isNaN(photoId)) return res.status(400).json({ error: 'ID invalide' });

      await rp.deletePhoto(pool, photoId);
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /reseau/api/photos/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/photos/students/search — portrait autocomplete ───────────
  router.get('/students/search', async (req, res) => {
    try {
      const query = req.query.q || '';
      const students = await rp.searchStudents(pool, query);
      res.json(students);
    } catch (err) {
      console.error('GET /reseau/api/photos/students/search error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/photos/:id/thumbnail — serve thumbnail (for gallery grid) ──
  router.get('/:id/thumbnail', async (req, res) => {
    try {
      const photoId = parseInt(req.params.id, 10);
      if (isNaN(photoId)) return res.status(400).json({ error: 'ID invalide' });

      const photo = await rp.getPhotoById(pool, photoId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });
      if (!photo) return res.status(404).json({ error: 'Photo introuvable' });

      // Bytea thumbnail_data (persisted DB copy) → serve as JPEG
      if (photo.thumbnail_data) {
        res.setHeader('Content-Type', 'image/jpeg');
        res.setHeader('Cache-Control', 'public, max-age=86400');
        return res.send(Buffer.from(photo.thumbnail_data));
      }

      // R2 URL thumbnail → return the URL directly (browser loads from R2)
      if (photo.thumbnail_url && isR2Url(photo.thumbnail_url)) {
        return res.json({ image_data: photo.thumbnail_url });
      }

      // Legacy base64 full image as fallback (old photos without thumbnail)
      if (photo.image_url) {
        return res.json({ image_data: photo.image_url });
      }

      return res.status(404).json({ error: 'Pas de vignette' });
    } catch (err) {
      console.error('GET /:id/thumbnail error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};