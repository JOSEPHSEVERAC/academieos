// routes/media-events.js
// Owns: event folders for photo/video galleries (gala/dossier model).
// Organizes reseau_photos + reseau_videos into named events with optional ballet_title.
// Does NOT own: standalone photo/video galleries (reseau-photos.js, reseau-videos.js),
// events gallery (reseau-events.js), auth (reseau-auth.js).

const me = require('../db/media-events');

// ── Middleware: require valid reseau session ──────────────────────────────────
function requireReseauAuth(pool, req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization' });
  }
  const token = authHeader.slice(7);
  pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(result => {
    if (!result.rows[0]) {
      return res.status(401).json({ error: 'Session expired or invalid' });
    }
    const row = result.rows[0];
    req.sessionUser = {
      id: row.user_id,
      sessionId: row.session_id,
      email: row.email,
      nom: row.nom,
      prenom: row.prenom,
      role: row.role,
    };
    next();
  }).catch(err => {
    console.error('Media events session error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });
}

function requireDirection(req, res, next) {
  if (!['president', 'directrice', 'professeur'].includes(req.sessionUser.role)) {
    return res.status(403).json({ error: 'Action réservée à la direction' });
  }
  next();
}

module.exports = function createMediaEventsRouter({ pool }) {
  const router = require('express').Router();

  router.use((req, res, next) => requireReseauAuth(pool, req, res, next));

  // ── GET /api/reseau/media-events — list all events ─────────────────────────
  router.get('/', async (req, res) => {
    try {
      const events = await me.listEvents(pool);
      res.json({ events });
    } catch (err) {
      console.error('GET /api/reseau/media-events error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /api/reseau/media-events/:id — single event ─────────────────────────
  router.get('/:id', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const event = await me.getEventById(pool, eventId);
      if (!event) return res.status(404).json({ error: 'Événement introuvable' });

      res.json({ event });
    } catch (err) {
      console.error('GET /api/reseau/media-events/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /api/reseau/media-events — create event (direction only) ───────────
  router.post('/', requireDirection, async (req, res) => {
    try {
      const { title, description, date_event } = req.body;

      if (!title || !title.trim()) {
        return res.status(400).json({ error: 'Titre requis' });
      }

      const event = await me.createEvent(pool, {
        title: title.trim(),
        description: description || null,
        dateEvent: date_event || null,
        createdBy: req.sessionUser.id,
      });

      res.status(201).json({ event });
    } catch (err) {
      console.error('POST /api/reseau/media-events error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── PUT /api/reseau/media-events/:id — update event (direction only) ─────────
  router.put('/:id', requireDirection, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const { title, description, date_event } = req.body;

      if (title !== undefined && !title.trim()) {
        return res.status(400).json({ error: 'Titre requis' });
      }

      const event = await me.updateEvent(pool, eventId, {
        title: title !== undefined ? title.trim() : undefined,
        description: description !== undefined ? (description || null) : undefined,
        dateEvent: date_event !== undefined ? (date_event || null) : undefined,
      });

      if (!event) return res.status(404).json({ error: 'Événement introuvable' });
      res.json({ event });
    } catch (err) {
      console.error('PUT /api/reseau/media-events/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── DELETE /api/reseau/media-events/:id — delete event (direction only) ─────
  router.delete('/:id', requireDirection, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      await me.deleteEvent(pool, eventId);
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /api/reseau/media-events/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /api/reseau/media-events/:id/photos — photos in event ───────────────
  router.get('/:id/photos', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const photos = await me.getPhotosByEvent(pool, eventId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });

      const safe = photos.map(p => ({
        id: p.id, titre: p.titre, lieu: p.lieu, evenement_type: p.evenement_type,
        jour: p.jour, is_private: p.is_private, created_at: p.created_at,
        description: p.description, ballet_title: p.ballet_title,
        uploader_nom: p.uploader_nom, uploader_prenom: p.uploader_prenom,
        has_image: !!p.image_url,
      }));

      res.json({ photos: safe });
    } catch (err) {
      console.error('GET /api/reseau/media-events/:id/photos error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /api/reseau/media-events/:id/videos — videos in event ───────────────
  router.get('/:id/videos', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const videos = await me.getVideosByEvent(pool, eventId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });

      const safe = videos.map(v => ({
        id: v.id, titre: v.titre, lieu: v.lieu, evenement_type: v.evenement_type,
        jour: v.jour, type_mime: v.type_mime, is_private: v.is_private,
        created_at: v.created_at,
        description: v.description, ballet_title: v.ballet_title,
        uploader_nom: v.uploader_nom, uploader_prenom: v.uploader_prenom,
        has_video: !!v.video_url,
      }));

      res.json({ videos: safe });
    } catch (err) {
      console.error('GET /api/reseau/media-events/:id/videos error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /api/reseau/media-events/:id/ballets — ballet sub-folders ──────────
  router.get('/:id/ballets', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const ballets = await me.getBalletFolders(pool, eventId);
      res.json({ ballets });
    } catch (err) {
      console.error('GET /api/reseau/media-events/:id/ballets error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /api/reseau/media-events/:id/media — all media in event (combined) ─
  router.get('/:id/media', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      if (isNaN(eventId)) return res.status(400).json({ error: 'ID invalide' });

      const opts = { userId: req.sessionUser.id, userRole: req.sessionUser.role };
      const [photos, videos] = await Promise.all([
        me.getPhotosByEvent(pool, eventId, opts),
        me.getVideosByEvent(pool, eventId, opts),
      ]);

      const safePhotos = photos.map(p => ({
        id: p.id, type: 'photo', titre: p.titre, lieu: p.lieu,
        evenement_type: p.evenement_type, jour: p.jour, is_private: p.is_private,
        created_at: p.created_at, description: p.description, ballet_title: p.ballet_title,
        uploader_nom: p.uploader_nom, uploader_prenom: p.uploader_prenom,
        has_image: !!p.image_url,
      }));

      const safeVideos = videos.map(v => ({
        id: v.id, type: 'video', titre: v.titre, lieu: v.lieu,
        evenement_type: v.evenement_type, jour: v.jour, type_mime: v.type_mime,
        is_private: v.is_private, created_at: v.created_at,
        description: v.description, ballet_title: v.ballet_title,
        uploader_nom: v.uploader_nom, uploader_prenom: v.uploader_prenom,
        has_video: !!v.video_url,
        thumbnail_url: v.thumbnail_url || null,
      }));

      // Interleave by day (desc) then created_at (desc)
      const all = [...safePhotos, ...safeVideos].sort((a, b) => {
        const dayA = a.jour || '';
        const dayB = b.jour || '';
        if (dayA !== dayB) return dayA < dayB ? 1 : -1;
        return a.created_at < b.created_at ? 1 : -1;
      });

      res.json({ media: all });
    } catch (err) {
      console.error('GET /api/reseau/media-events/:id/media error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /api/reseau/media-events/:id/ballets/:balletId/media — media in ballet ─
  router.get('/:id/ballets/:balletId/media', async (req, res) => {
    try {
      const eventId = parseInt(req.params.id, 10);
      const balletId = parseInt(req.params.balletId, 10);
      if (isNaN(eventId) || isNaN(balletId)) return res.status(400).json({ error: 'ID invalide' });

      const opts = { userId: req.sessionUser.id, userRole: req.sessionUser.role };
      const [photos, videos] = await Promise.all([
        me.getPhotosByEvent(pool, balletId, opts),
        me.getVideosByEvent(pool, balletId, opts),
      ]);

      const safePhotos = photos.map(p => ({
        id: p.id, type: 'photo', titre: p.titre, lieu: p.lieu,
        evenement_type: p.evenement_type, jour: p.jour, is_private: p.is_private,
        created_at: p.created_at, description: p.description, ballet_title: p.ballet_title,
        uploader_nom: p.uploader_nom, uploader_prenom: p.uploader_prenom,
        has_image: !!p.image_url,
      }));

      const safeVideos = videos.map(v => ({
        id: v.id, type: 'video', titre: v.titre, lieu: v.lieu,
        evenement_type: v.evenement_type, jour: v.jour, type_mime: v.type_mime,
        is_private: v.is_private, created_at: v.created_at,
        description: v.description, ballet_title: v.ballet_title,
        uploader_nom: v.uploader_nom, uploader_prenom: v.uploader_prenom,
        has_video: !!v.video_url,
        thumbnail_url: v.thumbnail_url || null,
      }));

      const all = [...safePhotos, ...safeVideos].sort((a, b) => {
        const dayA = a.jour || '';
        const dayB = b.jour || '';
        if (dayA !== dayB) return dayA < dayB ? 1 : -1;
        return a.created_at < b.created_at ? 1 : -1;
      });

      res.json({ media: all });
    } catch (err) {
      console.error('GET /api/reseau/media-events/:id/ballets/:balletId/media error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};