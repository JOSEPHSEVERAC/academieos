// routes/admin-eleves.js
// Owns: Student profile pages — list, detail, update, attendance history.
// Does NOT own: CSV import, student export, student social auth, payment entry creation.

const express = require('express');

// Allowed fields for admin update — no financial fields (those go through payments routes)
const UPDATABLE_FIELDS = [
  'first_name', 'last_name', 'email', 'phone', 'birth_date', 'sexe',
  'address', 'postal_code', 'city',
  'parent_name', 'parent_phone', 'parent_email',
  'size_top', 'size_bottom', 'shoe_size',
  'droit_image', 'certificat_medical', 'payment_method',
  'numero_adherent', 'date_adhesion',
];

module.exports = function createAdminElevesRouter({ pool, requireAuth }) {
  const router = express.Router();

  // GET /api/admin/eleves — all students for the active saison (for the list view)
  router.get('/', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const saisonRes = await pool.query(`SELECT id FROM saisons WHERE active = TRUE LIMIT 1`);
      if (saisonRes.rows.length === 0) {
        return res.json({ eleves: [] });
      }
      const saisonId = saisonRes.rows[0].id;

      const result = await pool.query(`
        SELECT
          s.id,
          s.last_name,
          s.first_name,
          s.email,
          s.phone,
          s.birth_date,
          s.sexe,
          s.numero_adherent,
          s.date_adhesion,
          s.date_premiere_inscription,
          s.disciplines,
          s.formule,
          s.statut_adhesion,
          ss.adhesion_payee,
          ss.adhesion_incluse,
          f.label AS formule_label,
          f.periodicite,
          f.prix_cents
        FROM students s
        LEFT JOIN student_saisons ss ON ss.student_id = s.id AND ss.saison_id = $1
        LEFT JOIN formulas f ON f.id = ss.formule_id
        WHERE s.active = true
        ORDER BY s.last_name, s.first_name
      `, [saisonId]);

      res.json({ eleves: result.rows });
    } catch (err) {
      console.error('[/api/admin/eleves]', err.message);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // GET /api/admin/eleves/:id — full student profile
  router.get('/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const studentId = parseInt(req.params.id);
      if (isNaN(studentId)) return res.status(400).json({ error: 'ID invalide' });

      const saisonRes = await pool.query(`SELECT id FROM saisons WHERE active = TRUE LIMIT 1`);
      const saisonId = saisonRes.rows[0]?.id;

      // Main student record
      const studentRes = await pool.query(`
        SELECT
          s.id,
          s.last_name,
          s.first_name,
          s.email,
          s.phone,
          s.birth_date,
          s.sexe,
          s.numero_adherent,
          s.date_adhesion,
          s.date_premiere_inscription,
          s.disciplines,
          s.practice_levels,
          s.formule,
          s.payment_method,
          s.address,
          s.postal_code,
          s.city,
          s.parent_name,
          s.parent_phone,
          s.parent_email,
          s.size_top,
          s.size_bottom,
          s.shoe_size,
          s.droit_image,
          s.certificat_medical,
          s.statut_adhesion,
          s.active,
          s.saisons,
          ss.adhesion_payee,
          ss.adhesion_incluse,
          ss.amount_paid_cents,
          ss.date_resiliation,
          f.label AS formule_label,
          f.periodicite,
          f.prix_cents
        FROM students s
        LEFT JOIN student_saisons ss ON ss.student_id = s.id AND ss.saison_id = $1
        LEFT JOIN formulas f ON f.id = ss.formule_id
        WHERE s.id = $2
      `, [saisonId || null, studentId]);

      if (studentRes.rows.length === 0) {
        return res.status(404).json({ error: 'Élève non trouvé' });
      }

      const student = studentRes.rows[0];

      // Enrolled disciplines
      const discRes = await pool.query(`
        SELECT d.id, d.name, sd.practice_level
        FROM student_disciplines sd
        JOIN disciplines d ON d.id = sd.discipline_id
        WHERE sd.student_id = $1
        ORDER BY d.name
      `, [studentId]);

      // Payment history for active saison
      let payments = [];
      if (saisonId) {
        const payRes = await pool.query(`
          SELECT amount_cents, payment_date, payment_method, notes, created_by
          FROM payment_entries
          WHERE student_id = $1 AND saison_id = $2
          ORDER BY payment_date DESC
        `, [studentId, saisonId]);
        payments = payRes.rows;
      }

      // Attendance summary (last 30 days for active saison)
      let recentAttendance = null;
      if (saisonId) {
        const attRes = await pool.query(`
          SELECT COUNT(*) FILTER (WHERE status = 'present') AS present_count,
                 COUNT(*) FILTER (WHERE status = 'absent')   AS absent_count,
                 COUNT(*) FILTER (WHERE status = 'excused')  AS excused_count
          FROM attendance a
          JOIN classes c ON c.id = a.class_id
          WHERE a.student_id = $1 AND c.saison_id = $2
            AND a.date >= NOW() - INTERVAL '30 days'
        `, [studentId, saisonId]);
        recentAttendance = attRes.rows[0];
      }

      // Total paid (all payment entries)
      const totalPaidRes = await pool.query(`
        SELECT COALESCE(SUM(amount_cents), 0) AS total_cents
        FROM payment_entries WHERE student_id = $1
      `, [studentId]);
      const totalPaidCents = parseInt(totalPaidRes.rows[0].total_cents);

      res.json({
        student,
        disciplines: discRes.rows,
        payments,
        recentAttendance,
        totalPaidCents,
      });
    } catch (err) {
      console.error('[/api/admin/eleves/:id]', err.message);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // PUT /api/admin/eleves/:id — update student info (admin only, with audit log)
  router.put('/:id', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    const client = await pool.connect();
    try {
      const studentId = parseInt(req.params.id);
      if (isNaN(studentId)) return res.status(400).json({ error: 'ID invalide' });

      // Fetch current record for change detection
      const currentRes = await client.query('SELECT * FROM students WHERE id = $1', [studentId]);
      if (currentRes.rows.length === 0) {
        client.release();
        return res.status(404).json({ error: 'Élève non trouvé' });
      }
      const current = currentRes.rows[0];

      // Build SET clause from allowed fields only
      const updates = {};
      for (const field of UPDATABLE_FIELDS) {
        if (req.body[field] !== undefined) {
          if (field === 'droit_image' || field === 'certificat_medical') {
            updates[field] = req.body[field] === true || req.body[field] === 'true';
          } else {
            updates[field] = req.body[field] === '' ? null : req.body[field];
          }
        }
      }

      if (Object.keys(updates).length === 0) {
        client.release();
        return res.status(400).json({ error: 'Aucun champ à mettre à jour' });
      }

      // Required fields validation
      if (updates.first_name !== undefined && !updates.first_name) {
        client.release();
        return res.status(400).json({ error: 'Le prénom est obligatoire' });
      }
      if (updates.last_name !== undefined && !updates.last_name) {
        client.release();
        return res.status(400).json({ error: 'Le nom est obligatoire' });
      }

      await client.query('BEGIN');

      // Apply update
      const setCols = Object.keys(updates).map((k, i) => `${k} = $${i + 2}`).join(', ');
      const vals = [studentId, ...Object.values(updates)];
      await client.query(
        `UPDATE students SET ${setCols}, updated_at = NOW() WHERE id = $1`,
        vals
      );

      // Log each changed field to student_change_log
      const authorEmail = req.user?.email || 'admin';
      for (const [field, newVal] of Object.entries(updates)) {
        const oldVal = current[field];
        const oldStr = oldVal == null ? '' : String(oldVal);
        const newStr = newVal == null ? '' : String(newVal);
        if (oldStr !== newStr) {
          await client.query(
            `INSERT INTO student_change_log (student_id, field_name, old_value, new_value, changed_by, changed_at)
             VALUES ($1, $2, $3, $4, $5, NOW())`,
            [studentId, field, oldStr || null, newStr || null, authorEmail]
          );
        }
      }

      await client.query('COMMIT');
      res.json({ success: true });
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      console.error('[PUT /api/admin/eleves/:id]', err.message);
      res.status(500).json({ error: 'Erreur serveur' });
    } finally {
      client.release();
    }
  });

  // GET /api/admin/eleves/:id/attendance — full attendance history for the student
  router.get('/:id/attendance', requireAuth(['PRÉSIDENT', 'DIRECTRICE']), async (req, res) => {
    try {
      const studentId = parseInt(req.params.id);
      if (isNaN(studentId)) return res.status(400).json({ error: 'ID invalide' });

      const result = await pool.query(`
        SELECT
          a.date,
          a.status,
          c.day_of_week,
          c.start_time,
          d.name AS discipline_name,
          l.name AS location_name
        FROM attendance a
        JOIN classes c ON c.id = a.class_id
        JOIN disciplines d ON d.id = c.discipline_id
        LEFT JOIN locations l ON l.id = c.location_id
        WHERE a.student_id = $1
        ORDER BY a.date DESC, c.start_time DESC
        LIMIT 200
      `, [studentId]);

      res.json({ attendance: result.rows });
    } catch (err) {
      console.error('[GET /api/admin/eleves/:id/attendance]', err.message);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
}