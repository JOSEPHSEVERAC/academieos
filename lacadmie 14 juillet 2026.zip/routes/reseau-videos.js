// routes/reseau-videos.js
// Owns: reseau video gallery — upload, listing, stream, download, filters.
// Does NOT own: auth (reseau-auth.js), photos (reseau-photos.js), feed (reseau-feed.js).
// Storage: videos uploaded to R2 (object storage), DB stores only the public URL.

const path = require('path');
const fs = require('fs');
const multer = require('multer');
const rv = require('../db/reseau-videos');
const me = require('../db/media-events');
const { uploadBuffer, isConfigured, fetchAndStream } = require('../services/r2');
const storage = require('../services/storage');
const { extractAndUpload } = require('../services/thumbnail');
const cfStream = require('../services/cloudflare-stream');

function isR2Url(url) {
  return !!(url && url.startsWith(storage.publicHost()));
}

// ── Multer: write video files to disk first (NOT memory) ───────────────────────
// Heap explosion from memoryStorage + base64 round-trip: a 100MB video → 333MB
// peak usage (binary + base64 + re-decode) which OOMs on Render's 512MB limit.
// Disk storage keeps memory flat regardless of file size. Raw binary is uploaded
// to R2 via multipart (no base64 involved), then local file is deleted on success.
// On R2 failure: local path stored in DB → served via Express static at /videos/.

function ensureVideosDir(req, file, cb) {
  const dir = path.join(__dirname, '..', 'videos');
  fs.mkdirSync(dir, { recursive: true });
  cb(null, dir);
}

// Multer cap mirrors the browser file-picker gate (public/reseau-app.html
// MAX_VIDEO_UPLOAD_BYTES). The Cloudflare Stream TUS path is unaffected.
const MAX_VIDEO_UPLOAD_BYTES = 5 * 1024 * 1024 * 1024;

const videoMulter = multer({
  storage: multer.diskStorage({ destination: ensureVideosDir, filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.mp4';
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  }}),
  limits: { fileSize: MAX_VIDEO_UPLOAD_BYTES },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('video/')) {
      return cb(new Error('Seules les vidéos sont acceptées'), false);
    }
    cb(null, true);
  },
});

// ── Middleware: require valid reseau session ──────────────────────────────────
function requireReseauAuth(pool, req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization' });
  }
  const token = authHeader.slice(7);
  pool.query(
    `SELECT rs.id as session_id, rs.user_id, rs.expires_at,
            ur.id, ur.email, ur.nom, ur.prenom, ur.role
     FROM reseau_sessions rs
     JOIN users_reseau ur ON ur.id = rs.user_id
     WHERE rs.token = $1 AND rs.expires_at > NOW()`,
    [token]
  ).then(result => {
    if (!result.rows[0]) {
      return res.status(401).json({ error: 'Session expired or invalid' });
    }
    const row = result.rows[0];
    req.sessionUser = {
      id: row.user_id,
      sessionId: row.session_id,
      email: row.email,
      nom: row.nom,
      prenom: row.prenom,
      role: row.role,
    };
    next();
  }).catch(err => {
    console.error('Reseau videos session error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });
}

function requireDirection(req, res, next) {
  if (!['president', 'directrice', 'professeur'].includes(req.sessionUser.role)) {
    return res.status(403).json({ error: 'Action réservée à la direction' });
  }
  next();
}

module.exports = function createReseauVideosRouter({ pool }) {
  const router = require('express').Router();

  // All routes require auth
  router.use((req, res, next) => requireReseauAuth(pool, req, res, next));

  // ── GET /reseau/api/videos — list visible videos with filters ────────────────
  router.get('/', async (req, res) => {
    try {
      let filterEventId = null;
      if (req.query.event_id === 'none') {
        filterEventId = 0;
      } else if (req.query.event_id) {
        filterEventId = parseInt(req.query.event_id, 10) || null;
      }
      const videos = await rv.getVideos(pool, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
        filterEvenementType: req.query.evenement_type || null,
        filterLieu: req.query.lieu || null,
        filterEventId,
      });
      // Strip video data from list response (lazy load)
      const safe = videos.map(v => ({
        id: v.id, titre: v.titre, lieu: v.lieu, evenement_type: v.evenement_type,
        jour: v.jour, type_mime: v.type_mime, is_private: v.is_private, created_at: v.created_at,
        event_id: v.event_id, description: v.description, ballet_title: v.ballet_title,
        thumbnail_url: v.thumbnail_url || (v.cloudflare_uid ? `https://videodelivery.net/${v.cloudflare_uid}/thumbnails/thumbnail.jpg` : null),
        cloudflare_uid: v.cloudflare_uid || null,
        uploader_nom: v.uploader_nom, uploader_prenom: v.uploader_prenom,
        has_video: !!v.video_url,
      }));
      res.json({ videos: safe });
    } catch (err) {
      console.error('GET /reseau/api/videos error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/videos/filters — available filter values ──────────────────
  router.get('/filters', async (req, res) => {
    try {
      const [evenementTypes, lieux] = await Promise.all([
        rv.getEvenementTypes(pool),
        rv.getLieux(pool),
      ]);
      res.json({ evenement_types: evenementTypes, lieux });
    } catch (err) {
      console.error('GET /reseau/api/videos/filters error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/videos/upload-url ──────────────────────────────────────
  // Step 1 of the Cloudflare Stream direct-upload flow.
  // Reserves a Cloudflare Stream UID and creates a placeholder DB row so the
  // browser can PUT/POST the file bytes directly to the returned uploadURL
  // (TUS-compatible endpoint — no server-side streaming transit required).
  // If Cloudflare is not configured, returns 503 so the frontend can fall
  // back to the legacy POST / endpoint for small files.
  router.post('/upload-url', requireDirection, async (req, res) => {
    try {
      const { titre, lieu, evenement_type, jour, is_private, private_eleve_id, event_id, description, ballet_title } = req.body || {};

      if (!titre || !String(titre).trim()) return res.status(400).json({ error: 'Titre requis' });
      if (!jour) return res.status(400).json({ error: 'Date requise' });
      if ((is_private === true || is_private === '1') && !private_eleve_id) {
        return res.status(400).json({ error: 'Veuillez sélectionner un membre pour le portrait privé' });
      }

      if (!(await cfStream.isConfigured())) {
        return res.status(503).json({ error: 'Cloudflare Stream non configuré' });
      }

      // Resolve ballet_title → media_events.id before creating the row so the
      // placeholder gets the right event_id from the start.
      let resolvedEventId = event_id ? parseInt(event_id, 10) : null;
      if (resolvedEventId && ballet_title && String(ballet_title).trim()) {
        try {
          const balletId = await me.resolveBalletEntry(pool, resolvedEventId, String(ballet_title).trim(), req.sessionUser.id);
          if (balletId) resolvedEventId = balletId;
        } catch (balletErr) {
          console.warn('[reseau-videos] ballet resolve failed (non-fatal):', balletErr.message);
        }
      }

      const { uploadURL, uid } = await cfStream.createDirectUploadLocation();

      const placeholder = await rv.createVideo(pool, {
        uploaderId: req.sessionUser.id,
        uploaderRole: req.sessionUser.role,
        titre: String(titre).trim(),
        lieu: String(lieu || '').trim(),
        evenementType: String(evenement_type || '').trim(),
        jour,
        // Sentinel value — finalize endpoint swaps in the Stream metadata.
        videoUrl: 'cloudflare:pending',
        typeMime: 'video/mp4',
        isPrivate: !!(is_private === true || is_private === '1'),
        privateEleveId: (is_private === true || is_private === '1') ? private_eleve_id : null,
        eventId: resolvedEventId,
        description: description || null,
        balletTitle: ballet_title || null,
        thumbnailUrl: `https://videodelivery.net/${uid}/thumbnails/thumbnail.jpg`,
        cloudflareUid: uid,
        streamPlaybackId: uid,
      });

      res.json({ id: placeholder.id, uploadURL, uid });
    } catch (err) {
      console.error('POST /reseau/api/videos/upload-url error:', err);
      if (!res.headersSent) res.status(500).json({ error: "Échec de la préparation de l'upload Cloudflare" });
    }
  });

  // ── POST /reseau/api/videos/:id/finalize ────────────────────────────────────
  // Step 3 of the Cloudflare Stream direct-upload flow.
  // Polls Cloudflare Stream for readyToStream; on success, persists the
  // thumbnail URL and stream IDs. Deletes the placeholder row if Cloudflare
  // reports a permanent failure.
  router.post('/:id/finalize', requireDirection, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id, 10);
      if (isNaN(videoId)) return res.status(400).json({ error: 'ID invalide' });

      const video = await rv.getVideoById(pool, videoId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });
      if (!video || !video.cloudflare_uid) {
        return res.status(404).json({ error: 'Vidéo introuvable' });
      }

      let cfVideo = null;
      for (let attempt = 0; attempt < 5; attempt++) {
        try {
          cfVideo = await cfStream.getVideo(video.cloudflare_uid);
          if (cfVideo.readyToStream) break;
        } catch (cfErr) {
          console.warn(`[reseau-videos] finalize getVideo attempt ${attempt + 1} failed: ${cfErr.message}`);
        }
        await new Promise(r => setTimeout(r, 1500));
      }

      if (!cfVideo) {
        // No usable response from Cloudflare → leave the row in place but
        // surface an error. The user can retry finalize from the UI later.
        return res.status(502).json({ error: 'Cloudflare Stream ne répond pas — réessayez dans quelques instants' });
      }

      if (cfVideo.status === 'error') {
        await pool.query(`UPDATE reseau_videos SET is_deleted = true WHERE id = $1`, [videoId]);
        return res.status(502).json({ error: 'Cloudflare a rejeté la vidéo (erreur de traitement)' });
      }

      if (!cfVideo.readyToStream) {
        return res.status(202).json({ ok: false, status: cfVideo.status, message: 'Vidéo en cours de traitement' });
      }

      await rv.finalizeStreamVideo(pool, videoId, {
        cloudflareUid: video.cloudflare_uid,
        streamPlaybackId: video.cloudflare_uid,
        thumbnailUrl: cfVideo.thumbnail,
      });

      res.json({
        ok: true,
        status: cfVideo.status,
        duration: cfVideo.duration,
        thumbnail_url: cfVideo.thumbnail,
      });
    } catch (err) {
      console.error('POST /reseau/api/videos/:id/finalize error:', err);
      if (!res.headersSent) res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── POST /reseau/api/videos — upload video (direction only) ──────────────────
  // Legacy upload path used for small videos (< 200 MB) falling back from
  // Cloudflare Stream. Uses multipart/form-data (multer) to avoid base64
  // JSON bloat. Browser sends raw binary → server streams to R2 or falls
  // back to local disk.
  // IMPORTANT: every code path must call res.json() exactly once; no branch may exit
  // without a response. All early returns are guarded with if (!res.headersSent).
  router.post('/', requireDirection, videoMulter.single('video'), async (req, res) => {
    const routeDeadline = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('upload_route_timeout')), 60000)
    );
    try {
      await Promise.race([
        (async () => {
          const { titre, lieu, evenement_type, jour, is_private, private_eleve_id, event_id, description, ballet_title } = req.body;
          const file = req.file;

          if (!titre || !titre.trim()) {
            if (!res.headersSent) return res.status(400).json({ error: 'Titre requis' });
            return;
          }
          if (!jour) {
            if (!res.headersSent) return res.status(400).json({ error: 'Date requise' });
            return;
          }
          if (!file) {
            if (!res.headersSent) return res.status(400).json({ error: 'Vidéo requise' });
            return;
          }
          if (!file.mimetype.startsWith('video/')) {
            if (!res.headersSent) return res.status(400).json({ error: 'Format vidéo invalide' });
            return;
          }

          if ((is_private === true || is_private === '1') && !private_eleve_id) {
            if (!res.headersSent) return res.status(400).json({ error: 'Veuillez sélectionner un membre pour le portrait privé' });
            return;
          }

          // Resolve ballet_title → media_events.id before creating video
          let resolvedEventId = event_id ? parseInt(event_id, 10) : null;
          if (resolvedEventId && ballet_title && ballet_title.trim()) {
            try {
              const balletId = await me.resolveBalletEntry(pool, resolvedEventId, ballet_title.trim(), req.sessionUser.id);
              if (balletId) resolvedEventId = balletId;
            } catch (balletErr) {
              console.warn('[reseau-videos] ballet resolve failed (non-fatal):', balletErr.message);
            }
          }

          const resolvedMime = file.mimetype || 'video/mp4';
          const diskUrl = 'videos/' + path.basename(file.path);

          // Try R2 upload — on any failure fall back to local disk (don't return error).
          let videoUrl = diskUrl;

          if (isConfigured()) {
            try {
              const fileSize = file.size;
              if (!fileSize || fileSize > 1024 * 1024 * 1024) {
                console.warn(`[reseau-videos] file too large for R2 (${(fileSize / 1024 / 1024).toFixed(0)} MB) — storing locally`);
                videoUrl = diskUrl;
              } else {
                const rawBuffer = fs.readFileSync(file.path);
                const filename = path.basename(file.path);
                const uploadPromise = uploadBuffer(rawBuffer, filename, resolvedMime);
                const timeoutPromise = new Promise((_, reject) =>
                  setTimeout(() => reject(new Error('R2 upload timed out after 20s')), 20000)
                );
                videoUrl = await Promise.race([uploadPromise, timeoutPromise]);
                const uploadedMb = (file.size / 1024 / 1024).toFixed(1);
                console.log(`[reseau-videos] R2 upload ok — ${uploadedMb} MB → ${videoUrl}`);
              }
            } catch (r2Err) {
              console.warn(`[reseau-videos] R2 upload failed (${r2Err.message}) — falling back to local disk`);
              videoUrl = diskUrl;
            }
          }

          // Extract thumbnail at midpoint frame — safe fallback on any failure.
          // thumbnailData (bytea) is the reliable path; thumbnailUrl (R2) is best-effort.
          let thumbnailUrl = null;
          let thumbnailData = null;
          try {
            const result = await extractAndUpload(file.path);
            if (result && result.jpeg) {
              thumbnailData = result.jpeg;
              thumbnailUrl = result.r2Url || null;
            }
          } catch (thumbErr) {
            console.warn(`[reseau-videos] Thumbnail extraction failed (non-fatal): ${thumbErr.message}`);
          }

          let video;
          try {
            video = await rv.createVideo(pool, {
              uploaderId: req.sessionUser.id,
              uploaderRole: req.sessionUser.role,
              titre: titre.trim(),
              lieu: (lieu || '').trim(),
              evenementType: (evenement_type || '').trim(),
              jour,
              videoUrl,
              typeMime: resolvedMime,
              isPrivate: !!is_private,
              privateEleveId: is_private ? private_eleve_id : null,
              eventId: resolvedEventId,
              description: description || null,
              balletTitle: ballet_title || null,
              thumbnailUrl,
              thumbnailData,
            });
          } catch (dbErr) {
            console.warn('[reseau-videos] createVideo failed — retrying without balletTitle:', dbErr.message);
            video = await rv.createVideo(pool, {
              uploaderId: req.sessionUser.id,
              uploaderRole: req.sessionUser.role,
              titre: titre.trim(),
              lieu: (lieu || '').trim(),
              evenementType: (evenement_type || '').trim(),
              jour,
              videoUrl,
              typeMime: resolvedMime,
              isPrivate: !!is_private,
              privateEleveId: is_private ? private_eleve_id : null,
              eventId: resolvedEventId,
              description: description || null,
              balletTitle: null,
              thumbnailUrl,
              thumbnailData,
            });
          }

          if (!res.headersSent) {
            return res.status(201).json({
              id: video.id, titre: video.titre, lieu: video.lieu,
              evenement_type: video.evenement_type, jour: video.jour,
              type_mime: video.type_mime, is_private: video.is_private,
              event_id: video.event_id, description: video.description, ballet_title: video.ballet_title,
              thumbnail_url: video.thumbnail_url,
              created_at: video.created_at, has_video: true,
            });
          }
        })(),
        routeDeadline,
      ]);
    } catch (err) {
      if (err.message === 'upload_route_timeout') {
        console.error('[reseau-videos] route handler timed out after 60s');
        if (!res.headersSent) res.status(504).json({ error: "Délai d'upload expiré — veuillez réessayer" });
        return;
      }
      console.error('[reseau-videos] POST /api/videos unhandled error:', err);
      if (!res.headersSent) res.status(500).json({ error: 'Erreur serveur' });
    } finally {
      // Always clean up the temp video file written by multer.
      if (req.file && req.file.path && fs.existsSync(req.file.path)) {
        try { fs.unlinkSync(req.file.path); } catch (_) {}
      }
    }
  });

  // ── GET /reseau/api/videos/:id/stream — stream video data (for player) ─────────
  // R2 URLs → redirect to R2 (browser handles streaming)
  // Local disk paths → pipe file directly (bypasses static handler for absolute Render paths)
  // Legacy base64 → decode and stream
  router.get('/:id/stream', async (req, res) => {
    try {
      const videoId = parseInt(req.params.id, 10);
      if (isNaN(videoId)) return res.status(400).json({ error: 'ID invalide' });

      const video = await rv.getVideoById(pool, videoId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });

      if (!video) return res.status(404).json({ error: 'Vidéo introuvable' });
      if (!video.video_url) return res.status(404).json({ error: 'Pas de vidéo' });

      // Cloudflare Stream → redirect to the public /downloads/default.mp4 endpoint.
      // The frontend uses the Stream iframe for HLS playback; this branch keeps
      // the legacy <video src=/stream> tag working as a single-bitrate fallback.
      if (video.cloudflare_uid) {
        return res.redirect(302, `https://videodelivery.net/${video.cloudflare_uid}/downloads/default.mp4`);
      }

      const contentType = video.type_mime || 'video/mp4';
      const filename = (video.titre || 'video').replace(/[^a-zA-Z0-9_\u00C0-\u017F -]/g, '_') + '.mp4';
      const range = req.headers.range;

      // R2 URL → stream server-side (R2 requires auth, redirect would expose broken URLs)
      if (video.video_url.startsWith(storage.publicHost())) {
        try {
          await fetchAndStream(video.video_url, res, {
            contentType,
            filename: (video.titre || 'video') + '.mp4',
            range: range ? { start: parseInt(range.split('-')[0]), end: range.split('-')[1] ? parseInt(range.split('-')[1]) : undefined } : null,
          });
        } catch (err) {
          console.error('[stream] R2 fetch failed:', err.message);
          return res.status(502).json({ error: 'Impossible de lire la vidéo depuis le stockage' });
        }
        return;
      }

      // Local disk path (relative: "videos/foo.mp4" or "/videos/foo.mp4")
      if (video.video_url.startsWith('videos/') || video.video_url.startsWith('/videos/')) {
        const filePath = path.join(__dirname, '..', video.video_url.replace(/^\/+/, ''));
        if (fs.existsSync(filePath)) {
          const stat = fs.statSync(filePath);
          res.setHeader('Content-Type', contentType);
          res.setHeader('Accept-Ranges', 'bytes');
          res.setHeader('Cache-Control', 'private, max-age=3600');
          if (range) {
            const [start, end] = range.replace('bytes=', '').split('-').map(Number);
            const chunkEnd = end ?? stat.size - 1;
            res.setHeader('Content-Range', `bytes ${start}-${chunkEnd}/${stat.size}`);
            res.setHeader('Content-Length', chunkEnd - start + 1);
            res.status(206);
            fs.createReadStream(filePath, { start, end: chunkEnd }).pipe(res);
          } else {
            res.setHeader('Content-Length', stat.size);
            fs.createReadStream(filePath).pipe(res);
          }
          return;
        }
        // File missing — fall through to DB check
      }

      // Absolute Render path: /opt/render/project/src/videos/foo.mp4 → pipe directly if present
      if (video.video_url.startsWith('/opt/render/project/src/')) {
        if (fs.existsSync(video.video_url)) {
          const stat = fs.statSync(video.video_url);
          res.setHeader('Content-Type', contentType);
          res.setHeader('Accept-Ranges', 'bytes');
          res.setHeader('Cache-Control', 'private, max-age=3600');
          if (range) {
            const [start, end] = range.replace('bytes=', '').split('-').map(Number);
            const chunkEnd = end ?? stat.size - 1;
            res.setHeader('Content-Range', `bytes ${start}-${chunkEnd}/${stat.size}`);
            res.setHeader('Content-Length', chunkEnd - start + 1);
            res.status(206);
            fs.createReadStream(video.video_url, { start, end: chunkEnd }).pipe(res);
          } else {
            res.setHeader('Content-Length', stat.size);
            fs.createReadStream(video.video_url).pipe(res);
          }
          return;
        }
        // File missing — fall through to DB check
      }

      // Legacy base64 → decode and stream
      if (video.video_url.startsWith('data:')) {
        const rawBase64 = video.video_url.replace(/^data:[^;]+;base64,/, '');
        const buffer = Buffer.from(rawBase64, 'base64');
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Length', buffer.length);
        res.setHeader('Accept-Ranges', 'none');
        res.setHeader('Cache-Control', 'private, max-age=3600');
        res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
        res.send(buffer);
        return;
      }

      return res.status(404).json({ error: 'Vidéo introuvable — fichier absent et aucune copie en base' });
    } catch (err) {
      console.error('GET /reseau/api/videos/:id/stream error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/videos/:id/thumbnail — video thumbnail (bytea or R2 URL) ───────
  // thumbnail_data (bytea, persisted) → serves directly
  // thumbnail_url pointing to R2 → returns R2 URL in image_data
  // thumbnail_url pointing to local disk → reads file and returns bytea
  router.get('/:id/thumbnail', async (req, res) => {
    try {
      const videoId = parseInt(req.params.id, 10);
      if (isNaN(videoId)) return res.status(400).json({ error: 'ID invalide' });

      const video = await rv.getVideoById(pool, videoId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });
      if (!video) return res.status(404).json({ error: 'Vidéo introuvable' });

      // R2 URL thumbnail → return the URL directly (browser loads from R2)
      if (video.thumbnail_url && isR2Url(video.thumbnail_url)) {
        return res.json({ image_data: video.thumbnail_url });
      }

      // Bytea thumbnail_data (persisted DB copy) → serve as JPEG
      if (video.thumbnail_data) {
        res.setHeader('Content-Type', 'image/jpeg');
        res.setHeader('Cache-Control', 'public, max-age=86400');
        return res.send(Buffer.from(video.thumbnail_data));
      }

      // Local disk thumbnail (ephemeral on Render) → try to read, fall back to missing
      if (video.thumbnail_url && (video.thumbnail_url.startsWith('videos/') || video.thumbnail_url.startsWith('/videos/'))) {
        const thumbPath = path.join(__dirname, '..', video.thumbnail_url.replace(/^\/+/, ''));
        if (fs.existsSync(thumbPath)) {
          res.setHeader('Content-Type', 'image/jpeg');
          res.setHeader('Cache-Control', 'public, max-age=86400');
          return res.sendFile(thumbPath);
        }
      }
      if (video.thumbnail_url && video.thumbnail_url.startsWith('/opt/render/project/src/')) {
        if (fs.existsSync(video.thumbnail_url)) {
          res.setHeader('Content-Type', 'image/jpeg');
          res.setHeader('Cache-Control', 'public, max-age=86400');
          return res.sendFile(video.thumbnail_url);
        }
      }

      return res.status(404).json({ error: 'Aucune vignette disponible' });
    } catch (err) {
      console.error('GET /reseau/api/videos/:id/thumbnail error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/videos/:id/download — download original file ──────────────
  // R2 URLs → stream server-side (R2 requires auth, redirect would fail)
  // Local disk paths → serve from filesystem
  // Legacy base64 → decode and serve as download
  router.get('/:id/download', async (req, res) => {
    try {
      const videoId = parseInt(req.params.id, 10);
      if (isNaN(videoId)) return res.status(400).json({ error: 'ID invalide' });

      const video = await rv.getVideoById(pool, videoId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });

      if (!video) return res.status(404).json({ error: 'Vidéo introuvable' });
      if (!video.video_url) return res.status(404).json({ error: 'Pas de vidéo' });

      // Cloudflare Stream → redirect to the public download mirror.
      if (video.cloudflare_uid) {
        return res.redirect(302, `https://videodelivery.net/${video.cloudflare_uid}/downloads/default.mp4`);
      }

      const safeName = (video.titre || 'video').replace(/[^a-zA-Z0-9_\u00C0-\u017F -]/g, '_') + '.mp4';

      // R2 URL → stream server-side as attachment
      if (video.video_url.startsWith(storage.publicHost())) {
        try {
          await fetchAndStream(video.video_url, res, {
            contentType: video.type_mime || 'video/mp4',
            filename: safeName,
            range: null,
          });
        } catch (err) {
          console.error('[download] R2 fetch failed:', err.message);
          return res.status(502).json({ error: 'Impossible de télécharger la vidéo' });
        }
        return;
      }

      // Local disk path (relative: "videos/foo.mp4" or "/videos/foo.mp4")
      if (video.video_url.startsWith('videos/') || video.video_url.startsWith('/videos/')) {
        const filePath = path.join(__dirname, '..', video.video_url.replace(/^\/+/, ''));
        if (fs.existsSync(filePath)) {
          return res.download(filePath, (video.titre || 'video') + '.mp4');
        }
        // File missing — fall through to DB check
      }

      // Absolute Render path: /opt/render/project/src/videos/foo.mp4
      if (video.video_url.startsWith('/opt/render/project/src/')) {
        if (fs.existsSync(video.video_url)) {
          return res.download(video.video_url, (video.titre || 'video') + '.mp4');
        }
        // File missing — fall through to DB check
      }

      // DB bytea fallback for download
      if (video.video_data) {
        const buffer = Buffer.from(video.video_data);
        res.setHeader('Content-Type', video.type_mime || 'video/mp4');
        res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
        res.setHeader('Content-Length', buffer.length);
        res.setHeader('Cache-Control', 'private, max-age=3600');
        res.send(buffer);
        return;
      }

      // Legacy base64 → decode and serve
      if (video.video_url.startsWith('data:')) {
        const rawBase64 = video.video_url.replace(/^data:[^;]+;base64,/, '');
        const buffer = Buffer.from(rawBase64, 'base64');
        res.setHeader('Content-Type', video.type_mime || 'video/mp4');
        res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
        res.setHeader('Content-Length', buffer.length);
        res.setHeader('Cache-Control', 'private, max-age=3600');
        res.send(buffer);
        return;
      }

      return res.status(404).json({ error: 'Vidéo introuvable — fichier absent et aucune copie en base' });
    } catch (err) {
      console.error('GET /reseau/api/videos/:id/download error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── DELETE /reseau/api/videos/:id — delete video (direction only) ─────────────
  router.delete('/:id', requireDirection, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id, 10);
      if (isNaN(videoId)) return res.status(400).json({ error: 'ID invalide' });

      const video = await rv.getVideoById(pool, videoId, {
        userId: req.sessionUser.id,
        userRole: req.sessionUser.role,
      });
      await rv.deleteVideo(pool, videoId);

      // Best-effort Cloudflare Stream cleanup — failures are logged but the
      // DB row is already soft-deleted, so we never block the response.
      if (video && video.cloudflare_uid && (await cfStream.isConfigured())) {
        cfStream.deleteVideo(video.cloudflare_uid).catch(err => {
          console.warn(`[reseau-videos] CF stream cleanup failed for ${video.cloudflare_uid}: ${err.message}`);
        });
      }
      res.json({ ok: true });
    } catch (err) {
      console.error('DELETE /reseau/api/videos/:id error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // ── GET /reseau/api/videos/students/search — portrait autocomplete ────────────
  router.get('/students/search', async (req, res) => {
    try {
      const query = req.query.q || '';
      const students = await rv.searchStudents(pool, query);
      res.json(students);
    } catch (err) {
      console.error('GET /reseau/api/videos/students/search error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};