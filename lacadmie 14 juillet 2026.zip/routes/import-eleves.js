// Import eleves — CSV bulk import via browser textarea
// Owns: POST /api/import-eleves (DELETE + re-import + student_disciplines + student_saisons)
// Does NOT own: standalone import script, student CRUD

const express = require('express');
const router = express.Router();

// Discipline name → id (from disciplines table)
const DISCIPLINE_MAP = {
  'Classique': 1,
  'Jazz': 2,
  'Jazz Latino': 3,
  'Hip-Hop / Break': 4,
  'Eveil / Initiation': 7,
  'Pilates': 10,
  'Stretching': 9,
  'Ragga': 8,
  'Barre à Terre': 11,
  'Pilates PM': 5,
  'Ragga Cardio': 6,
};

module.exports = function createImportElevesRouter({ pool, requireAuth }) {

  // Validates DD/MM/YYYY and rejects impossible dates (day 32, month 13, year 0000)
  function parseDate(str) {
    if (!str || str.trim() === '') return { value: null, raw: str };
    const parts = str.trim().split('/');
    if (parts.length !== 3) return { value: null, raw: str, error: 'Format attendu : JJ/MM/AAAA' };
    let [day, month, year] = parts;
    day = parseInt(day, 10);
    month = parseInt(month, 10);
    year = parseInt(year, 10);
    if (isNaN(day) || isNaN(month) || isNaN(year)) return { value: null, raw: str, error: 'Date invalide (caractères non numériques)' };
    if (month < 1 || month > 12) return { value: null, raw: str, error: `Mois ${month} invalide (doit être 1-12)` };
    const daysInMonth = new Date(year, month, 0).getDate();
    if (day < 1 || day > daysInMonth) return { value: null, raw: str, error: `Jour ${day} invalide pour le mois ${month}` };
    if (year < 1900 || year > 2100) return { value: null, raw: str, error: `Année ${year} hors plage (1900-2100)` };
    return { value: `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`, raw: str };
  }

  function parseArray(str) {
    if (!str || str.trim() === '') return null;
    return str.split(',').map(s => s.trim()).filter(Boolean);
  }

  function parseCSVLine(line) {
    return line.split(';').map(s => s.trim());
  }

  function validateEmail(str) {
    if (!str || str.trim() === '') return null; // optional field
    const re = /^[^\f\n\r\t @]+@[^\f\n\r\t @]+\/[^\f\n\r\t @]+$/;
    if (!re.test(str.trim())) return 'Format email invalide';
    return null;
  }

  function validatePhone(str) {
    if (!str || str.trim() === '') return null;
    const cleaned = str.split('').filter(c => '0123456789'.includes(c)).join('');
    if (!/^[0-9]{10}$/.test(cleaned)) return 'Numéro de téléphone invalide (attendu : 10 chiffres)';
    return null;
  }

  // Returns error message or null
  function validateDiscipline(name) {
    const trimmed = name.trim();
    if (DISCIPLINE_MAP[trimmed] !== undefined) return null;
    // Find closest match for hint
    const keys = Object.keys(DISCIPLINE_MAP);
    let best = null, bestScore = -1;
    for (const k of keys) {
      const s = trimmed.toLowerCase();
      const ks = k.toLowerCase();
      if (ks === s) return null;
      const score = [...s].filter(c => ks.includes(c)).length;
      if (score > bestScore) { bestScore = score; best = k; }
    }
    return `Discipline "${trimmed}" non reconnue — suggestion : "${best}"`;
  }

  // POST /api/import-eleves — import CSV from textarea body
  router.post('/', requireAuth(['PRÉSIDENT']), async (req, res) => {
    const { csv } = req.body;

    if (!csv || typeof csv !== 'string') {
      return res.status(400).json({ error: 'Champ "csv" requis' });
    }

    const lines = csv.split('\n').filter(l => l.trim() !== '');
    if (lines.length < 2) {
      return res.status(400).json({ error: 'Le CSV doit contenir un header et au moins une ligne de données' });
    }

    const header = parseCSVLine(lines[0]);

    // Column index mapping
    const COL = {
      Nom: header.indexOf('Nom'),
      Prenom: header.indexOf('Prénom'),
      Email: header.indexOf('Email'),
      Telephone: header.indexOf('Téléphone'),
      DateNaissance: header.indexOf('Date de naissance'),
      ResponsableLegal: header.indexOf('Responsable légal'),
      TelResponsable: header.indexOf('Tél. responsable légal'),
      EmailResponsable: header.indexOf('Email responsable légal'),
      Adresse: header.indexOf('Adresse'),
      CodePostal: header.indexOf('Code postal'),
      Ville: header.indexOf('Ville'),
      Disciplines: header.indexOf('Disciplines'),
      NiveauxPratique: header.indexOf('Niveaux de pratique'),
      Formule: header.indexOf('Formule tarifaire'),
      ModePaiement: header.indexOf('Mode de paiement'),
      TailleHaut: header.indexOf('Taille haut'),
      TailleBas: header.indexOf('Taille bas'),
      Pointure: header.indexOf('Pointure'),
      DatePremiereInscription: header.indexOf('Date 1ère inscription'),
      Saisons: header.indexOf("Saison(s)"),
      StatutAdhesion: header.indexOf('Statut adhésion'),
    };

    const missing = Object.entries(COL).filter(([, idx]) => idx === -1).map(([name]) => name);
    if (missing.length > 0) {
      return res.status(400).json({
        error: `Colonnes manquantes dans le CSV: ${missing.join(', ')}`
      });
    }

    // --- PHASE 1: DRY RUN — collect all row-level errors before touching DB ---
    const rowErrors = [];
    const seenRows = new Map(); // dedup within CSV
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (!line.trim()) continue;

      const cols = parseCSVLine(line);
      const get = (idx) => (cols[idx] || '').trim();

      const nom = get(COL.Nom);
      const prenom = get(COL.Prenom);
      const birthDateRaw = get(COL.DateNaissance);

      // Missing required fields (fatal — row skipped, no insert)
      if (!nom || !prenom) {
        rowErrors.push({ row: i + 1, field: 'Nom / Prénom', error: 'Nom ou prénom manquant — ligne ignorée' });
        continue;
      }

      // Duplicate within CSV (same Nom + Prénom + birth date)
      const dedupKey = `${nom}|${prenom}|${birthDateRaw}`;
      if (seenRows.has(dedupKey)) {
        rowErrors.push({ row: i + 1, field: 'Doublon', error: `Doublon détecté — ligne ${seenRows.get(dedupKey)} a déjà "${nom} ${prenom}" (${birthDateRaw})` });
      } else {
        seenRows.set(dedupKey, i + 1);
      }

      // Malformed date
      if (birthDateRaw) {
        const parsed = parseDate(birthDateRaw);
        if (parsed.error) {
          rowErrors.push({ row: i + 1, field: 'Date de naissance', error: parsed.error });
        }
      }

      const datePremRaw = get(COL.DatePremiereInscription);
      if (datePremRaw) {
        const parsed = parseDate(datePremRaw);
        if (parsed.error) {
          rowErrors.push({ row: i + 1, field: 'Date 1ère inscription', error: parsed.error });
        }
      }

      // Invalid email formats
      const email = get(COL.Email);
      if (email) {
        const emailErr = validateEmail(email);
        if (emailErr) rowErrors.push({ row: i + 1, field: 'Email', error: emailErr });
      }
      const emailResp = get(COL.EmailResponsable);
      if (emailResp) {
        const emailErr = validateEmail(emailResp);
        if (emailErr) rowErrors.push({ row: i + 1, field: 'Email responsable légal', error: emailErr });
      }

      // Invalid phone formats
      const phone = get(COL.Telephone);
      if (phone) {
        const phoneErr = validatePhone(phone);
        if (phoneErr) rowErrors.push({ row: i + 1, field: 'Téléphone', error: phoneErr });
      }
      const telResp = get(COL.TelResponsable);
      if (telResp) {
        const phoneErr = validatePhone(telResp);
        if (phoneErr) rowErrors.push({ row: i + 1, field: 'Tél. responsable légal', error: phoneErr });
      }

      // Unrecognized disciplines
      const discNames = parseArray(get(COL.Disciplines)) || [];
      for (const d of discNames) {
        const discErr = validateDiscipline(d);
        if (discErr) rowErrors.push({ row: i + 1, field: 'Disciplines', error: discErr });
      }

      // Year out of plausible range (warn non-fatal, insert anyway)
      if (birthDateRaw) {
        const parts = birthDateRaw.trim().split('/');
        if (parts.length === 3) {
          const year = parseInt(parts[2], 10);
          if (!isNaN(year) && (year < 1930 || year > 2030)) {
            rowErrors.push({ row: i + 1, field: 'Date de naissance', error: `Année ${year} inhabituelle — vérifier la date (${birthDateRaw})` });
          }
        }
      }
    }

    const totalDataRows = lines.length - 1;

    // If any fatal errors (missing nom/prenom), abort — no DB changes
    const fatalErrors = rowErrors.filter(e => e.field === 'Nom / Prénom' || e.field === 'Doublon');
    if (fatalErrors.length > 0) {
      return res.status(400).json({
        error: 'Import bloqué — erreurs détectées dans le CSV',
        totalRows: totalDataRows,
        errors: rowErrors.length,
        errorDetails: rowErrors,
        duplicateInCSV: rowErrors.filter(e => e.field === 'Doublon').length,
        unknownDisciplines: rowErrors.filter(e => e.field === 'Disciplines').length,
      });
    }

    // --- PHASE 2: IMPORT ---
    const client = await pool.connect();
    let inserted = 0;
    let disciplinesInserted = 0;
    let skipped = 0;
    let committed = false;

    try {
      await client.query('BEGIN');
      // Clear existing records (TRUNCATE not allowed via raw SQL here)
      await client.query('DELETE FROM student_disciplines');
      await client.query('DELETE FROM student_saisons');
      await client.query('DELETE FROM students');

      const saisonNomRes = await client.query('SELECT nom FROM saisons WHERE active = TRUE LIMIT 1');
      let seasonCode = '2627';
      if (saisonNomRes.rows.length > 0) {
        const nom = saisonNomRes.rows[0].nom;
        const parts = nom.match(/(\d{4})\/(\d{4})/);
        if (parts) seasonCode = parts[1].slice(2) + parts[2].slice(2);
      }
      let nextN = 0;

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        if (!line.trim()) continue;

        const cols = parseCSVLine(line);
        const get = (idx) => (cols[idx] || '').trim();

        const nom = get(COL.Nom);
        const prenom = get(COL.Prenom);

        // Already caught in dry run, skip silently
        if (!nom || !prenom) { skipped++; continue; }

        const birthDateResult = parseDate(get(COL.DateNaissance));
        const datePremResult = parseDate(get(COL.DatePremiereInscription));

        try {
          const discNames = parseArray(get(COL.Disciplines)) || [];

          nextN++;
          const numeroAdherent = `${seasonCode}-${String(nextN).padStart(4, '0')}`;

          const result = await client.query(
            `INSERT INTO students (
              last_name, first_name, email, phone,
              birth_date,
              parent_name, parent_phone, parent_email,
              address, postal_code, city,
              disciplines, practice_levels, formule,
              payment_method,
              size_top, size_bottom, shoe_size,
              date_premiere_inscription, saisons, statut_adhesion,
              active, droit_image, certificat_medical, unsubscribed, numero_adherent
            ) VALUES (
              $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,
              true, false, false, false, $22
            ) RETURNING id`,
            [
              nom, prenom,
              get(COL.Email) || null,
              get(COL.Telephone) || null,
              birthDateResult.value,
              get(COL.ResponsableLegal) || null,
              get(COL.TelResponsable) || null,
              get(COL.EmailResponsable) || null,
              get(COL.Adresse) || null,
              get(COL.CodePostal) || null,
              get(COL.Ville) || null,
              parseArray(get(COL.Disciplines)),
              get(COL.NiveauxPratique) || null,
              get(COL.Formule) || null,
              get(COL.ModePaiement) || null,
              get(COL.TailleHaut) || null,
              get(COL.TailleBas) || null,
              get(COL.Pointure) || null,
              datePremResult.value,
              parseArray(get(COL.Saisons)),
              get(COL.StatutAdhesion) || null,
              numeroAdherent,
            ]
          );

          const studentId = result.rows[0].id;
          inserted++;

          for (const discName of discNames) {
            const discId = DISCIPLINE_MAP[discName.trim()];
            if (discId) {
              await client.query(
                `INSERT INTO student_disciplines (student_id, discipline_id, enrolled_at)
                 VALUES ($1, $2, NOW())`,
                [studentId, discId]
              );
              disciplinesInserted++;
            }
          }
        } catch (err) {
          rowErrors.push({ row: i + 1, error: err.message });
        }
      }

      await client.query(
        `INSERT INTO student_saisons (student_id, saison_id, adhesion_payee, adhesion_incluse,
         cours_unite_count, versements_cents, amount_paid_cents, created_at)
         SELECT id, 1, true, false, 0, 0, 0, NOW() FROM students
         ON CONFLICT (student_id, saison_id) DO NOTHING`
      );

      await client.query('COMMIT');
      committed = true;

      res.json({
        imported: inserted,
        skipped: skipped + rowErrors.filter(e => e.field === 'Doublon').length,
        disciplinesInserted,
        errors: rowErrors.length,
        errorDetails: rowErrors,
        totalRows: totalDataRows,
        // Summary counts for the UI
        dateErrors: rowErrors.filter(e => e.field === 'Date de naissance' || e.field === 'Date 1ère inscription').length,
        emailErrors: rowErrors.filter(e => e.field === 'Email').length,
        phoneErrors: rowErrors.filter(e => e.field === 'Téléphone' || e.field === 'Tél. responsable légal').length,
        unknownDisciplines: rowErrors.filter(e => e.field === 'Disciplines').length,
        yearWarnings: rowErrors.filter(e => e.error && e.error.includes('inhabuelle')).length,
      });
    } catch (err) {
      console.error('[import-eleves] Fatal error:', err);
      if (!committed) await client.query('ROLLBACK');
      res.status(500).json({ error: 'Erreur serveur pendant l import' });
    } finally {
      client.release();
    }
  });

  return router;
};
