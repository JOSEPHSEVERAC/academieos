// Temporary 2FA bypass route for PRÉSIDENT + DIRECTRICE
// Used when Polsia email proxy is down and 2FA codes can't be sent.
// Does NOT own: normal 2FA login flow (server.js), student auth, tablet auth.

const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function generateToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

// Simple in-memory rate limiter for bypass attempts — 5 attempts per 15 min per IP
const bypassAttempts = new Map();
const BYPASS_RATE_LIMIT = 5;
const BYPASS_RATE_WINDOW_MS = 15 * 60 * 1000;

function checkBypassRateLimit(ip) {
  const now = Date.now();
  const key = ip || 'unknown';
  const entry = bypassAttempts.get(key);
  if (!entry || now - entry.windowStart > BYPASS_RATE_WINDOW_MS) {
    bypassAttempts.set(key, { windowStart: now, count: 1 });
    return true;
  }
  entry.count++;
  if (entry.count > BYPASS_RATE_LIMIT) return false;
  return true;
}

module.exports = function (pool, logAudit) {
  const router = express.Router();

  // Step 1: Generate a temp bypass token (admin-to-admin, no 2FA)
  // POST /auth/bypass/generate
  // Body: { email, password }
  // Returns: { bypass_token } (valid 24h, role-restricted)
  router.post('/bypass/generate', async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) return res.status(400).json({ error: 'Email et mot de passe requis' });

      // Rate limit bypass attempts
      if (!checkBypassRateLimit(req.ip)) {
        console.warn(`[bypass] RATE LIMITED ip=${req.ip} email=${email}`);
        return res.status(429).json({ error: 'Trop de tentatives. Réessayez dans 15 minutes.' });
      }

      const normalizedEmail = email.toLowerCase().trim();
      const result = await pool.query(
        `SELECT * FROM app_users WHERE email = $1 AND active = true AND role IN ('PRÉSIDENT', 'DIRECTRICE')`,
        [normalizedEmail]
      );
      if (result.rows.length === 0) {
        await bcrypt.compare(password, '$2a$10$placeholder.hash.to.prevent.timing.attack.padding');
        console.warn(`[bypass] GENERATE REJECTED — no matching active user email=${normalizedEmail} ip=${req.ip}`);
        return res.status(401).json({ error: 'Accès réservé au PRESIDENT ou à la DIRECTRICE' });
      }

      const user = result.rows[0];
      if (!user.password_hash) {
        console.warn(`[bypass] GENERATE REJECTED — account not activated email=${normalizedEmail} ip=${req.ip}`);
        return res.status(401).json({ error: 'Compte non activé' });
      }
      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        console.warn(`[bypass] GENERATE REJECTED — bad password email=${normalizedEmail} user_id=${user.id} ip=${req.ip}`);
        if (logAudit) {
          await logAudit(user.id, user.email, user.role, 'BYPASS_GENERATE_FAILED', 'app_users', user.id, { reason: 'bad_password' }, req.ip);
        }
        return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
      }

      // Generate bypass token
      const bypassToken = generateToken();
      const bypassHash = hashToken(bypassToken);
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h

      await pool.query(
        `INSERT INTO temp_bypass_tokens (token_hash, user_id, allowed_role, expires_at, created_by)
         VALUES ($1, $2, $3, $4, $2)`,
        [bypassHash, user.id, user.role, expiresAt]
      );

      console.log(`[bypass] GENERATE OK user_id=${user.id} role=${user.role} ip=${req.ip}`);
      if (logAudit) {
        await logAudit(user.id, user.email, user.role, 'BYPASS_TOKEN_GENERATED', 'temp_bypass_tokens', null, { expires_in: '24h' }, req.ip);
      }

      res.json({ bypass_token: bypassToken, role: user.role, expires_in: '24h' });
    } catch (err) {
      console.error('bypass/generate error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  // Step 2: Exchange bypass token for a session (no 2FA)
  // POST /auth/bypass/session
  // Body: { bypass_token }
  // Returns: { token, user } (full session, 7 days)
  router.post('/bypass/session', async (req, res) => {
    try {
      const { bypass_token } = req.body;
      if (!bypass_token) return res.status(400).json({ error: 'Token requis' });

      // Rate limit session exchange attempts too
      if (!checkBypassRateLimit(req.ip)) {
        console.warn(`[bypass] SESSION RATE LIMITED ip=${req.ip}`);
        return res.status(429).json({ error: 'Trop de tentatives. Réessayez dans 15 minutes.' });
      }

      const hash = hashToken(bypass_token);
      // Re-validate user is still active AND role still matches allowed_role
      const row = await pool.query(
        `SELECT t.*, u.email, u.first_name, u.last_name, u.role, u.teacher_name,
                u.onboarding_completed_at, u.invitation_accepted_at, u.active
         FROM temp_bypass_tokens t
         JOIN app_users u ON t.user_id = u.id
         WHERE t.token_hash = $1 AND t.used = false AND t.expires_at > NOW()`,
        [hash]
      );

      if (row.rows.length === 0) {
        console.warn(`[bypass] SESSION REJECTED — token not found or expired ip=${req.ip}`);
        return res.status(401).json({ error: 'Token expiré ou invalide' });
      }

      const record = row.rows[0];

      // Guard: user must still be active (could have been deactivated since token was generated)
      if (!record.active) {
        await pool.query('UPDATE temp_bypass_tokens SET used = true WHERE id = $1', [record.id]);
        console.warn(`[bypass] SESSION REJECTED — user deactivated user_id=${record.user_id} ip=${req.ip}`);
        if (logAudit) {
          await logAudit(record.user_id, record.email, record.role, 'BYPASS_SESSION_DENIED', 'app_users', record.user_id, { reason: 'user_inactive' }, req.ip);
        }
        return res.status(401).json({ error: 'Compte désactivé' });
      }

      // Guard: user role must still match the allowed_role from the token
      // Prevents session creation if user was demoted between generate and exchange
      if (record.role !== record.allowed_role) {
        await pool.query('UPDATE temp_bypass_tokens SET used = true WHERE id = $1', [record.id]);
        console.warn(`[bypass] SESSION REJECTED — role mismatch user_id=${record.user_id} current=${record.role} allowed=${record.allowed_role} ip=${req.ip}`);
        if (logAudit) {
          await logAudit(record.user_id, record.email, record.role, 'BYPASS_SESSION_DENIED', 'app_users', record.user_id,
            { reason: 'role_mismatch', current_role: record.role, allowed_role: record.allowed_role }, req.ip);
        }
        return res.status(401).json({ error: 'Rôle modifié — token invalide' });
      }

      // Mark bypass token as used (one-time use)
      await pool.query('UPDATE temp_bypass_tokens SET used = true WHERE id = $1', [record.id]);

      // Update last_login_at
      await pool.query('UPDATE app_users SET last_login_at = NOW() WHERE id = $1', [record.user_id]);

      // Create session token
      const sessionToken = generateToken();
      const sessionHash = hashToken(sessionToken);
      const sessionExpires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

      await pool.query(
        `INSERT INTO auth_tokens (user_id, type, token_hash, expires_at) VALUES ($1, 'session', $2, $3)`,
        [record.user_id, sessionHash, sessionExpires]
      );

      console.log(`[bypass] SESSION OK user_id=${record.user_id} role=${record.role} ip=${req.ip}`);
      if (logAudit) {
        await logAudit(record.user_id, record.email, record.role, 'BYPASS_SESSION_CREATED', 'app_users', record.user_id, null, req.ip);
      }

      res.json({
        token: sessionToken,
        user: {
          id: record.user_id,
          email: record.email,
          first_name: record.first_name,
          last_name: record.last_name,
          role: record.role,
          teacher_name: record.teacher_name,
          onboarding_completed_at: record.onboarding_completed_at,
          invitation_accepted_at: record.invitation_accepted_at,
          first_time: !record.invitation_accepted_at
        }
      });
    } catch (err) {
      console.error('bypass/session error:', err);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  });

  return router;
};