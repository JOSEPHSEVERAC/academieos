const fs = require('fs');
const path = require('path');
const base = __dirname;
const files = ['public/landing.html','public/parents.html','public/schedule.html','public/tarifs.html'];
let allOk = true;
for (const f of files) {
  const h = fs.readFileSync(path.join(base, f), 'utf8');
  const missing = ['<html','</html>','<body','</body>'].filter(t => !h.includes(t));
  if (missing.length) {
    console.error('FAIL: ' + f + ' missing ' + missing.join(','));
    allOk = false;
  } else {
    console.log('PASS: ' + f);
  }
}
if (!allOk) process.exit(1);