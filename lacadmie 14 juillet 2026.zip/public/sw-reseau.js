// Service Worker — L'Académie Réseau Social PWA
// Scoped to /reseau/ only — isolated from /appel and /encaissement SWs.
const CACHE = 'academie-reseau-v2';
const SHELL = ['/reseau/app', '/reseau/manifest.json', '/icons/icon-192.svg'];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Only handle /reseau/ scope — no overlap with other PWAs
  if (!url.pathname.startsWith('/reseau/')) return;

  // API / auth calls: network-only
  if (url.pathname.startsWith('/reseau/api/')) {
    e.respondWith(fetch(e.request));
    return;
  }

  // App shell: network-first, fall back to cache
  e.respondWith(
    fetch(e.request)
      .then(res => {
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return res;
      })
      .catch(() => caches.match(e.request))
  );
});