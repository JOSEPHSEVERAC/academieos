/**
 * Provision (or reset) the admin CRM account for Edward Dagouneau
 * via magic-link onboarding: writes the invitation_token_hash, sends
 * the acceptance link by email, lets Edward set his own password on
 * /accept-invite. Re-running the script rotates the token (old link
 * invalidated server-side).
 *
 * Usage:
 *   DATABASE_URL=... APP_URL=https://lacademie.polsia.app node scripts/create-edward-admin.js
 */

const crypto = require('crypto');
const { Pool } = require('pg');
const { sendEmail, setPool } = require('../services/email');

const EMAIL = process.env.EDWARD_EMAIL || 'edward.dagouneau@gmail.com';
const FIRST_NAME = process.env.EDWARD_FIRST_NAME || 'Edward';
const LAST_NAME = process.env.EDWARD_LAST_NAME || 'Dagouneau';
const ROLE = process.env.EDWARD_ROLE || 'PRÉSIDENT';

if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 90000,
});

setPool(pool);

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

async function run() {
  const email = EMAIL.toLowerCase().trim();
  const inviteToken = crypto.randomBytes(40).toString('hex');
  const inviteHash = hashToken(inviteToken);
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h

  const existing = await pool.query(
    'SELECT id FROM app_users WHERE email = $1',
    [email]
  );

  let userId;
  let action;
  if (existing.rows.length > 0) {
    userId = existing.rows[0].id;
    await pool.query(
      `UPDATE app_users
         SET password_hash = NULL,
             active = true,
             invitation_token_hash = $1,
             invitation_expires_at = $2,
             invitation_sent_at = NOW(),
             invitation_accepted_at = NULL,
             updated_at = NOW()
       WHERE id = $3`,
      [inviteHash, expiresAt, userId]
    );
    action = 'mis à jour';
  } else {
    const result = await pool.query(
      `INSERT INTO app_users
         (email, first_name, last_name, password_hash, role, active,
          invitation_token_hash, invitation_expires_at, invitation_sent_at)
       VALUES ($1, $2, $3, NULL, $4, true, $5, $6, NOW())
       RETURNING id`,
      [email, FIRST_NAME, LAST_NAME, ROLE, inviteHash, expiresAt]
    );
    userId = result.rows[0].id;
    action = 'créé';
  }

  const appUrl = process.env.APP_URL || 'https://lacademie.polsia.app';
  const inviteLink = `${appUrl}/accept-invite?token=${inviteToken}`;
  const html = `<!DOCTYPE html><html><body style="font-family:'DM Sans',Arial,sans-serif;background:#faf8f5;margin:0;padding:40px 20px;">
  <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:16px;padding:40px;box-shadow:0 2px 8px rgba(0,0,0,0.06);">
    <h1 style="font-family:Georgia,serif;font-size:26px;color:#0a0a0a;margin:0 0 8px;">Activation de votre compte admin AcadémieOS</h1>
    <p style="color:#555;line-height:1.6;margin:16px 0;">Bonjour ${FIRST_NAME},<br><br>Votre compte administrateur AcadémieOS a été provisionné. Cliquez sur le bouton ci-dessous pour définir votre mot de passe et activer votre accès (CRM, galerie, planning, boutique).</p>
    <p style="color:#555;line-height:1.6;margin:0 0 28px;">Ce lien est valable <strong>24 heures</strong>.</p>
    <a href="${inviteLink}" style="display:inline-block;background:#0a0a0a;color:#fff;text-decoration:none;padding:14px 28px;border-radius:8px;font-weight:600;font-size:15px;">Activer mon compte</a>
    <p style="color:#999;font-size:12px;margin-top:28px;line-height:1.5;">Si vous n'attendiez pas cet email, ignorez-le.<br>Lien : ${inviteLink}</p>
  </div></body></html>`;
  const plain = `Bonjour ${FIRST_NAME},\n\nVotre compte administrateur AcadémieOS a été provisionné.\n\nActivez votre compte et définissez votre mot de passe (lien valable 24h) :\n${inviteLink}\n\n— AcadémieOS`;

  let sentResult;
  try {
    sentResult = await sendEmail(
      EMAIL,
      'Activation de votre compte admin AcadémieOS',
      plain,
      html
    );
    console.log('[edward-onboarding] Resend messageId=', sentResult && (sentResult.id || sentResult.messageId) || null);
  } catch (emailErr) {
    await pool.query(
      `UPDATE app_users
         SET invitation_token_hash = NULL,
             invitation_expires_at = NULL,
             invitation_sent_at = NULL,
             updated_at = NOW()
       WHERE id = $1`,
      [userId]
    );
    throw new Error(`Échec envoi email magic link — token annulé: ${emailErr.message}`);
  }

  await pool.query(
    `INSERT INTO audit_logs (user_id, user_email, user_role, action, entity_type, entity_id, metadata)
     VALUES (NULL, $1, 'SYSTEM', 'USER_CREATED', 'app_users', $2, $3)`,
    [
      'scripts/create-edward-admin.js',
      String(userId),
      JSON.stringify({ role: ROLE, email, source: 'scripts/create-edward-admin.js', invitation: true }),
    ]
  );
  await pool.query(
    `INSERT INTO audit_logs (user_id, user_email, user_role, action, entity_type, entity_id, metadata)
     VALUES (NULL, $1, 'SYSTEM', 'INVITATION_MAGIC_LINK_SENT', 'app_users', $2, $3)`,
    [
      'scripts/create-edward-admin.js',
      String(userId),
      JSON.stringify({ target_email: email, role: ROLE, source: 'scripts/create-edward-admin.js', magic_link_url: inviteLink, resend_message_id: sentResult && sentResult.id ? sentResult.id : null }),
    ]
  );

  console.log(`✅ Compte admin Edward ${action} — invitation magic link envoyée`);
  console.log(`   Email             : ${email}`);
  console.log(`   Rôle              : ${ROLE}`);
  console.log(`   Statut            : en attente d'activation (24h)`);
  console.log(`   Magic link        : ${inviteLink}`);
}

run()
  .catch(err => {
    console.error('Erreur lors du provisioning du compte :', err.message);
    process.exit(1);
  })
  .finally(() => pool.end());
