// scripts/test-printful-token.js
// Quick token verification — calls Printful API directly.
// Usage: node scripts/test-printful-token.js
// Run via: POST /debug/run-script?script=test-printful-token

const PRINTFUL_API_URL = 'https://api.printful.com';

async function main() {
  const token = process.env.PRINTFUL_API_TOKEN;
  if (!token) {
    console.error('ERROR: PRINTFUL_API_TOKEN not set');
    process.exit(1);
  }

  console.log('[printful-test] Token found, calling /sync/products...');

  const res = await fetch(`${PRINTFUL_API_URL}/sync/products`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });

  const json = await res.json();

  if (!res.ok) {
    console.error(`ERROR: HTTP ${res.status} — ${json?.error?.message || res.statusText}`);
    process.exit(1);
  }

  const products = json.result || [];
  console.log(`SUCCESS: ${products.length} sync products in Printful catalog`);
  if (products.length > 0) {
    console.log('Sample product:', JSON.stringify(products[0], null, 2));
  }
}

main().catch(err => {
  console.error('FATAL:', err.message);
  process.exit(1);
});