/**
 * Reset the PRÉSIDENT account password on the Render PostgreSQL database.
 * Creates the account if it doesn't exist.
 *
 * Usage:
 *   DATABASE_URL=... POLSIA_OWNER_EMAIL=... node scripts/create-president.js
 */

const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

const email = process.env.POLSIA_OWNER_EMAIL;

if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

if (!email) {
  console.error('ERROR: POLSIA_OWNER_EMAIL environment variable is required');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 90000,
});

async function run() {
  const passwordHash = await bcrypt.hash('AcademieOS2026!', 12);

  const existing = await pool.query(
    "SELECT email FROM app_users WHERE role = 'PRÉSIDENT' LIMIT 1"
  );

  let accountEmail;
  if (existing.rows.length > 0) {
    accountEmail = existing.rows[0].email;
    await pool.query(
      "UPDATE app_users SET password_hash = $1, updated_at = NOW() WHERE role = 'PRÉSIDENT'",
      [passwordHash]
    );
  } else {
    const result = await pool.query(
      `INSERT INTO app_users (email, first_name, last_name, password_hash, role)
       VALUES ($1, 'Joseph', 'Séverac', $2, 'PRÉSIDENT')
       RETURNING email`,
      [email.toLowerCase().trim(), passwordHash]
    );
    accountEmail = result.rows[0].email;
  }

  const action = existing.rows.length > 0 ? 'réinitialisé' : 'créé';
  console.log(`✅ Compte PRÉSIDENT ${action}`);
  console.log(`   Email            : ${accountEmail}`);
  console.log(`   Mot de passe     : AcademieOS2026!`);
  console.log(`   URL de connexion : https://academieos-web.onrender.com/login`);
}

run()
  .catch(err => {
    console.error('Erreur lors de la création du compte :', err.message);
    process.exit(1);
  })
  .finally(() => pool.end());
