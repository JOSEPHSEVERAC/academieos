// Generate SQL INSERT from CSV — handles rows with missing trailing fields
const fs = require('fs');
const path = require('path');

const csvPath  = path.join(__dirname, '..', 'data', 'eleves_2025_2026.csv');
const outPath  = path.join(__dirname, '..', 'data', 'import.sql');
const content  = fs.readFileSync(csvPath, 'utf-8');
const lines    = content.split('\n');

const COL = {
  Nom: 0, Prenom: 1, Email: 2, Telephone: 3, DateNaissance: 4,
  ResponsableLegal: 5, TelResponsable: 6, EmailResponsable: 7,
  Adresse: 8, CodePostal: 9, Ville: 10, Disciplines: 11,
  NiveauxPratique: 12, Formule: 13, ModePaiement: 14,
  TailleHaut: 15, TailleBas: 16, Pointure: 17,
  DatePremiereInscription: 18, Saisons: 19, StatutAdhesion: 20,
};
const FIELD_COUNT = 21;

// Parse ; separated CSV, handle quoted fields
function parseCSV(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
      else { inQuotes = !inQuotes; }
    } else if (c === ';' && !inQuotes) {
      result.push(current.trim()); current = '';
    } else { current += c; }
  }
  result.push(current.trim());
  return result;
}

// Parse DD/MM/YYYY → YYYY-MM-DD (French date format)
function parseDate(str) {
  if (!str) return null;
  // Match DD/MM/YYYY
  const m = str.match(/^(\b[0-9]{1,2}\b)\/(\b[0-9]{1,2}\b)\/(\b[0-9]{4}\b)/);
  if (m) {
    const [, d, mo, y] = m;
    return `${y}-${mo.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }
  return null;
}

function pgArr(str) {
  if (!str || str === '') return null;
  const items = str.split(',').map(s => s.trim()).filter(Boolean);
  if (items.length === 0) return null;
  return '{' + items.map(s => '"' + s.replace(/"/g, '\\"') + '"').join(',') + '}';
}

function esc(s) { return (String(s || '')).replace(/'/g, "''"); }
function rv(s)  { return s && s !== '' ? "'" + esc(s) + "'" : 'NULL'; }

const header = parseCSV(lines[0]);
console.log('Header cols:', header.length, '| Expected:', FIELD_COUNT);

const values = [];
let skipped = 0;

for (let i = 1; i < lines.length; i++) {
  const rawLine = lines[i];
  if (!rawLine.trim()) continue;

  const cols = parseCSV(rawLine);

  const nom    = cols[COL.Nom];
  const prenom  = cols[COL.Prenom];
  if (!nom || !prenom) { skipped++; continue; }

  // Birth date
  const birthDate = parseDate(cols[COL.DateNaissance]);

  // First inscription date
  let dateIns;
  if (cols.length === 20) {
    // 20-col rows: dateIns in cols[17], saisons in cols[18], statut in cols[19]
    dateIns = parseDate(cols[17]) || '2026-05-03';
  } else {
    dateIns = parseDate(cols[COL.DatePremiereInscription]) || '2026-05-03';
  }

  // Disciplines
  const disciplines = pgArr(cols[COL.Disciplines]);

  // Note: for 20-col rows, cols[17] = date_inscription (not Pointure),
  // so Pointure is NULL (no room for it in the row)
  const pointure = cols.length === 20 ? 'NULL' : rv(cols[COL.Pointure]);

  // Saisons
  let saisons;
  if (cols.length === 20) {
    saisons = pgArr(cols[18]) || '{2025/2026}';
  } else {
    saisons = pgArr(cols[COL.Saisons]) || '{2025/2026}';
  }

  // Statut adhésion
  const statut = cols.length === 20 ? (cols[19] || 'Payée') : (cols[COL.StatutAdhesion] || 'Payée');

  const row = [
    rv(nom), rv(prenom),
    rv(cols[COL.Email]), rv(cols[COL.Telephone]),
    birthDate ? "'" + birthDate + "'" : 'NULL',
    rv(cols[COL.ResponsableLegal]), rv(cols[COL.TelResponsable]), rv(cols[COL.EmailResponsable]),
    rv(cols[COL.Adresse]), rv(cols[COL.CodePostal]), rv(cols[COL.Ville]),
    disciplines ? "'" + disciplines + "'::text[]" : "'{}'::text[]",
    cols[COL.NiveauxPratique] && cols[COL.NiveauxPratique].trim() !== '' ? rv(cols[COL.NiveauxPratique]) : "'{}'::text[]",
    rv(cols[COL.Formule]), rv(cols[COL.ModePaiement]),
    rv(cols[COL.TailleHaut]), rv(cols[COL.TailleBas]), pointure,
    "'" + dateIns + "'",
    "'" + saisons + "'::text[]",
    rv(statut),
    'true', 'false', 'false', 'false'
  ];

  values.push('(' + row.join(',') + ')');
}

console.log('Rows:', values.length, '| Skipped:', skipped);
values.slice(0, 3).forEach((v, i) => console.log('Row', i + 1 + ':', v));
console.log('...');

const sql = 'INSERT INTO students (last_name, first_name, email, phone, birth_date, parent_name, parent_phone, parent_email, address, postal_code, city, disciplines, practice_levels, formule, payment_method, size_top, size_bottom, shoe_size, date_premiere_inscription, saisons, statut_adhesion, active, droit_image, certificat_medical, unsubscribed) VALUES\n' + values.join(',\n') + '\nON CONFLICT DO NOTHING;';

fs.writeFileSync(outPath, sql);
console.log('\nWritten to data/import.sql (' + values.length + ' rows, ~' + Math.round(sql.length / 1024) + ' KB)');