// scripts/test-email-delivery.js
// Owner-runnable CLI proof of email delivery via Resend.
// Sends one test email and prints the provider message ID.
// Usage:
//   DATABASE_URL=... node scripts/test-email-delivery.js
//   DATABASE_URL=... node scripts/test-email-delivery.js user@example.com
//   TEST_EMAIL=user@example.com DATABASE_URL=... node scripts/test-email-delivery.js
// Run via: npm run test:email -- user@example.com

const { Pool } = require('pg');
const { sendEmail, setPool } = require('../services/email');

const CLI_RECIPIENT = process.argv[2];

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error('ERROR: DATABASE_URL environment variable is required');
    process.exit(1);
  }

  const to = CLI_RECIPIENT || process.env.TEST_EMAIL || 'gregjs33260@gmail.com';
  console.log(`[email-test] starting recipient=${to}`);

  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
    connectionTimeoutMillis: 90000,
  });
  setPool(pool);

  try {
    const sentAt = new Date().toISOString();
    const result = await sendEmail(
      to,
      '[AcadémieOS] test delivery',
      `AcadémieOS email-delivery proof of life.\nRecipient: ${to}\nTimestamp: ${sentAt}\nProvider: Resend (lacademie.art)\n— AcadémieOS`
    );
    const messageId = result?.id || result?.messageId;
    if (!messageId) {
      console.error('[email-test] FAILED — provider returned no messageId');
      console.error(JSON.stringify(result, null, 2));
      process.exit(1);
    }
    console.log(`[email-test] PASS — recipient=${to} messageId=${messageId}`);
    console.log(`[email-test] verify on Resend dashboard: https://resend.com/emails/${messageId}`);
  } catch (err) {
    console.error(`[email-test] FAILED — recipient=${to} code=${err.code || 'unknown'} msg="${err.message}"`);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main().catch(err => {
  console.error('FATAL:', err && err.message ? err.message : err);
  process.exit(1);
});
