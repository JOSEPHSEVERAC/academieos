/**
 * Generate numero_adherent for unassigned students in saison 2025/2026.
 *
 * Format: 202526-NNNN  (YYYY=2025, SS=26, NNNN=0001..0188)
 * Order:   alphabetical by last_name, then first_name
 *
 * Usage:
 *   DATABASE_URL=... node scripts/generate-numero-adherent.js
 *   npm run generate-numero-adherent
 */

const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 90000,
});

async function main() {
  const client = await pool.connect();

  try {
    // 1. Resolve saison 2025/2026
    const saisonRes = await client.query(
      `SELECT id FROM saisons WHERE nom = '2025/2026' LIMIT 1`
    );
    if (!saisonRes.rows[0]) {
      console.error("ERROR: Saison '2025/2026' introuvable");
      process.exit(1);
    }
    const saisonId = saisonRes.rows[0].id;
    console.log(`Saison 2025/2026 ID: ${saisonId}`);

    // 2. Get students needing a number — alphabetical order
    const studentsRes = await client.query(`
      SELECT s.id, s.last_name, s.first_name, s.numero_adherent
      FROM students s
      JOIN student_saisons ss ON ss.student_id = s.id AND ss.saison_id = $1
      WHERE (s.numero_adherent IS NULL OR s.numero_adherent = '—')
      ORDER BY s.last_name ASC, s.first_name ASC
    `, [saisonId]);

    if (studentsRes.rows.length === 0) {
      console.log('Aucun élève à numéroter (tous ont déjà un numéro)');
      return;
    }

    console.log(`Élèves à numéroter: ${studentsRes.rows.length}`);

    // 3. Batch UPDATE in transaction
    await client.query('BEGIN');
    const results = [];
    let errors = 0;

    for (let i = 0; i < studentsRes.rows.length; i++) {
      const student = studentsRes.rows[i];
      const numero = `202526-${String(i + 1).padStart(4, '0')}`;
      try {
        const r = await client.query(
          `UPDATE students SET numero_adherent = $1 WHERE id = $2 RETURNING id, numero_adherent`,
          [numero, student.id]
        );
        results.push({ id: student.id, numero_adherent: r.rows[0].numero_adherent });
      } catch (err) {
        console.error(`  Erreur pour ${student.last_name} ${student.first_name} (id=${student.id}): ${err.message}`);
        errors++;
      }
    }

    if (errors > 0) {
      await client.query('ROLLBACK');
      console.error(`\nÉchec: ${errors} erreur(s) — rollback effectué`);
      process.exit(1);
    } else {
      await client.query('COMMIT');
    }

    console.log(`\nNuméros attribués: ${results.length}`);
    console.log('Premier:', results[0].numero_adherent, '| Dernier:', results[results.length - 1].numero_adherent);

  } finally {
    client.release();
    await pool.end();
  }
}

main().catch(err => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
