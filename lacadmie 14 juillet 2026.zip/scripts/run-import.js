const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const CSV_PATH = path.join(__dirname, '..', 'data', 'eleves-2025-2026.csv');
const DB_URL = process.env.DATABASE_URL;

if (!DB_URL) { console.error('DATABASE_URL required'); process.exit(1); }

const pool = new Pool({ connectionString: DB_URL, ssl: { rejectUnauthorized: false } });

const DISC = {
  'Classique':1,'Jazz':2,'Jazz Latino':3,'Hip-Hop / Break':4,
  'Eveil / Initiation':7,'Pilates':10,'Stretching':9,'Ragga':8,'Barre à Terre':11
};

function parseDate(str) {
  if (!str || !str.trim()) return null;
  const parts = str.trim().split('/');
  if (parts.length !== 3) return null;
  return parts[2]+'-'+parts[1].padStart(2,'0')+'-'+parts[0].padStart(2,'0');
}
function esc(s) { return (s||'').replace(/'/g,"''"); }
function arr(vals) {
  if (!vals || !vals.length) return 'NULL';
  return "ARRAY[" + vals.map(v => "'"+esc(v)+"'").join(',') + "]";
}

const content = fs.readFileSync(CSV_PATH,'utf8');
const lines = content.split('\n').filter(l=>l.trim());
const header = lines[0].split(';').map(s=>s.trim());
const col = {
  nom:header.indexOf('Nom'),prenom:header.indexOf('Prénom'),
  email:header.indexOf('Email'),tel:header.indexOf('Téléphone'),
  dob:header.indexOf('Date de naissance'),
  parent:header.indexOf('Responsable légal'),tparent:header.indexOf('Tél. responsable légal'),
  eparent:header.indexOf('Email responsable légal'),
  addr:header.indexOf('Adresse'),cp:header.indexOf('Code postal'),ville:header.indexOf('Ville'),
  discs:header.indexOf('Disciplines'),
  formule:header.indexOf('Formule tarifaire'),paiement:header.indexOf('Mode de paiement'),
  thaut:header.indexOf('Taille haut'),tbas:header.indexOf('Taille bas'),
  pointure:header.indexOf('Pointure'),
  inscription:header.indexOf("Date 1ère inscription"),
  saisons:header.indexOf("Saison(s)"),statut:header.indexOf('Statut adhésion')
};
const g = (idx,row) => ((row[idx]||'').trim());

const students = [];
const disciplines = [];
for (let i=1; i<lines.length; i++) {
  const r = lines[i].split(';').map(s=>s.trim());
  const nom=g(col.nom,r), prenom=g(col.prenom,r);
  if (!nom || !prenom) continue;
  const discList = g(col.discs,r) ? g(col.discs,r).split(',').map(s=>s.trim()).filter(Boolean) : [];
  const saisList = g(col.saisons,r) ? g(col.saisons,r).split(',').map(s=>s.trim()).filter(Boolean) : [];
  students.push({
    nom, prenom,
    email: g(col.email,r)||null, phone: g(col.tel,r)||null,
    birth_date: parseDate(g(col.dob,r)),
    parent: g(col.parent,r)||null, tparent: g(col.tparent,r)||null, eparent: g(col.eparent,r)||null,
    addr: g(col.addr,r)||null, cp: g(col.cp,r)||null, ville: g(col.ville,r)||null,
    discList, saisList,
    formule: g(col.formule,r)||null, paiement: g(col.paiement,r)||null,
    thaut: g(col.thaut,r)||null, tbas: g(col.tbas,r)||null, pointure: g(col.pointure,r)||null,
    inscription: parseDate(g(col.inscription,r)), statut: g(col.statut,r)||null
  });
  discList.forEach(d => {
    const did = DISC[d.trim()];
    if (did) disciplines.push({student_idx: students.length, disc_id: did});
  });
}

console.log(`Parsed ${students.length} students, ${disciplines.length} discipline entries`);
console.log(`First student: ${students[0].nom} ${students[0].prenom} — discs: ${students[0].discList.join(', ')}`);

async function run() {
  const client = await pool.connect();
  let inserted = 0;
  try {
    // DELETE existing
    await client.query('DELETE FROM student_disciplines');
    await client.query('DELETE FROM student_saisons');
    await client.query('DELETE FROM students');
    console.log('Cleared tables');

    // Insert students in batches of 20
    const BATCH = 20;
    for (let b = 0; b < students.length; b += BATCH) {
      const batch = students.slice(b, b+BATCH);
      const vals = batch.map((s,i) => {
        const n = b+i+1;
        return `(${n},'${esc(s.nom)}','${esc(s.prenom)}',${s.email?"'"+esc(s.email)+"'":"NULL"},${s.phone?"'"+esc(s.phone)+"'":"NULL"},${s.birth_date?"'"+s.birth_date+"'":"NULL"},${s.parent?"'"+esc(s.parent)+"'":"NULL"},${s.tparent?"'"+esc(s.tparent)+"'":"NULL"},${s.eparent?"'"+esc(s.eparent)+"'":"NULL"},${s.addr?"'"+esc(s.addr)+"'":"NULL"},${s.cp?"'"+esc(s.cp)+"'":"NULL"},${s.ville?"'"+esc(s.ville)+"'":"NULL"},${arr(s.discList)},${s.formule?"'"+esc(s.formule)+"'":"NULL"},${s.paiement?"'"+esc(s.paiement)+"'":"NULL"},${s.thaut?"'"+esc(s.thaut)+"'":"NULL"},${s.tbas?"'"+esc(s.tbas)+"'":"NULL"},${s.pointure?"'"+esc(s.pointure)+"'":"NULL"},${s.inscription?"'"+s.inscription+"'":"NULL"},${arr(s.saisList)},${s.statut?"'"+esc(s.statut)+"'":"NULL"},true,false,false,false)`;
      });
      await client.query(
        `INSERT INTO students (id,last_name,first_name,email,phone,birth_date,parent_name,parent_phone,parent_email,address,postal_code,city,disciplines,formule,payment_method,size_top,size_bottom,shoe_size,date_premiere_inscription,saisons,statut_adhesion,active,droit_image,certificat_medical,unsubscribed) VALUES ${vals.join(',')}`
      );
      inserted += batch.length;
      console.log(`  Inserted batch ${Math.floor(b/BATCH)+1}: ${inserted}/${students.length}`);
    }

    // Insert disciplines
    const discVals = disciplines.map(d => `(${d.student_idx},${d.disc_id})`).join(',');
    await client.query(`INSERT INTO student_disciplines (student_id,discipline_id,enrolled_at) VALUES ${discVals}`);
    console.log(`Inserted ${disciplines.length} student_disciplines`);

    // Insert student_saisons (all for saison 1)
    const saiVals = students.map((_,i) => `(${i+1},1,true,false,0,0,0,NOW())`).join(',');
    await client.query(`INSERT INTO student_saisons (student_id,saison_id,adhesion_payee,adhesion_incluse,cours_unite_count,versements_cents,amount_paid_cents,created_at) VALUES ${saiVals}`);
    console.log(`Inserted ${students.length} student_saisons`);

  } finally {
    client.release();
    await pool.end();
  }
  console.log('\nImport complete!');
}

run().catch(err => { console.error('FATAL:', err.message); process.exit(1); });