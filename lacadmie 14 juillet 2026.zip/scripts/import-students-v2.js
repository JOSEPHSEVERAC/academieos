/**
 * Import students from CSV — inserts into students, student_disciplines, student_saisons
 *
 * Usage:
 *   node -e "
 *     process.env.DATABASE_URL = require('./env.json').DATABASE_URL;
 *     require('./scripts/import-students-v2.js');
 *   "
 *   Or call directly via the route: POST /api/import-eleves with { csv: <text> }
 */

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

// Resolve path relative to this script
const CSV_PATH = path.join(__dirname, '..', 'data', 'eleves-2025-2026.csv');

if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 90000,
});

// Discipline name → id mapping (from DB)
const DISCIPLINE_MAP = {
  'Classique':            1,
  'Jazz':                  2,
  'Jazz Latino':          3,
  'Hip-Hop / Break':      4,
  'Eveil / Initiation':   7,
  'Pilates':              10,
  'Stretching':           9,
  'Ragga':                 8,
  'Barre à Terre':        11,
  'Pilates PM':           5,
  'Ragga Cardio':          6,
};

function parseDate(str) {
  if (!str || str.trim() === '') return null;
  const parts = str.trim().split('/');
  if (parts.length !== 3) return null;
  const [day, month, year] = parts;
  return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
}

function parseArray(str) {
  if (!str || str.trim() === '') return null;
  return str.split(',').map(s => s.trim()).filter(Boolean);
}

function parseCSVLine(line) {
  return line.split(';').map(s => s.trim());
}

async function importCSV() {
  if (!fs.existsSync(CSV_PATH)) {
    console.error(`ERROR: CSV file not found at ${CSV_PATH}`);
    process.exit(1);
  }

  const content = fs.readFileSync(CSV_PATH, 'utf8');
  const lines = content.split('\n').filter(l => l.trim() !== '');

  if (lines.length < 2) {
    console.error('ERROR: CSV must have a header row and at least one data row');
    process.exit(1);
  }

  const header = parseCSVLine(lines[0]);
  console.log(`CSV header: ${header.join(' | ')}`);
  console.log(`Data rows: ${lines.length - 1}`);

  const COL = {
    Nom:                    header.indexOf('Nom'),
    Prenom:                 header.indexOf('Prénom'),
    Email:                  header.indexOf('Email'),
    Telephone:              header.indexOf('Téléphone'),
    DateNaissance:           header.indexOf('Date de naissance'),
    ResponsableLegal:        header.indexOf('Responsable légal'),
    TelResponsable:         header.indexOf('Tél. responsable légal'),
    EmailResponsable:        header.indexOf('Email responsable légal'),
    Adresse:                header.indexOf('Adresse'),
    CodePostal:             header.indexOf('Code postal'),
    Ville:                  header.indexOf('Ville'),
    Disciplines:            header.indexOf('Disciplines'),
    NiveauxPratique:         header.indexOf('Niveaux de pratique'),
    Formule:                header.indexOf('Formule tarifaire'),
    ModePaiement:           header.indexOf('Mode de paiement'),
    TailleHaut:             header.indexOf('Taille haut'),
    TailleBas:              header.indexOf('Taille bas'),
    Pointure:               header.indexOf('Pointure'),
    DatePremiereInscription:header.indexOf('Date 1ère inscription'),
    Saisons:                header.indexOf("Saison(s)"),
    StatutAdhesion:         header.indexOf('Statut adhésion'),
  };

  const missing = Object.entries(COL).filter(([, idx]) => idx === -1).map(([name]) => name);
  if (missing.length > 0) {
    console.error(`ERROR: Missing CSV columns: ${missing.join(', ')}`);
    process.exit(1);
  }

  const client = await pool.connect();
  let studentsInserted = 0;
  let disciplinesInserted = 0;
  let saisonsInserted = 0;
  let errors = 0;

  try {
    // TRUNCATE existing data (reset sequences)
    await client.query('TRUNCATE students RESTART IDENTITY CASCADE');
    console.log('Cleared students and student_disciplines');

    await client.query(
      `INSERT INTO student_saisons (student_id, saison_id, adhesion_payee, adhesion_incluse,
       cours_unite_count, versements_cents, amount_paid_cents)
       SELECT id, 1, true, false, 0, 0, 0 FROM students
       ON CONFLICT (student_id, saison_id) DO NOTHING`
    );

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (!line.trim()) continue;

      const cols = parseCSVLine(line);
      const get = (idx) => (cols[idx] || '').trim();

      const nom = get(COL.Nom);
      const prenom = get(COL.Prenom);
      if (!nom || !prenom) {
        console.warn(`Row ${i}: Skipping - missing nom or prenom`);
        errors++;
        continue;
      }

      try {
        const result = await client.query(
          `INSERT INTO students (
            last_name, first_name, email, phone,
            birth_date,
            parent_name, parent_phone, parent_email,
            address, postal_code, city,
            disciplines, practice_levels, formule,
            payment_method,
            size_top, size_bottom, shoe_size,
            date_premiere_inscription, saisons, statut_adhesion,
            active, droit_image, certificat_medical, unsubscribed
          ) VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,
            true, false, false, false
          ) RETURNING id`,
          [
            nom, prenom,
            get(COL.Email) || null,
            get(COL.Telephone) || null,
            parseDate(get(COL.DateNaissance)),
            get(COL.ResponsableLegal) || null,
            get(COL.TelResponsable) || null,
            get(COL.EmailResponsable) || null,
            get(COL.Adresse) || null,
            get(COL.CodePostal) || null,
            get(COL.Ville) || null,
            parseArray(get(COL.Disciplines)),
            get(COL.NiveauxPratique) || null,
            get(COL.Formule) || null,
            get(COL.ModePaiement) || null,
            get(COL.TailleHaut) || null,
            get(COL.TailleBas) || null,
            get(COL.Pointure) || null,
            parseDate(get(COL.DatePremiereInscription)),
            parseArray(get(COL.Saisons)),
            get(COL.StatutAdhesion) || null,
          ]
        );

        const studentId = result.rows[0].id;
        studentsInserted++;

        // Insert student_disciplines rows
        const discNames = parseArray(get(COL.Disciplines)) || [];
        for (const name of discNames) {
          const discId = DISCIPLINE_MAP[name.trim()];
          if (discId) {
            await client.query(
              `INSERT INTO student_disciplines (student_id, discipline_id, enrolled_at)
               VALUES ($1, $2, NOW())
               ON CONFLICT DO NOTHING`,
              [studentId, discId]
            );
            disciplinesInserted++;
          } else {
            console.warn(`Row ${i}: Unknown discipline "${name}"`);
          }
        }

        // Insert student_saisons (saison_id=1 = 2025/2026, adhesion_payee=true)
        await client.query(
          `INSERT INTO student_saisons (student_id, saison_id, adhesion_payee, adhesion_incluse,
           cours_unite_count, versements_cents, amount_paid_cents, created_at)
           VALUES ($1, 1, true, false, 0, 0, 0, NOW())
           ON CONFLICT (student_id, saison_id) DO NOTHING`,
          [studentId]
        );
        saisonsInserted++;

      } catch (err) {
        console.warn(`Row ${i} (${nom} ${prenom}): ${err.message}`);
        errors++;
      }
    }
  } finally {
    client.release();
    await pool.end();
  }

  console.log(`\nImport complete:`);
  console.log(`  Students:       ${studentsInserted}`);
  console.log(`  Disciplines:    ${disciplinesInserted}`);
  console.log(`  Saisons:        ${saisonsInserted}`);
  console.log(`  Errors:         ${errors}`);

  process.exit(errors > 0 ? 1 : 0);
}

importCSV().catch(err => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});