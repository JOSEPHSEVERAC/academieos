/**
 * Generates SQL INSERT statements for students, student_disciplines, student_saisons.
 * Run: node scripts/gen-import-sql.js > /tmp/import.sql
 * Then paste batches of 10 INSERT statements into query_db.
 */

const fs = require('fs');
const path = require('path');

const CSV_PATH = path.join(__dirname, '..', 'data', 'eleves-2025-2026.csv');

const DISCIPLINE_MAP = {
  'Classique': 1,
  'Jazz': 2,
  'Jazz Latino': 3,
  'Hip-Hop / Break': 4,
  'Eveil / Initiation': 7,
  'Pilates': 10,
  'Stretching': 9,
  'Ragga': 8,
  'Barre à Terre': 11,
  'Pilates PM': 5,
  'Ragga Cardio': 6,
};

function parseDate(str) {
  if (!str || str.trim() === '') return null;
  const parts = str.trim().split('/');
  if (parts.length !== 3) return null;
  return `${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
}

function escape(str) {
  if (str === null) return 'NULL';
  return str.replace(/'/g, "''");
}

function pgArray(arr) {
  if (!arr || arr.length === 0) return 'NULL';
  return `ARRAY[${arr.map(v => `'${escape(v)}'`).join(',')}]`;
}

const content = fs.readFileSync(CSV_PATH, 'utf8');
const lines = content.split('\n').filter(l => l.trim() !== '');
const header = lines[0].split(';').map(s => s.trim());

const COL = {
  Nom: header.indexOf('Nom'),
  Prenom: header.indexOf('Prénom'),
  Email: header.indexOf('Email'),
  Telephone: header.indexOf('Téléphone'),
  DateNaissance: header.indexOf('Date de naissance'),
  ResponsableLegal: header.indexOf('Responsable légal'),
  TelResponsable: header.indexOf('Tél. responsable légal'),
  EmailResponsable: header.indexOf('Email responsable légal'),
  Adresse: header.indexOf('Adresse'),
  CodePostal: header.indexOf('Code postal'),
  Ville: header.indexOf('Ville'),
  Disciplines: header.indexOf('Disciplines'),
  NiveauxPratique: header.indexOf('Niveaux de pratique'),
  Formule: header.indexOf('Formule tarifaire'),
  ModePaiement: header.indexOf('Mode de paiement'),
  TailleHaut: header.indexOf('Taille haut'),
  TailleBas: header.indexOf('Taille bas'),
  Pointure: header.indexOf('Pointure'),
  DatePremiereInscription: header.indexOf('Date 1ère inscription'),
  Saisons: header.indexOf("Saison(s)"),
  StatutAdhesion: header.indexOf('Statut adhésion'),
};

const rows = [];
for (let i = 1; i < lines.length; i++) {
  const line = lines[i];
  if (!line.trim()) continue;
  const cols = line.split(';').map(s => s.trim());
  const get = idx => (cols[idx] || '').trim();
  const nom = get(COL.Nom);
  const prenom = get(COL.Prenom);
  if (!nom || !prenom) continue;

  const disciplines = get(COL.Disciplines)
    ? get(COL.Disciplines).split(',').map(s => s.trim()).filter(Boolean)
    : [];
  const saisons = get(COL.Saisons)
    ? get(COL.Saisons).split(',').map(s => s.trim()).filter(Boolean)
    : [];

  rows.push({
    last_name: nom,
    first_name: prenom,
    email: get(COL.Email) || null,
    phone: get(COL.Telephone) || null,
    birth_date: parseDate(get(COL.DateNaissance)),
    parent_name: get(COL.ResponsableLegal) || null,
    parent_phone: get(COL.TelResponsable) || null,
    parent_email: get(COL.EmailResponsable) || null,
    address: get(COL.Adresse) || null,
    postal_code: get(COL.CodePostal) || null,
    city: get(COL.Ville) || null,
    disciplines,
    practice_levels: null,
    formule: get(COL.Formule) || null,
    payment_method: get(COL.ModePaiement) || null,
    size_top: get(COL.TailleHaut) || null,
    size_bottom: get(COL.TailleBas) || null,
    shoe_size: get(COL.Pointure) || null,
    date_premiere_inscription: parseDate(get(COL.DatePremiereInscription)),
    saisons,
    statut_adhesion: get(COL.StatutAdhesion) || null,
  });
}

// Generate SQL
const BATCH = 10;
let out = [];
out.push('BEGIN;');
out.push('');

// Batch inserts for students
for (let b = 0; b < rows.length; b += BATCH) {
  const batch = rows.slice(b, b + BATCH);
  const values = batch.map((r, i) => {
    const n = b + i + 1;
    return `(${n},'${escape(r.last_name)}','${escape(r.first_name)}',${r.email?`'${escape(r.email)}'`:'NULL'},${r.phone?`'${escape(r.phone)}'`:'NULL'},${r.birth_date?`'${r.birth_date}'`:'NULL'},${r.parent_name?`'${escape(r.parent_name)}'`:'NULL'},${r.parent_phone?`'${escape(r.parent_phone)}'`:'NULL'},${r.parent_email?`'${escape(r.parent_email)}'`:'NULL'},${r.address?`'${escape(r.address)}'`:'NULL'},${r.postal_code?`'${escape(r.postal_code)}'`:'NULL'},${r.city?`'${escape(r.city)}'`:'NULL'},${pgArray(r.disciplines)},NULL,${r.formule?`'${escape(r.formule)}'`:'NULL'},${r.payment_method?`'${escape(r.payment_method)}'`:'NULL'},${r.size_top?`'${escape(r.size_top)}'`:'NULL'},${r.size_bottom?`'${escape(r.size_bottom)}'`:'NULL'},${r.shoe_size?`'${escape(r.shoe_size)}'`:'NULL'},${r.date_premiere_inscription?`'${r.date_premiere_inscription}'`:'NULL'},${pgArray(r.saisons)},${r.statut_adhesion?`'${escape(r.statut_adhesion)}'`:'NULL'},true,false,false,false)`;
  }).join(',\n');
  out.push(`INSERT INTO students (id,last_name,first_name,email,phone,birth_date,parent_name,parent_phone,parent_email,address,postal_code,city,disciplines,practice_levels,formule,payment_method,size_top,size_bottom,shoe_size,date_premiere_inscription,saisons,statut_adhesion,active,droit_image,certificat_medical,unsubscribed) VALUES\n${values};`);
}

out.push('');
out.push('COMMIT;');

fs.writeFileSync('/tmp/students_insert.sql', out.join('\n'), 'utf8');
console.log(`Generated /tmp/students_insert.sql — ${rows.length} rows, ${Math.ceil(rows.length/BATCH)} batches`);

// Generate discipline inserts (based on student ids)
const discOut = ['BEGIN;'];
discOut.push('DELETE FROM student_disciplines;');
let discInserts = [];
rows.forEach((r, idx) => {
  const studentId = idx + 1;
  r.disciplines.forEach(discName => {
    const discId = DISCIPLINE_MAP[discName.trim()];
    if (discId) {
      discInserts.push(`(${studentId},${discId})`);
    }
  });
});
// Batch in groups of 50
for (let i = 0; i < discInserts.length; i += 50) {
  discOut.push(`INSERT INTO student_disciplines (student_id,discipline_id,enrolled_at) VALUES ${discInserts.slice(i, i+50).join(',')};`);
}
discOut.push('COMMIT;');
fs.writeFileSync('/tmp/disciplines_insert.sql', discOut.join('\n'), 'utf8');

// Generate saison inserts
const saisonsOut = ['BEGIN;'];
saisonsOut.push('DELETE FROM student_saisons;');
const saisonsInserts = rows.map((_, idx) => `(${idx+1},1,true,false,0,0,0)`).join(',');
saisonsOut.push(`INSERT INTO student_saisons (student_id,saison_id,adhesion_payee,adhesion_incluse,cours_unite_count,versements_cents,amount_paid_cents,created_at) VALUES ${saisonsInserts}, (SELECT 1,1,true,false,0,0,0,NOW()) ON CONFLICT DO NOTHING;`);
saisonsOut.push('COMMIT;');
fs.writeFileSync('/tmp/saisons_insert.sql', saisonsOut.join('\n'), 'utf8');
console.log(`Generated disciplines + saisons SQL files`);