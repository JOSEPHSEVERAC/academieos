// services/r2.js
// Owns: Polsia R2 object storage via the Polsia R2 proxy.
// Does NOT own: CDN URLs, signed URLs.
// Upload: POST to https://polsia.com/api/proxy/r2/upload with Authorization: Bearer POLSIA_API_KEY.
// Format: POST multipart/form-data with 'file' field (raw binary).
// Proxy returns { success: true, file: { url: "https://pub-..." } }.
//
// This module now delegates uploads to services/storage.js, which selects
// between Bunny.net, Cloudflare R2 (S3-compatible), or the Polsia proxy.
// fetchAndStream is unchanged — it streams from R2 URLs already stored in the DB.

const fetch = require('node-fetch');
const FormData = require('form-data');
const storage = require('./storage');

const POLSIA_API_KEY = process.env.POLSIA_API_KEY;
const R2_UPLOAD_URL  = 'https://polsia.com/api/proxy/r2/upload';
const R2_PUBLIC_HOST = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev';

function isConfigured() {
  return storage.isConfigured();
}

async function uploadBuffer(buffer, filename, contentType) {
  return storage.upload(buffer, filename, contentType);
}

async function uploadFromBase64(base64, filename, contentType) {
  return storage.upload(Buffer.from(base64, 'base64'), filename, contentType);
}

async function uploadVideoToR2(base64, filename, mimeType) {
  return storage.upload(Buffer.from(base64, 'base64'), filename, mimeType);
}

async function uploadFile(base64, subdir, filename, mimeType) {
  const safeName = (filename || 'file').replace(/[^a-zA-Z0-9._-]/g, '_');
  return uploadFromBase64(base64, `${subdir}/${safeName}`, mimeType);
}

async function fetchAndStream(url, res, { contentType, filename, range }) {
  const headers = { Authorization: `Bearer ${POLSIA_API_KEY}` };
  const fetchOptions = range
    ? { headers, range: { start: range.start, end: range.end } }
    : { headers };

  const remoteRes = await fetch(url, fetchOptions);

  if (!remoteRes.ok && remoteRes.status !== 206) {
    throw new Error(`R2 fetch failed: HTTP ${remoteRes.status}`);
  }

  const remoteStatus = remoteRes.status;
  const remoteRange   = remoteRes.headers.get('content-range');
  const remoteSize    = remoteRes.headers.get('content-length');

  res.setHeader('Content-Type', contentType || 'video/mp4');
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'private, max-age=3600');
  if (filename) res.setHeader('Content-Disposition', `inline; filename="${filename}"`);

  if (range && remoteStatus === 206 && remoteRange) {
    res.setHeader('Content-Range', remoteRange);
    res.setHeader('Content-Length', remoteSize);
    res.status(206);
  } else if (range) {
    res.setHeader('Content-Length', remoteSize || '*');
    res.status(200);
  } else {
    res.setHeader('Content-Length', remoteSize || '*');
    res.status(200);
  }

  if (remoteRes.body) {
    for await (const chunk of remoteRes.body) { res.write(chunk); }
    res.end();
  } else {
    res.end();
  }
}

module.exports = { uploadBuffer, uploadFromBase64, uploadVideoToR2, uploadFile, isConfigured, fetchAndStream };