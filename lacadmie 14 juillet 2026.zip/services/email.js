// services/email.js
// Owns: transactional email composition + sending via Resend (default) or
// SMTP (admin-managed). Reads `email_smtp_config` on every send so an admin
// can swap providers / from-address without redeploying.
// Does NOT own: email campaign batch sends (routes/messaging.js),
//               social notifications (services/notifications.js),
//               Resend wiring (services/resend.js), DB table
//               (migrations/203…_email_smtp_config_and_app_settings.js).
//
// Provider switch (column `provider` in `email_smtp_config`, admin-managed):
//   - 'resend'  → existing path via Resend (`lacademie.art` verified domain)
//   - 'smtp'    → Nodemailer against `smtp_host` / `smtp_port` columns
//   - '' (cold) → defaults to Resend so the existing flow is unchanged
//
// From-address resolution order at send time:
//   1. opts.from (caller override)
//   2. email_smtp_config.from_address + from_name (admin override)
//   3. email_sender_config (legacy Resend sender address table)
//   4. process.env.FROM_EMAIL + L'Académie
//
// Pool is hooked once at startup via `setPool(pool)`. Call sites keep their
// minimal signature: sendEmail(to, subject, body, html?, opts?).

const crypto = require('crypto');
const { getResendClient, verifyDomainOnce } = require('./resend');
const emailConfig = require('../db/email-config');

const DEFAULT_FROM_EMAIL = process.env.FROM_EMAIL || 'contact@lacademie.art';
const DEFAULT_FROM_NAME = "L'Académie";

let _pool = null;
function setPool(pool) { _pool = pool; }

// Memoized SMTP transport cache. Re-using one nodemailer transport across
// sends avoids a fresh TLS handshake on every email; the cache key is a
// sha1 of the credential tuple so a config edit picks up on the next call.
let _smtpTransport = null;
let _smtpTransportSig = null;

function transportSig(cfg) {
  return crypto
    .createHash('sha1')
    .update(
      `${cfg.host || ''}|${cfg.port || ''}|${cfg.secure === null ? '' : !!cfg.secure}|${cfg.user || ''}|${cfg.password || ''}`
    )
    .digest('hex');
}

function getSmtpTransport(cfg) {
  const sig = transportSig(cfg);
  if (_smtpTransport && _smtpTransportSig === sig) return _smtpTransport;
  // Lazy require so we only pay the cost when the admin actually flips
  // the SMTP switch (this file is required at startup regardless).
  const nodemailer = require('nodemailer');
  _smtpTransport = nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.secure,
    auth: cfg.user || cfg.password ? { user: cfg.user || '', pass: cfg.password || '' } : undefined,
  });
  _smtpTransportSig = sig;
  return _smtpTransport;
}

function resetSmtpTransport() {
  _smtpTransport = null;
  _smtpTransportSig = null;
}

/**
 * Resolve the From header. Order:
 *   1. opts.from (caller override, used for one-offs)
 *   2. email_smtp_config (admin-managed, takes precedence)
 *   3. email_sender_config (legacy Resend sender selection)
 *   4. process.env.FROM_EMAIL + default name
 *
 * Each DB read is wrapped in try/catch so a pre-migration cold start
 * doesn't crash the app.
 */
async function resolveFrom(optsFrom) {
  if (optsFrom) return optsFrom;
  if (_pool) {
    // 1. email_smtp_config — admin override wins so admins can globally
    //    change the From header from the CRM without redeploy.
    try {
      if (emailConfig && typeof emailConfig.getActiveConfig === 'function') {
        const cfg = await emailConfig.getActiveConfig(_pool);
        if (cfg && cfg.from_address) {
          const name = cfg.from_name || DEFAULT_FROM_NAME;
          return `${name} <${cfg.from_address}>`;
        }
      }
    } catch (err) {
      // email_smtp_config may not exist yet on cold starts — fall through.
    }
    // 2. email_sender_config — legacy Resend-sender-selection table.
    try {
      const result = await _pool.query(
        `SELECT sender_email, sender_name FROM email_sender_config ORDER BY id LIMIT 1`
      );
      if (result.rows && result.rows[0] && result.rows[0].sender_email) {
        const name = result.rows[0].sender_name || DEFAULT_FROM_NAME;
        return `${name} <${result.rows[0].sender_email}>`;
      }
    } catch (err) {
      // email_sender_config may not exist yet on cold starts — fall through.
    }
  }
  return `${DEFAULT_FROM_NAME} <${DEFAULT_FROM_EMAIL}>`;
}

/**
 * Send via Resend (default path). Identical behavior to the previous
 * implementation except for the new from-resolution order above.
 */
async function sendViaResend({ to, subject, body, html, from }) {
  // Step 0: verify provider once per process — blocks send if `lacademie.art`
  // is not in `verified` state.
  try {
    await verifyDomainOnce();
  } catch (verifyErr) {
    console.error(`[resend] provider NOT verified — refusing send to=${to} code=${verifyErr.code || 'unknown'} msg="${verifyErr.message}"`);
    throw verifyErr;
  }

  const client = getResendClient();
  if (!client) {
    const msg = `[resend] RESEND_API_KEY not configured — cannot send to ${to}`;
    console.error(msg);
    throw new Error(msg);
  }

  const payload = { from, to, subject, text: body, ...(html ? { html } : {}) };
  try {
    const result = await client.emails.send(payload);
    if (result.error) {
      const err = new Error(result.error.message || 'Resend send failed');
      err.name = result.error.name || 'resend_send_error';
      throw err;
    }
    const message = result.data;
    return { id: message?.id || null, ...message };
  } catch (err) {
    console.error(`[resend] send rejected — to=${to} message="${err.message}"`);
    throw err;
  }
}

/**
 * Send via SMTP using the admin-managed credentials. Nodemailer transport
 * is cached per credential fingerprint so a healthy config doesn't reopen
 * a TLS socket on every send.
 */
async function sendViaSmtp({ to, subject, body, html, from, transportCfg }) {
  if (!transportCfg.host || !transportCfg.port) {
    const msg = `[smtp] host/port requis pour provider=smtp — vérifiez la configuration admin.`;
    const err = new Error(msg);
    err.code = 'smtp_not_configured';
    throw err;
  }
  const transport = getSmtpTransport(transportCfg);
  console.log(`[smtp] Sending — to=${to} host=${transportCfg.host}:${transportCfg.port} subject="${subject}" source=${transportCfg.source}`);
  try {
    const info = await transport.sendMail({
      from,
      to,
      subject,
      text: body,
      ...(html ? { html } : {}),
    });
    return { id: info.messageId || null, ...info };
  } catch (err) {
    // Nodemailer uses err.responseCode for SMTP status codes; surface it
    // so the admin's "Tester la configuration" UI tells 535 (auth) from
    // 550 (recipient blocked) at a glance.
    console.error(`[smtp] send rejected — to=${to} code=${err.responseCode || 'n/a'} message="${err.message}"`);
    err.code = err.code || `smtp_${err.responseCode || 'error'}`;
    throw err;
  }
}

/**
 * Top-level send. Picks provider based on the admin-managed row in
 * `email_smtp_config`. Callers don't need to know which transport will
 * be used — magic links, invitations, and password-resets all funnel
 * through this entry point.
 */
async function sendEmail(to, subject, body, html = null, opts = {}) {
  // Resolve transport config only if SMTP is the active provider — most
  // existing sends will hit the Resend fast path.
  let provider = 'resend';
  let transportCfg = null;
  if (_pool) {
    try {
      transportCfg = await emailConfig.getEffectiveTransportConfig(_pool);
      provider = transportCfg.provider;
    } catch (err) {
      // Cold start before migration ran — fall through to Resend.
      transportCfg = null;
      provider = 'resend';
    }
  }

  const from = await resolveFrom(opts.from);

  if (provider === 'smtp') {
    return sendViaSmtp({ to, subject, body, html, from, transportCfg });
  }
  return sendViaResend({ to, subject, body, html, from });
}

// Test hook so an admin PUT that flows a new SMTP password through the
// system immediately invalidates the cached nodemailer transport — without
// this, the new password wouldn't take effect until the next deploy.
function invalidateSmtpTransport() {
  resetSmtpTransport();
}

module.exports = {
  sendEmail,
  setPool,
  invalidateSmtpTransport,
};
