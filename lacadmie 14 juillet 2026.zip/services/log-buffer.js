// services/log-buffer.js
// In-memory circular buffer for upload diagnostics. Max 500 entries.
// Shared singleton: both upload routes and the debug endpoint require this file.

const MAX_ENTRIES = 500;
const logBuf = [];

function uploadLog(message) {
  const now = new Date();
  const ts = now.toTimeString().slice(0, 8) + '.' + String(now.getMilliseconds()).padStart(3, '0');
  const line = `[UPLOAD ${ts}] ${message}`;
  console.log(line);
  logBuf.push(line);
  if (logBuf.length > MAX_ENTRIES) logBuf.splice(0, logBuf.length - MAX_ENTRIES);
}

function getRecentLogs() {
  return logBuf.slice();
}

module.exports = { logBuf, uploadLog, getRecentLogs };
