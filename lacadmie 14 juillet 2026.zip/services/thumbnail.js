// services/thumbnail.js
// Owns: Video thumbnail extraction via ffmpeg-static.
// Does NOT own: R2 upload (delegates to services/r2.js).
// Falls back gracefully when ffmpeg is unavailable or extraction fails.

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { uploadBuffer, isConfigured: isR2Configured } = require('./r2');

// ffmpeg-static bundles a platform-specific binary with no system dependency.
// The package exposes the binary path via require.resolve().
let FFMPEG_PATH;
try {
  FFMPEG_PATH = require('ffmpeg-static');
} catch (e) {
  FFMPEG_PATH = null;
}

/**
 * Extract a JPEG thumbnail from a video file at the midpoint frame.
 * Falls back to 1-second mark if duration cannot be determined.
 *
 * @param {string} videoPath  — absolute path to the local video file
 * @returns {Promise<Buffer>} raw JPEG image bytes
 */
async function extractFrame(videoPath) {
  if (!FFMPEG_PATH) {
    throw new Error('ffmpeg-static not installed');
  }
  if (!fs.existsSync(videoPath)) {
    throw new Error('Video file not found: ' + videoPath);
  }

  // ── Step 1: probe duration via ffprobe ───────────────────────────────────────
  const durationSec = await getDuration(videoPath);

  // ── Step 2: extract frame at duration / 2 ─────────────────────────────────────
  const seekTime = durationSec > 0 ? Math.max(0, durationSec / 2) : 1;

  return new Promise((resolve, reject) => {
    const args = [
      '-ss', String(seekTime),
      '-i', videoPath,
      '-vframes', '1',
      '-vf', 'scale=480:-1',
      '-f', 'image2pipe',
      '-vcodec', 'mjpeg',
      '-'
    ];

    let stderr = '';
    const proc = spawn(FFMPEG_PATH, args, {
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, PATH: process.env.PATH },
    });

    const chunks = [];
    proc.stdout.on('data', chunk => chunks.push(chunk));
    proc.stderr.on('data', chunk => { stderr += chunk.toString(); });

    proc.on('close', code => {
      if (code !== 0) {
        reject(new Error(`ffmpeg exited ${code}: ${stderr.substring(0, 200)}`));
        return;
      }
      const buf = Buffer.concat(chunks);
      if (buf.length === 0) {
        reject(new Error('ffmpeg produced empty output'));
        return;
      }
      resolve(buf);
    });

    proc.on('error', err => reject(err));
  });
}

/**
 * Probe video duration in seconds using ffprobe (bundled with ffmpeg-static).
 * Returns 0 on failure.
 */
async function getDuration(videoPath) {
  if (!FFMPEG_PATH) return 0;

  // Try ffprobe first (typically alongside ffmpeg in ffmpeg-static)
  let ffprobePath = FFMPEG_PATH.replace(/[\\/]ffmpeg$/, '/ffprobe');
  if (!fs.existsSync(ffprobePath)) {
    // ffmpeg-static bundles everything in the same directory
    const dir = path.dirname(FFMPEG_PATH);
    const candidates = ['ffprobe', 'ffprobe.exe', 'ffmpeg/bin/ffprobe', 'ffmpeg/bin/ffprobe.exe'];
    ffprobePath = candidates.map(c => path.join(dir, c)).find(p => fs.existsSync(p)) || null;
  }

  if (!ffprobePath || !fs.existsSync(ffprobePath)) {
    // Fall back to ffmpeg -i (less reliable but works in a pinch)
    try {
      const out = await execCapture(FFMPEG_PATH, ['-i', videoPath]);
      const m = out.match(/Duration: (\\d+):(\\d+):(\u0000-\u0039.)/);
      if (m) return parseInt(m[1]) * 3600 + parseInt(m[2]) * 60 + parseFloat(m[3]);
    } catch (_) {}
    return 0;
  }

  return new Promise((resolve) => {
    const proc = spawn(ffprobePath, [
      '-v', 'error',
      '-show_entries', 'format=duration',
      '-of', 'default=noprint_wrappers=1:nokey=1',
      videoPath,
    ], { stdio: ['ignore', 'pipe', 'pipe'] });

    let stdout = '';
    proc.stdout.on('data', chunk => { stdout += chunk.toString(); });
    proc.on('close', code => {
      if (code === 0) {
        const n = parseFloat(stdout.trim());
        resolve(isNaN(n) ? 0 : n);
      } else {
        resolve(0);
      }
    });
    proc.on('error', () => resolve(0));
  });
}

function execCapture(cmd, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '', err = '';
    proc.stdout.on('data', c => { out += c.toString(); });
    proc.stderr.on('data', c => { err += c.toString(); });
    proc.on('close', code => {
      if (code === 0) resolve(out); else reject(new Error(err.substring(0, 200)));
    });
    proc.on('error', reject);
  });
}

/**
 * Extract thumbnail and return the raw JPEG buffer.
 * Caller is responsible for: persisting to DB (bytea) and/or uploading to R2.
 * The JPEG buffer can be stored directly in reseau_videos.thumbnail_data
 * for permanent, non-ephemeral thumbnail persistence.
 *
 * @param {string} videoFilePath  — video file path (absolute or relative "videos/foo.mp4")
 * @returns {Promise<Buffer|null>} raw JPEG bytes, or null on failure
 */
async function extractAndUpload(videoFilePath) {
  try {
    if (!FFMPEG_PATH) {
      console.error('[thumbnail] ffmpeg-static unavailable — cannot extract frame');
      return null;
    }

    // Resolve absolute path for ffmpeg (videoFilePath may be relative like "videos/foo.mp4")
    const absPath = path.isAbsolute(videoFilePath)
      ? videoFilePath
      : path.join(__dirname, '..', videoFilePath.replace(/^\/+/, ''));

    const timeoutMs = 45000;
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('thumbnail_extraction_timeout')), timeoutMs)
    );

    const extractPromise = (async () => {
      const jpeg = await extractFrame(absPath);
      if (!jpeg || jpeg.length === 0) {
        console.error('[thumbnail] extractFrame returned empty buffer');
        return null;
      }

      // Also try to upload to R2 for CDN-backed thumbnail URLs (optional, non-blocking)
      if (isR2Configured()) {
        try {
          const filename = `thumb_${Date.now()}_${Math.random().toString(36).slice(2)}.jpg`;
          const url = await uploadBuffer(jpeg, filename, 'image/jpeg');
          console.log(`[thumbnail] R2 upload OK → ${url}`);
          return { jpeg, r2Url: url };
        } catch (r2Err) {
          console.warn(`[thumbnail] R2 upload failed (${r2Err.message}), storing bytea only`);
        }
      }

      console.log(`[thumbnail] storing bytea only (${(jpeg.length / 1024).toFixed(0)} KB)`);
      return { jpeg, r2Url: null };
    })();

    return await Promise.race([extractPromise, timeoutPromise]);
  } catch (err) {
    if (err.message === 'thumbnail_extraction_timeout') {
      console.error('[thumbnail] extraction timed out after 45s — skipping thumbnail');
    } else {
      console.error(`[thumbnail] extraction failed (non-fatal): ${err.message}`);
    }
    return null;
  }
}

module.exports = { extractAndUpload };