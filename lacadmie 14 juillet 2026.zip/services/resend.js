// services/resend.js
// Owns: Resend API client + sender-domain policy.
// Does NOT own: email composition (services/email.js), campaign batch sends
// (routes/messaging.js), social notifications (services/notifications.js).
//
// Auth: Bearer token via RESEND_API_KEY env var.
// Domain: verified `lacademie.art` (sender `send.lacademie.art`).
//
// Pattern mirrors services/printful.js + services/cloudflare-stream.js.

const { Resend } = require('resend');

// Domains Resend is allowed to send from on behalf of L'Académie.
// Used by routes/admin-sender-config.js to reject any sender outside this list.
const ALLOWED_FROM_DOMAINS = ['lacademie.art'];

// Hard-coded allowlist of approved sender identities. Resend rejects unverified
// From addresses and the error message is opaque — keep this list curated
// inside the app (one config row, surfaced via ADMIN UI) rather than letting
// ad-hoc values slip through.
const ALLOWED_FROM_ADDRESSES = ['contact@lacademie.art', 'gregory@lacademie.art'];

let _client = null;
let _logged = false;
let _verified = false;
let _verifiedStatus = null;
let _verifiedRegion = null;

function getResendClient() {
  if (_client) return _client;
  const key = process.env.RESEND_API_KEY;
  if (!key) {
    console.warn('[startup] RESEND_API_KEY: MISSING — transactional emails will fail');
    _logged = true;
    return null;
  }
  if (!_logged) {
    console.log(`[startup] RESEND_API_KEY: present (len=${key.length})`);
    _logged = true;
  }
  _client = new Resend(key);
  return _client;
}

// Verify the Resend domain is live and ready to send. Called once per
// process before any sendEmail() — surfaces a hard error if `lacademie.art`
// is not in `verified` state, since Resend silently rejects unverified senders.
async function verifyDomainOnce() {
  if (_verified) {
    return { status: _verifiedStatus, region: _verifiedRegion };
  }
  const client = getResendClient();
  if (!client) {
    const err = new Error('Resend client not configured — RESEND_API_KEY is missing');
    err.code = 'resend_key_missing';
    throw err;
  }
  try {
    const r = await client.domains.list();
    const list = (r && r.data && Array.isArray(r.data.data)) ? r.data.data : [];
    const lacademie = list.find(d => d && d.name === 'lacademie.art');
    const status = lacademie ? (lacademie.status || 'unknown') : 'not_found';
    const region = lacademie ? (lacademie.region || 'unknown') : 'unknown';
    _verifiedStatus = status;
    _verifiedRegion = region;
    _verified = true;
    console.log(`[startup] Resend domain lacademie.art status=${status} region=${region}`);
    if (status !== 'verified') {
      const err = new Error(`Resend domain lacademie.art not verified (status=${status})`);
      err.code = 'domain_not_verified';
      err.status = status;
      throw err;
    }
    return { status, region };
  } catch (err) {
    if (err.code === 'domain_not_verified' || err.code === 'resend_key_missing') throw err;
    console.warn(`[startup] Resend domains.list probe failed: ${err.message}`);
    const wrapped = new Error(`Resend domain verification probe failed: ${err.message}`);
    wrapped.code = 'domain_probe_failed';
    throw wrapped;
  }
}

function isConfigured() {
  return !!process.env.RESEND_API_KEY;
}

module.exports = {
  getResendClient,
  verifyDomainOnce,
  isConfigured,
  ALLOWED_FROM_DOMAINS,
  ALLOWED_FROM_ADDRESSES,
};
