// services/cloudflare-stream.js
// Owns: Cloudflare Stream API integration.
//   - Direct upload URL creation (browser → CF Stream TUS endpoint)
//   - Video status polling / thumbnail URL extraction
//   - Video deletion (best-effort cleanup on DB delete)
// Does NOT own: photo storage (services/r2.js / services/storage.js), Stream
// iframe rendering (frontend), access control (routes/reseau-videos.js).
//
// Auth: Bearer token via CLOUDFLARE_STREAM_TOKEN (DB row in
// media_provider_config.api_token takes precedence when set, otherwise
// process.env.CLOUDFLARE_STREAM_TOKEN is used as a last-resort fallback).
// Account: CLOUDFLARE_ACCOUNT_ID (media_provider_config.account_id same fallback).
// Public base: media_provider_config.public_base_url, falling back to
// process.env.CLOUDFLARE_PUBLIC_BASE_URL when blank.
// Base URL: https://api.cloudflare.com/client/v4
// Endpoint reference: POST /accounts/{account_id}/stream/direct_upload
//                     GET /accounts/{account_id}/stream/{uid}
//                     DELETE /accounts/{account_id}/stream/{uid}
//
// requireSignedURLs is left at default (false) so the browser can POST files
// directly to the uploadURL returned by the API — access control is enforced
// server-side in routes/reseau-videos.js at /:id/stream.

const fetch = require('node-fetch');

const CF_API_BASE = 'https://api.cloudflare.com/client/v4';

let _pool = null;
function setPool(pool) { _pool = pool; }

async function getStreamConfig() {
  if (_pool) {
    try {
      const mediaConfig = require('./../db/media-config');
      const cfg = await mediaConfig.getEffectiveStreamConfig(_pool);
      if (cfg) return cfg;
    } catch (err) {
      console.warn('[cloudflare-stream] DB read failed, falling through to env:', err.message);
    }
  }
  // Env fallback for cold starts / unconfigured deploys.
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID || null;
  const token = process.env.CLOUDFLARE_STREAM_TOKEN || null;
  if (!accountId || !token) return null;
  return {
    provider: 'cloudflare_stream',
    accountId,
    token,
    publicBaseUrl: process.env.CLOUDFLARE_PUBLIC_BASE_URL || null,
    source: 'env',
  };
}

async function getAccountId() {
  const cfg = await getStreamConfig();
  return cfg ? cfg.accountId : null;
}

async function getToken() {
  const cfg = await getStreamConfig();
  return cfg ? cfg.token : null;
}

async function isConfigured() {
  const cfg = await getStreamConfig();
  return !!(cfg && cfg.accountId && cfg.token);
}

async function authHeaders() {
  const cfg = await getStreamConfig();
  return {
    'Authorization': `Bearer ${cfg.token}`,
    'Content-Type': 'application/json',
  };
}

/**
 * Request a direct upload URL from Cloudflare Stream.
 * The browser PUTs/POSTs the file to uploadURL (TUS-compatible), then we
 * finalize via getVideo(uid) and persist the resulting UID + thumbnail URL.
 *
 * @param {Object} [opts]
 * @param {number} [opts.maxDurationSeconds=7200] — Cloudflare rejects uploads beyond this
 * @returns {Promise<{ uploadURL: string, uid: string }>}
 */
async function createDirectUploadLocation({ maxDurationSeconds = 7200 } = {}) {
  const cfg = await getStreamConfig();
  if (!cfg) {
    throw new Error('Cloudflare Stream non configuré — CLOUDFLARE_ACCOUNT_ID / CLOUDFLARE_STREAM_TOKEN manquants');
  }

  const url = `${CF_API_BASE}/accounts/${cfg.accountId}/stream/direct_upload`;
  const body = {
    maxDurationSeconds,
    creator: 'reseau-app',
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: await authHeaders(),
    body: JSON.stringify(body),
  });

  const json = await res.json().catch(() => ({}));

  if (!res.ok || !json.success || !json.result) {
    const messages = (json.errors || []).map(e => e.message).join('; ') || `HTTP ${res.status}`;
    throw new Error(`Cloudflare Stream direct_upload failed: ${messages}`);
  }

  return {
    uploadURL: json.result.uploadURL,
    uid: json.result.uid,
  };
}

/**
 * Fetch a stream video's status and metadata.
 * Once status.readyToStream === true, the HLS manifest is mounted under
 * https://videodelivery.net/{uid}/manifest/video.m3u8 and the thumbnail
 * at https://videodelivery.net/{uid}/thumbnails/thumbnail.jpg.
 *
 * @param {string} uid
 * @returns {Promise<{ uid: string, readyToStream: boolean, status: string, duration: number|null, thumbnail: string, playback: { hls?: string, dash?: string } }>}
 */
async function getVideo(uid) {
  const cfg = await getStreamConfig();
  if (!cfg) {
    throw new Error('Cloudflare Stream non configuré');
  }

  const url = `${CF_API_BASE}/accounts/${cfg.accountId}/stream/${uid}`;
  const res = await fetch(url, { method: 'GET', headers: { 'Authorization': `Bearer ${cfg.token}` } });
  const json = await res.json().catch(() => ({}));

  if (!res.ok || !json.success || !json.result) {
    const messages = (json.errors || []).map(e => e.message).join('; ') || `HTTP ${res.status}`;
    throw new Error(`Cloudflare Stream getVideo failed: ${messages}`);
  }

  const r = json.result;
  return {
    uid: r.uid,
    readyToStream: !!r.readyToStream,
    status: r.status?.state || (r.readyToStream ? 'ready' : 'inprogress'),
    duration: typeof r.duration === 'number' ? r.duration : null,
    thumbnail: `https://videodelivery.net/${r.uid}/thumbnails/thumbnail.jpg`,
    playback: r.playback || {},
  };
}

/**
 * Delete a Cloudflare Stream video. Best-effort — failures are logged but
 * not surfaced (the caller has already or is about to delete the DB row).
 *
 * @param {string} uid
 * @returns {Promise<boolean>} true if deletion succeeded
 */
async function deleteVideo(uid) {
  if (!uid) return false;
  const cfg = await getStreamConfig();
  if (!cfg) return false;
  try {
    const url = `${CF_API_BASE}/accounts/${cfg.accountId}/stream/${uid}`;
    const res = await fetch(url, { method: 'DELETE', headers: { 'Authorization': `Bearer ${cfg.token}` } });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || !json.success) {
      const messages = (json.errors || []).map(e => e.message).join('; ') || `HTTP ${res.status}`;
      console.warn(`[cloudflare-stream] deleteVideo failed for ${uid}: ${messages}`);
      return false;
    }
    return true;
  } catch (err) {
    console.warn(`[cloudflare-stream] deleteVideo error for ${uid}: ${err.message}`);
    return false;
  }
}

module.exports = {
  isConfigured,
  createDirectUploadLocation,
  getVideo,
  deleteVideo,
  setPool,
  // Internal helpers exposed for advanced call sites / tests.
  getAccountId,
  getToken,
};
