// services/storage.js
// Unified external storage backend supporting Bunny.net, Cloudflare R2/S3,
// Cloudflare Stream (videos only, via services/cloudflare-stream.js), and a
// Polsia R2-proxy fallback.
//
// Provider resolution (every read goes through this; sync API kept stable
// for backwards-compat with existing sync callers like routes/reseau-*):
//   1. media_provider_config.provider (when non-empty).
//   2. process.env.STORAGE_PROVIDER ('r2' / 'bunny').
//   3. Auto-detect: Bunny if BUNNY_API_KEY+BUNNY_STORAGE_ZONE are set,
//      else R2 if R2_* are set, else Polsia proxy.
//   4. Polsia proxy fallback.
//
// Each provider's credentials resolve "DB column if non-empty, else
// process.env", so admins can migrate per-field. Sync getters (publicHost,
// isConfigured) read a module-level snapshot that is initialized from env
// at startup and refreshed whenever the async upload path resolves the DB.
// Async upload functions always pull fresh creds so admin edits take
// effect on the very next request without a redeploy.

const fetch = require('node-fetch');
const FormData = require('form-data');

const R2_PUBLIC_HOST_FALLBACK = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev';

let _pool = null;
function setPool(pool) { _pool = pool; }

/**
 * Snapshot of resolved provider, populated from env at module load and
 * refreshed via `refreshFromDb()` whenever the DB is consulted by an upload.
 * Sync getters (publicHost, isConfigured) read this snapshot only — they
 * do not block the event loop waiting for a DB roundtrip.
 */
const cache = {
  provider: null,        // 'bunny' | 'r2' | 'polsia'
  bunny: { apiKey: null, storageZone: null, cdnHost: null },
  r2:     { accountId: null, accessKeyId: null, secretAccessKey: null, bucket: null, endpoint: null, publicHost: null },
  polsia: { apiKey: null, apiUrl: null, imageProxyUrl: null, publicHost: R2_PUBLIC_HOST_FALLBACK },
};

function seedCacheFromEnv() {
  let provider = process.env.STORAGE_PROVIDER || '';
  if (provider !== 'r2' && provider !== 'bunny') {
    if (process.env.BUNNY_API_KEY && process.env.BUNNY_STORAGE_ZONE) provider = 'bunny';
    else if (
      process.env.R2_ACCOUNT_ID &&
      process.env.R2_ACCESS_KEY_ID &&
      process.env.R2_SECRET_ACCESS_KEY &&
      process.env.R2_BUCKET
    ) provider = 'r2';
    else provider = 'polsia';
  }
  cache.provider = provider;
  cache.bunny = {
    apiKey:      process.env.BUNNY_API_KEY       || null,
    storageZone: process.env.BUNNY_STORAGE_ZONE  || null,
    cdnHost:     process.env.BUNNY_CDN_HOST      || null,
  };
  cache.r2 = {
    accountId:       process.env.R2_ACCOUNT_ID        || null,
    accessKeyId:     process.env.R2_ACCESS_KEY_ID     || null,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || null,
    bucket:          process.env.R2_BUCKET            || null,
    endpoint:        null,
    publicHost:      process.env.R2_PUBLIC_HOST       || null,
  };
  if (!cache.r2.endpoint && cache.r2.accountId) {
    cache.r2.endpoint = `https://${cache.r2.accountId}.r2.cloudflarestorage.com`;
  }
  cache.polsia = {
    apiKey:        process.env.POLSIA_API_KEY         || null,
    apiUrl:        process.env.POLSIA_API_URL         || 'https://polsia.com/api',
    imageProxyUrl: process.env.POLSIA_IMAGE_PROXY_URL || null,
    publicHost:    R2_PUBLIC_HOST_FALLBACK,
  };
}
seedCacheFromEnv();

async function refreshFromDb() {
  if (!_pool) return;
  try {
    const mediaConfig = require('./../db/media-config');
    const cfg = await mediaConfig.getEffectiveStorageConfig(_pool);
    if (!cfg) return;
    cache.provider = cfg.provider;
    cache.bunny = cfg.bunny;
    cache.r2 = cfg.r2;
    cache.polsia = cfg.polsia;
    if (cfg.provider === 'r2' && !cache.r2.endpoint && cache.r2.accountId) {
      cache.r2.endpoint = `https://${cache.r2.accountId}.r2.cloudflarestorage.com`;
    }
  } catch (err) {
    console.warn('[storage] DB read failed, keeping env-seeded snapshot:', err.message);
  }
}

// ── Sync API (may return stale snapshot until an upload ran) ──────────────

function getProvider() {
  if (!cache.provider) seedCacheFromEnv();
  return cache.provider;
}

function publicHost() {
  if (cache.provider === 'bunny') {
    return cache.bunny.cdnHost || (cache.bunny.storageZone ? `${cache.bunny.storageZone}.storage.bunnycdn.com` : null);
  }
  if (cache.provider === 'r2') {
    return cache.r2.publicHost || (cache.r2.accountId ? `https://${cache.r2.accountId}.r2.dev` : R2_PUBLIC_HOST_FALLBACK);
  }
  return R2_PUBLIC_HOST_FALLBACK;
}

function isConfigured() {
  if (cache.provider === 'bunny') {
    return !!(cache.bunny.apiKey && cache.bunny.storageZone && cache.bunny.cdnHost);
  }
  if (cache.provider === 'r2') {
    return !!(cache.r2.accountId && cache.r2.accessKeyId && cache.r2.secretAccessKey && cache.r2.bucket);
  }
  return !!cache.polsia.apiKey;
}

// ── Async upload (hot-credential resolution) ──────────────────────────────

async function resolveConfig() {
  // Always pull fresh creds from DB so admin edits take effect on the very
  // next request without a restart. Falls back to env if the DB is silent.
  await refreshFromDb();
  return cache;
}

/**
 * Upload a buffer to the active storage provider.
 * @param {Buffer} buffer       — raw file bytes
 * @param {string} filename     — target filename (may include subdir prefix for Bunny)
 * @param {string} contentType  — MIME type
 * @returns {Promise<string>}    — public URL of the uploaded file
 */
async function upload(buffer, filename, contentType) {
  const cfg = await resolveConfig();
  switch (cfg.provider) {
    case 'bunny':
      return uploadBunny(buffer, filename, contentType, cfg);
    case 'r2':
      return uploadR2(buffer, filename, contentType, cfg);
    default:
      return uploadPolsia(buffer, filename, contentType, cfg);
  }
}

// Bunny.net Storage — PUT https://{zone}.storage.bunnycdn.com/{path}
// AccessKey is the API key used as Bearer in Authorization header
async function uploadBunny(buffer, filename, contentType, cfg = cache) {
  if (!cfg.bunny.apiKey || !cfg.bunny.storageZone) {
    throw new Error('Bunny.net non configuré — api_token / storage_zone manquants (DB ou env)');
  }

  const path = filename.startsWith('/') ? filename : `/${filename}`;
  const url = `https://${cfg.bunny.storageZone}.storage.bunnycdn.com${path}`;

  const res = await fetch(url, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${cfg.bunny.apiKey}`,
      'Content-Type': contentType || 'application/octet-stream',
    },
    body: buffer,
    signal: AbortSignal.timeout(30000),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Bunny.net upload failed ${res.status}: ${detail}`);
  }

  const cdn = cfg.bunny.cdnHost || `${cfg.bunny.storageZone}.storage.bunnycdn.com`;
  return `https://${cdn}${path}`;
}

// Cloudflare R2 — S3-compatible API
async function uploadR2(buffer, filename, contentType, cfg = cache) {
  if (!cfg.r2.accountId || !cfg.r2.accessKeyId || !cfg.r2.secretAccessKey || !cfg.r2.bucket) {
    throw new Error('R2 non configuré — account_id / access_key_id / secret_access_key / bucket manquants (DB ou env)');
  }

  let S3Client, PutObjectCommand;
  try {
    ({ Client: S3Client, PutObjectCommand } = require('@aws-sdk/client-s3'));
  } catch {
    throw new Error('R2 provider requires @aws-sdk/client-s3 — `npm install @aws-sdk/client-s3`');
  }

  const endpoint = cfg.r2.endpoint || `https://${cfg.r2.accountId}.r2.cloudflarestorage.com`;
  const client = new S3Client({
    region: 'auto',
    endpoint,
    credentials: {
      accessKeyId:     cfg.r2.accessKeyId,
      secretAccessKey: cfg.r2.secretAccessKey,
    },
  });

  const command = new PutObjectCommand({
    Bucket:      cfg.r2.bucket,
    Key:         filename,
    Body:        buffer,
    ContentType: contentType || 'application/octet-stream',
  });

  await client.send(command);

  const host = cfg.r2.publicHost || `https://${cfg.r2.accountId}.r2.dev`;
  return `${host}/${filename}`;
}

function getPolsiaUploadUrl(cfg = cache) {
  if (cfg.polsia.imageProxyUrl) return cfg.polsia.imageProxyUrl;
  const base = cfg.polsia.apiUrl.replace(/\/api$/, '');
  const m = (cfg.polsia.apiKey || '').match(/^company_(\d+)_/);
  const cid = m ? m[1] : '98213';
  return `${base}/api/company/${cid}/image/upload`;
}

// Polsia proxy fallback
async function uploadPolsia(buffer, filename, contentType, cfg = cache) {
  if (!cfg.polsia.apiKey) {
    throw new Error('Polsia R2 proxy non configuré — POLSIA_API_KEY manquant');
  }

  const formData = new FormData();
  formData.append('file', buffer, { filename, contentType });

  const uploadUrl = getPolsiaUploadUrl(cfg);
  const res = await fetch(uploadUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cfg.polsia.apiKey}`,
      ...formData.getHeaders(),
    },
    body: formData,
    signal: AbortSignal.timeout(50000),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`R2 proxy error ${res.status}: ${detail}`);
  }

  const json = await res.json();
  if (!json.success || !json.file?.url) {
    throw new Error(`R2 proxy returned unexpected format: ${JSON.stringify(json)}`);
  }
  return json.file.url;
}

module.exports = {
  provider: getProvider(),
  publicHost,
  upload,
  isConfigured,
  setPool,
  // Exposed for tests / admin tooling
  refreshFromDb,
};
