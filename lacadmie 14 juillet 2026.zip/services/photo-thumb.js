// services/photo-thumb.js
// Owns: Photo thumbnail generation via sharp (resize to ~300px-wide JPEG).
// Does NOT own: R2 upload (delegates to services/r2.js).

const { uploadBuffer, isConfigured: isR2Configured } = require('./r2');

/**
 * Resize an image to a ~300px-wide JPEG thumbnail.
 * @param {string} imageDataUri — data:image/...;base64,... URI
 * @returns {Promise<{jpeg: Buffer, r2Url: string|null}>}
 */
async function resizeImage(imageDataUri) {
  const sharp = require('sharp');
  const rawBase64 = imageDataUri.replace(/^data:[^;]+;base64,/, '');
  const buf = Buffer.from(rawBase64, 'base64');
  const jpeg = await sharp(buf)
    .resize(300, null, { withoutEnlargement: true, fit: 'inside' })
    .jpeg({ quality: 80 })
    .toBuffer();
  return jpeg;
}

/**
 * Generate a JPEG thumbnail and upload to R2 (non-blocking).
 * Falls back to bytea-only if R2 is unavailable.
 * @param {string} imageDataUri — data:image/...;base64,... URI
 * @returns {Promise<{jpeg: Buffer, r2Url: string|null}>}
 */
async function generateAndUpload(imageDataUri) {
  const jpeg = await resizeImage(imageDataUri);
  let r2Url = null;
  if (isR2Configured()) {
    try {
      const filename = `thumb_${Date.now()}_${Math.random().toString(36).slice(2)}.jpg`;
      r2Url = await uploadBuffer(jpeg, filename, 'image/jpeg');
      console.log(`[photo-thumb] R2 upload OK → ${r2Url}`);
    } catch (r2Err) {
      console.warn(`[photo-thumb] R2 upload failed (${r2Err.message}), storing bytea only`);
    }
  } else {
    console.log(`[photo-thumb] R2 not configured — storing bytea only (${(jpeg.length / 1024).toFixed(0)} KB)`);
  }
  return { jpeg, r2Url };
}

module.exports = { generateAndUpload };
