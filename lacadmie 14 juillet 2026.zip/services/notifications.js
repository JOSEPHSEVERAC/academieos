// services/notifications.js
// Owns: social-network notification dispatch seam.
// Does NOT own: actual email sending (services/email.js), recipient preference
// queries (users_reseau), audit log writes (server.js logAudit).
//
// Status: scaffolded — surfaces one log line per social event so the seam is
// verified wired at runtime but no email is dispatched yet. Future work will
// plug in Resend-based notification dispatch here.
//
// Concentrating the seam in this file keeps reseau route handlers free of
// email concerns and ensures every future change to "when do we notify, and
// how do we batch/dedupe/throttle" lands in one place.

const KINDS = new Set([
  'post_created',
  'comment_created',
  'reaction_added',
  'reaction_removed',
  'follow_added',
  'mention',
]);

/**
 * Notify a user of a social-network event. Currently a log-only stub.
 *
 * @param {object} pool  - PG pool (used for future recipient lookup)
 * @param {object} evt
 * @param {string} evt.kind              - one of KINDS
 * @param {number} evt.actorId           - users_reseau.id of the actor
 * @param {number} evt.recipientId       - users_reseau.id of the recipient
 * @param {string} [evt.entityType]      - 'post' | 'comment' | 'reaction' | 'follow'
 * @param {number} [evt.entityId]        - DB id of entityType row
 * @returns {Promise<{ ok: boolean, sent: boolean, reason: string }>}
 */
async function notifySocialEvent(pool, evt) {
  if (!evt || !KINDS.has(evt.kind)) {
    return { ok: false, sent: false, reason: 'unknown_kind' };
  }
  const actor = evt.actorId ?? 'n/a';
  const recipient = evt.recipientId ?? 'broadcast';
  // eslint-disable-next-line no-console
  console.log(`[notifications] scheduled social event: kind=${evt.kind} actor=${actor} recipient=${recipient} entity=${evt.entityType || 'n/a'}#${evt.entityId || 'n/a'}`);
  return { ok: true, sent: false, reason: 'scaffolded' };
}

module.exports = { notifySocialEvent, KINDS };
