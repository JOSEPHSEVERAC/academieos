// services/printful.js
// Printful REST API client. Handles:
//   - Catalog sync (list products/variants with cost pricing)
//   - Order creation (auto-fulfillment when adherent orders)
//   - Order status polling
// Auth: Bearer token via PRINTFUL_API_TOKEN env var.
// Base URL: https://api.printful.com

const PRINTFUL_API_URL = 'https://api.printful.com';

function getToken() {
  const t = process.env.PRINTFUL_API_TOKEN;
  if (!t) throw new Error('PRINTFUL_API_TOKEN is not configured — ask Grégory for his Personal Access Token');
  return t;
}

async function pfFetch(path, { method = 'GET', body = null } = {}) {
  const token = getToken();
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  };
  if (body) opts.body = JSON.stringify(body);

  const res = await fetch(`${PRINTFUL_API_URL}${path}`, opts);
  const json = await res.json();

  if (!res.ok) {
    const msg = json?.error?.message || `Printful API error ${res.status}`;
    throw new Error(msg);
  }
  return json.result;
}

// ── Catalog sync ─────────────────────────────────────────────────────────────

/**
 * Fetch all products from Printful catalog.
 * Returns an array of product objects with variants.
 */
async function getProducts() {
  return pfFetch('/products');
}

/**
 * Fetch a single Printful product with all variants.
 */
async function getProduct(productId) {
  return pfFetch(`/products/${productId}`);
}

/**
 * Fetch all sync products (user-created catalog items).
 * These include pricing and SKU mapping.
 */
async function getSyncProducts() {
  return pfFetch('/sync/products');
}

/**
 * Fetch one sync product.
 */
async function getSyncProduct(syncProductId) {
  return pfFetch(`/sync/products/${syncProductId}`);
}

// ── Order creation ───────────────────────────────────────────────────────────

/**
 * Create a Printful order for an adhèrent.
 *
 * @param {Object} opts
 * @param {string} opts.recipientName   — Full name (e.g. "Dupont Jean")
 * @param {string} opts.recipientEmail — Email of the adhèrent
 * @param {string} opts.recipientAddress — Address line 1
 * @param {string} opts.recipientCity  — City
 * @param {string} opts.recipientCountryCode — 2-letter ISO (FR, etc.)
 * @param {string} opts.recipientZip    — Postal code
 * @param {Array}  opts.items           — [{ sync_variant_id, quantity }]
 * @param {string} opts.retailLine      — "true" for end-customer retail pricing
 */
async function createOrder({
  recipientName,
  recipientEmail,
  recipientAddress,
  recipientCity,
  recipientCountryCode,
  recipientZip,
  items,
  retailLine = 'true',
}) {
  const nameParts = recipientName.trim().split(' ');
  const firstName = nameParts[0] || '';
  const lastName = nameParts.slice(1).join(' ') || '';

  return pfFetch('/orders', {
    method: 'POST',
    body: {
      external_id: undefined,
      shipping_method: undefined,
      recipient: {
        name: recipientName,
        first_name: firstName,
        last_name: lastName,
        email: recipientEmail,
        address1: recipientAddress,
        city: recipientCity,
        country_code: recipientCountryCode,
        zip: recipientZip,
      },
      items: items.map(item => ({
        sync_variant_id: item.sync_variant_id,
        quantity: item.quantity,
        retail_price: retailLine === 'true' ? undefined : undefined,
      })),
    },
  });
}

/**
 * Get order status from Printful.
 */
async function getOrder(orderId) {
  return pfFetch(`/orders/${orderId}`);
}

/**
 * List recent Printful orders (optionally filtered by status).
 */
async function getOrders({ status } = {}) {
  const qs = status ? `?status=${status}` : '';
  return pfFetch(`/orders${qs}`);
}

module.exports = {
  getProducts,
  getProduct,
  getSyncProducts,
  getSyncProduct,
  createOrder,
  getOrder,
  getOrders,
};