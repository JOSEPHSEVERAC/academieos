const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.connectOverCDP(process.env.CDP_URL);
  const page = await browser.newPage();
  const errors = [];
  page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });

  // Login
  await page.goto('https://lacademie.polsia.app/reseau/login');
  await page.waitForLoadState('networkidle');

  const html = await page.content();
  console.log('=== Login page ===');
  console.log('Title:', await page.title());
  console.log('Has email input:', html.includes('email') || html.includes('Email'));

  const inputs = await page.locator('input').all();
  console.log('Input count:', inputs.length);
  for (const inp of inputs) {
    console.log(' - type:', await inp.getAttribute('type'), '| placeholder:', await inp.getAttribute('placeholder'));
  }

  // Fill and submit login
  await page.fill('input[type="email"]', 'gregjs33260@gmail.com');
  await page.fill('input[type="password"]', 'TestPassword123');

  await Promise.all([
    page.waitForNavigation({ timeout: 10000 }),
    page.click('button[type="submit"], button:has-text("Se connecter")')
  ]).catch(() => console.log('Nav timeout (expected for SPA)'));

  // Check if we got redirected to /app
  await page.waitForTimeout(2000);
  const url = page.url();
  console.log('\n=== After login ===');
  console.log('URL:', url);

  // Navigate to /app explicitly
  await page.goto('https://lacademie.polsia.app/reseau/app');
  await page.waitForLoadState('networkidle');
  await page.waitForTimeout(3000);

  console.log('\n=== /reseau/app ===');
  console.log('URL:', page.url());
  const appHtml = await page.content();
  console.log('Has "Chargement":', appHtml.includes('Chargement'));
  console.log('Has feed:', appHtml.includes('feed') || appHtml.includes('L_ACADÉMIE'));
  console.log('Title:', await page.title());
  console.log('Console errors:', errors);

  await browser.close();
})().catch(err => { console.error('Error:', err.message); process.exit(1); });