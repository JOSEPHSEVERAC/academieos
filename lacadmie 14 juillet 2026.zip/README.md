# AcadémieOS

CRM pour l'école de danse L'Académie — gestion des inscriptions, planning,
présences hebdomadaires, paiements, exports PDF. Sert aussi une PWA tablette
pour faire l'appel en classe.

## Requirements

- Node.js 18+
- PostgreSQL database (Neon recommended)

## Environment Variables

See `server.js` and `services/*.js` for the full list. The platform env vars
required at boot are:

- `DATABASE_URL` — PostgreSQL connection string (required)
- `PORT` — Server port (default: 3000)
- `POLSIA_API_KEY` — Polsia platform API key (email + image proxy)
- `POLSIA_API_URL` — Polsia API base URL (default `https://polsia.com/api`)
- `PRINTFUL_API_TOKEN` — Printful Personal Access Token (boutique auto-fulfillment)
- `CLOUDFLARE_ACCOUNT_ID` — Cloudflare account ID for Cloudflare Stream
- `CLOUDFLARE_STREAM_TOKEN` — Cloudflare Stream API token (vidéos multi-Go)

All other credentials are managed at runtime through the admin section below.

## Endpoints

- `GET /` — Hello
- `GET /health` — Health check (verifies database connection)
- `GET /admin` — PRÉSIDENT-only hub (see Admin Section below)

## Admin Section

The `GET /admin` hub is the single landing page for everything the
PRÉSIDENT manages at runtime. It is reachable from the sidebar of
`/dashboard`, `/admin/eleves`, and `/admin/boutique2.html` — visible only
when the connected user has role `PRÉSIDENT`. Every endpoint below it
enforces `requireAuth(['PRÉSIDENT'])`, so a non-PRESIDENT who guesses the URL
still sees `/login.html` after the page's `checkAuth()` failure.

Three tabs (deep-linkable via `#medias`, `#email`, `#security`):

- **Médias** — Cloudflare Stream / Bunny / Cloudflare R2 / Polsia proxy
  credentials. Replaces `CLOUDFLARE_*`, `R2_*`, `BUNNY_*` env vars.
- **Email & SMTP** — Resend ↔ SMTP provider switch, host/port/user/password,
  test-send probe.
- **Sécurité** — 2FA method (today: TOTP), 2FA global enforcement toggle,
  magic-link toggle + TTL (1..168h) + custom email template.

All settings live in single-row tables: `media_provider_config`,
`email_smtp_config`, `app_settings`. Changes are picked up at runtime — no
redeploy required. The `app_settings` cache in `db/app-settings.js` is
invalidated automatically after every write so the next request sees the new
value (or at most within the 60s TTL).

Secrets — `api_token`, `secret_access_key`, `access_key_id`, `smtp_password` —
are masked to `••••••••` after the first save. Submit blank to keep the
existing secret; type a new one to overwrite.

Audit events written:

- `MEDIA_PROVIDER_CONFIG_UPDATED`
- `EMAIL_CONFIG_UPDATED`
- `EMAIL_SENDER_UPDATED`
- `EMAIL_TEST_SENT` / `EMAIL_TEST_FAILED`
- `TWO_FACTOR_GLOBAL_TOGGLED`
- `TWO_FACTOR_METHOD_CHANGED`
- `MAGIC_LINK_TOGGLED`
- `MAGIC_LINK_CONFIG_UPDATED`

The two standalone pages `/admin/media-config` and `/admin/email-config`
keep working as bookmarks — both gain an "← Admin hub" back-link pointing at
`/admin`.

## Local Development

```bash
npm install
DATABASE_URL="postgresql://..." npm run dev
```

`npm run migrate` applies DDL migrations before the server starts.

## Deployment

Configured for Render via `render.yaml`. The `/health` endpoint must return
200 for Render to keep the service up.
