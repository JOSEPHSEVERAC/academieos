const fs = require('fs');
const h = fs.readFileSync('public/reseau-app.html', 'utf8');

const need = ['<html', '</html>', '<body', '</body>'];
const missing = need.filter(t => h.includes(t) === false);
if (missing.length) {
  console.error('FAIL: missing required tags:', missing.join(', '));
  process.exit(1);
}
console.log('PASS: HTML structure valid');
console.log('File size:', (h.length / 1024).toFixed(1) + ' KB');
console.log('Line count:', h.split('\n').length);

// Try to parse the JS part
const lastScriptStart = h.lastIndexOf('<script>');
const lastScriptEnd = h.lastIndexOf('<\/script>');
if (lastScriptStart !== -1 && lastScriptEnd !== -1) {
  const js = h.slice(lastScriptStart + 8, lastScriptEnd);
  try {
    new Function(js);
    console.log('JS syntax: valid (Function constructor check)');
  } catch (e) {
    console.error('JS syntax error:', e.message);
    process.exit(1);
  }
}

// Check for duplicate function definitions
const funcMatches = js.matchAll(/^(?:async )?function (\b[a-zA-Z_][a-zA-Z0-9_]*\b)/gm);
const funcNames = {};
let duplicates = [];
for (const m of funcMatches) {
  const name = m[1];
  if (funcNames[name]) {
    duplicates.push(name);
  } else {
    funcNames[name] = true;
  }
}
if (duplicates.length > 0) {
  console.error('Duplicate function definitions:', duplicates.join(', '));
}