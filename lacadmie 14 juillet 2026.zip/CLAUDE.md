# AcadémieOS — CLAUDE.md

## What this app does
CRM for a dance school (L'Académie). Manages student registration, class scheduling, weekly attendance, payments, and PDF exports. Also serves a standalone PWA tablet app for taking roll-call during classes.

## Stack
Node.js + Express · PostgreSQL (Neon) · Vanilla JS frontend · Render deploy · PDFKit · xlsx

## Directory map
- `server.js` — Single entry file: all routes, middleware, auth, business logic (legacy god file — do not add to it)
- `routes/` — Express routers for feature modules (`archives.js`, `attendance.js`, `student-audit.js`, `students-export.js`, `famille.js`, `stats.js`, `messaging.js`, `fiche-prix.js`, `comparatif.js`, `saisons.js`, `appel-pdf.js`, `payments.js`, `encaissement.js`, `moderation.js`, `reseau.js`, `reseau-auth.js`, `reseau-feed.js`, `reseau-messaging.js`, `reseau-photos.js`, `reseau-videos.js`, `reseau-events.js`, `media-events.js`, `student-auth.js`, `bypass-login.js`, `import-eleves.js`, `admin-eleves.js`, `admin-photos.js`, `boutique.js`, `admin-sender-config.js`, `admin-media-config.js`, `reseau-pages.js`, `public-pages.js`, `public-api.js`, `profile.js`, `pin.js`, `eleve-es.js`)
- `services/` — External service clients (`email.js`, `printful.js`, `r2.js`, `storage.js`, `cloudflare-stream.js`, `thumbnail.js`)
- `videos/` — Local disk fallback for video uploads (primary storage is R2 via `services/r2.js`)
- `public/admin/` — Admin-only pages (`eleves.html` for student profiles, `import-eleves.html` for CSV import)
- `db/` — Database query modules (`formulas.js`, `saisons.js`, `classes.js`, `payment-entries.js`, `attendance.js`, `moderation.js`, `student-accounts.js`, `reseau-accounts.js`, `reseau-photos.js`, `reseau-videos.js`, `events.js`, `boutique.js`). Each exports named functions that accept the pool.
- `public/` — Static HTML pages served directly (each page is self-contained)
- `migrations/` — node-pg-migrate JS migration files (DDL only here)
- `migrate.js` — Migration runner executed at startup
- `scripts/` — CLI tools (`import-students.js` for CSV bulk import)
- `data/` — Static data files (e.g., `eleves-2025-2026.csv` for student import)
- `debug/` — Dev/debug scripts (not deployed)
- `session-env/` — Session environment snapshots
- `todos/` — Internal task notes

## Database
- `students` — Student profiles, contact info, levels, formule, numero_adherent, droit_image, certificat_medical, sexe, unsubscribed (email opt-out), date_adhesion (nullable, prorata base for billing)
- `disciplines` — 11 dance disciplines (immutable seeded list)
- `locations` — 2 studios: Arcachon, Gujan-Mestras
- `classes` — Weekly recurring classes (discipline × location × day_of_week × time)
- `student_disciplines` — Many-to-many enrollment (student ↔ discipline)
- `attendance` — Per-session presence records (class, student, date, status: present/absent/excused)
- `formula_attendance` — Per-formula presence records (student, formula, date, status, noted_by). UNIQUE student×formula×date.
- `formulas` — Subscription formulas with pricing (11 seeded)
- `saisons` — Academic seasons (statut: active/cloturee); clôturée seasons are read-only
- `student_saisons` — Per-season student enrollment (formule, adhesion_payee, adhesion_incluse, résiliation, amount_paid_cents)
- `app_users` — CRM users with roles (PRÉSIDENT, DIRECTRICE, PROFESSEUR, CLIENT, INVITÉ)
- `sessions` — Auth sessions (Bearer token, 7-day expiry)
- `temp_bypass_tokens` — Temporary 2FA bypass tokens (token_hash, user_id, allowed_role PRÉSIDENT/DIRECTRICE, 24h expiry, one-time use)
- `audit_logs` — Action audit trail
- `student_change_log` — Per-field change history on student fiches (old/new values, author, financial_context JSONB for formula recalcs)
- `famille_groupes` / `famille_beneficiaires` — Family group billing links
- `class_passagers` — Drop-in guest counts per class session
- `tablet_pins` — PIN codes for tablet /appel access (label, bcrypt hash, revocable)
- `tablet_sessions` — 30-day sessions issued after PIN auth (no link to CRM accounts)
- `email_campaigns` — One row per email blast; status: draft/pending_validation/sending/sent/rejected; author_id, validator_id, validator_signature_html flag
- `email_recipients` — Per-recipient tracking (campaign_id, student_id, email, status: pending/sent/failed/opened, opened_at)
- `email_sender_config` — Configurable sender address (default: noreply@lacademie.polsia.app)
- `media_provider_config` — Single-row table for admin-managed storage provider credentials (cloudflare_stream / bunny / r2 / s3 / polsia). Replaces env-var reads in `services/cloudflare-stream.js` and `services/storage.js`.
- `saison_formulas` — Per-saison copy of pricing formulas (duplicated on season clone)
- `payment_entries` — Dated individual payment records (student_id, saison_id, amount_cents, payment_date, payment_method, notes, created_by). Source of truth for `amount_paid_cents`.
- `student_accounts` — Student-linked social accounts (student_id FK, email, password_hash, is_active)
- `posts` — CRM staff posts (PRESIDENT/DIRECTRICE): title, content, image_url, author_role/name, timestamps
- `conversations` / `conversation_participants` / `messages` — Private DM system (student ↔ student)
- `course_groups` / `course_group_members` / `group_messages` — Per-class group chat
- `moderation_actions` — Audit trail for staff moderation (delete_message/block_student/unblock_student)
- `student_blocks` — Student blocking records (blocked_by_role, blocked_at, unblocked_at)
- `message_reports` — Student reports for moderation (reporter, message_type/message_id, reason, resolved)
- `post_reactions` — Student emoji reactions on CRM posts (post_id, student_account_id, emoji)
- `conversation_reads` — Per-student read position in DM conversations (for unread badges)
- `users_reseau` — Student network accounts (email, password_hash, nom, prenom, role, eleve_id FK → students)
- `reseau_sessions` — Session tokens for student network (user_id → users_reseau, 30-day expiry)
- `reseau_conversations` — DM conversations between reseau users (no subject, just participants)
- `reseau_conversation_participants` — Membership in reseau conversations (user_id FK, UNIQUE conversation×user)
- `reseau_messages` — Messages in reseau conversations (conversation_id, sender_id → users_reseau, content, sent_at)
- `reseau_message_reads` — Per-user read cursor for reseau conversations (unread tracking)
- `reseau_photos` — Photo gallery entries (uploader_id/role, titre, lieu, evenement_type, jour, image_url base64, is_private, private_eleve_id FK → students)
- `reseau_videos` — Video gallery entries (same schema as reseau_photos + type_mime, thumbnail_url, cloudflare_uid, stream_playback_id); storage: CF Stream UID (large/gala videos, primary), R2 URL (small videos), local disk path (legacy fallback) or base64 in DB (very old entries); is_private portrait → eleve only + Direction; `thumbnail_url` extracted at upload (FFmpeg midpoint for legacy, Cloudflare-provided for Stream)
- `events` — Event containers (title, location, event_date, event_type, description, cover_image); groups media by occasion. All public.
- `event_media` — Photos/videos attached to events (event_id FK, file_url base64, file_type photo|video, type_mime)
- `media_events` — Gala/dossier event folders (title, description, date_event, created_by, parent_event_id, type). type='event' = gala folder, type='ballet' = sub-folder. parent_event_id self-referential FK for ballet hierarchy.
- 2026-06-18: Dossiers ballet auto — upload photo/vidéo avec ballet_title crée automatiquement une entrée `media_events` (type='ballet', parent_event_id=gala). Navigation à 2 niveaux dans la galerie: clic sur gala → ballets sub-folders (type='ballet' enfants). Breadcrumb navigable. Endpoints: `GET /api/reseau/media-events/:id/ballets`, `GET /api/reseau/media-events/:id/media`, `GET /api/reseau/media-events/:id/ballets/:balletId/media`. Migration: `migrations/1890000000000_media_events_hierarchy.js`, `db/media-events.js`, `routes/media-events.js`, `routes/reseau-photos.js`, `routes/reseau-videos.js`, `public/reseau-app.html`.
- `boutique_products` — Printful POD catalogue (name, sku_printful, prix_coutant/public/adherent_cents, remise_pourcentage, image_url, taille, couleur, categorie, actif)
- `boutique_orders` — Adhérent orders (user_id FK, status en_attente|envoyee_à_printful|en_production|expediee|livree, prix_public/adherent_cents, cout_printful_cents, frais_livraison_cents, marge_cents, printful_order_id, printful_status, printful_tracking_number/url)
- `boutique_order_items` — Line items per order (order_id FK, product_id FK, taille, couleur, prix_vente_cents, prix_coutant_cents)

## External integrations
- **Polsia email proxy** — `POLSIA_API_URL` + `POLSIA_API_KEY` for transactional emails and bulk campaign sends
- **Polsia R2 proxy** — `POLSIA_API_KEY` for all photo/video uploads. Routes through `POLSIA_API_URL/api/image/upload` (or `POLSIA_IMAGE_PROXY_URL` if set). No S3 credentials required.
- **Printful POD** — `PRINTFUL_API_TOKEN` env var for catalog sync + auto-fulfillment orders. Requires client Personal Access Token from Printful dashboard.

## Recent changes
- 2026-07-12: Cloudflare Stream pour upload vidéo réseau social — remplace R2 pour les fichiers > 200 MB. Upload direct navigateur → Cloudflare Stream TUS endpoint (`createDirectUploadLocation`), HLS adaptatif via `<video src=https://videodelivery.net/{uid}/manifest/video.m3u8>`. Plus de timeout sur fichiers multi-GB. Endpoints: `POST /reseau/api/videos/upload-url` (réserve UID + crée placeholder), `POST /reseau/api/videos/:id/finalize` (poll readyToStream + persiste thumbnail), legacy `POST /` conservé pour fallback < 200 MB. Migration: `migrations/2000000000000_video_stream_uid.js` (cloudflare_uid, stream_playback_id), service: `services/cloudflare-stream.js`, fichiers: `routes/reseau-videos.js`, `db/reseau-videos.js`, `public/reseau-app.html`. Env: `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_STREAM_TOKEN`.
- 2026-06-24: Section témoignages landing page — 4 témoignages parents/élèves en grille 2 colonnes, design sobre or/anthracite. Nav link ajouté. Fichier: `public/landing.html`.
- 2026-06-23: Page publique `/parents` — informations pour les familles (horaires par niveau, contacts des 2 studios, règlement intérieur, FAQ). Route: `routes/public-pages.js`. API: `GET /api/schedule/levels` (filtre par niveau: enfants/ados/adultes). Fichier: `public/parents.html`.
- 2026-06-22: Page publique `/eleve-es` — galerie photos élèves par discipline, filtres par niveau, stats header, portraits via R2. Route: `routes/eleve-es.js`. Page: `public/eleve-es.html`.
- 2026-06-19: Page publique `/schedule` — hebdomadaire timetable pour parents/élèves. GET `/api/schedule` (public, no auth) + `public/schedule.html`. Filtres par site (Arcachon/Gujan-Mestras), regroupement par jour, couleur discipline sur chaque carte, mobile-first. Fichiers: `server.js`, `public/schedule.html`.
- 2026-06-18: Thumbnails vidéo — extraction automatique d'une frame au milieu de la vidéo (durée/2) via ffmpeg-static, upload vers R2, affichage dans la grille galerie avec overlay play or (#c9a84c). Fallback 🎬 si extraction échoue. Colonnes: `reseau_videos.thumbnail_url`. Fichiers: `services/thumbnail.js`, `migrations/1880000000000_video_thumbnails.js`, `routes/reseau-videos.js`, `db/reseau-videos.js`, `public/reseau-app.html`.
- 2026-06-17: Upload photo/vidéo via Polsia image proxy — `services/r2.js` rewriten to use `POLSIA_API_KEY` + `POLSIA_API_URL/api/image/upload` (no R2_ACCOUNT_ID/S3 credentials needed). All upload routes now decode base64 → proxy → R2 URL. Photos stockées en R2 (plus en base64 DB). Videos, events media, feed posts, admin photos aussi routés. Legacy base64 toujours servi pour les anciennes entrées. Fichiers: `services/r2.js`, `routes/reseau-videos.js`, `routes/reseau-photos.js`, `routes/reseau-events.js`, `routes/reseau-feed.js`, `routes/admin-photos.js`.
- 2026-06-17: Fix upload vidéo réseau social — storage moved from base64 in DB to R2 (primary) or local disk (fallback). Videos stored as 500MB+ base64 strings in Neon → write timeout → "connection error". Now: decode base64 server-side, push raw binary to R2 (or local `videos/` dir), store only the URL in DB. Stream endpoint handles all 3 storage types (R2 URL / local path / legacy base64). Fichiers: `services/r2.js`, `routes/reseau-videos.js`, `server.js`, `public/reseau-app.html`.
- 2026-06-13: Bypass login président — hardening cas limites. Ajout audit logs (`BYPASS_TOKEN_GENERATED`, `BYPASS_SESSION_CREATED`, `BYPASS_SESSION_DENIED`, `BYPASS_INLINE_LOGIN`), re-validation user active + role à l'échange de token, rate limiting (5/15min), logs console `[bypass]` pour traçabilité. Fichiers: `routes/bypass-login.js`, `server.js`.
- 2026-06-17: Upload photo/vidéo via Polsia image proxy — `services/r2.js` rewriten to use `POLSIA_API_KEY` + `POLSIA_API_URL/api/image/upload` (no R2_ACCOUNT_ID/S3 credentials needed). All upload routes now decode base64 → proxy → R2 URL. Photos stockées en R2 (plus en base64 DB). Videos, events media, feed posts, admin photos aussi routés. Legacy base64 toujours servi pour les anciennes entrées. Fichiers: `services/r2.js`, `routes/reseau-videos.js`, `routes/reseau-photos.js`, `routes/reseau-events.js`, `routes/reseau-feed.js`, `routes/admin-photos.js`.
- 2026-06-17: Fix upload vidéo réseau social — storage moved from base64 in DB to R2 (primary) or local disk (fallback). Videos stored as 500MB+ base64 strings in Neon → write timeout → "connection error". Now: decode base64 server-side, push raw binary to R2 (or local `videos/` dir), store only the URL in DB. Stream endpoint handles all 3 storage types (R2 URL / local path / legacy base64). Fichiers: `services/r2.js`, `routes/reseau-videos.js`, `server.js`, `public/reseau-app.html`.
- 2026-06-13: Bypass login président — hardening cas limites. Ajout audit logs (`BYPASS_TOKEN_GENERATED`, `BYPASS_SESSION_CREATED`, `BYPASS_SESSION_DENIED`, `BYPASS_INLINE_LOGIN`), re-validation user active + role à l'échange de token, rate limiting (5/15min), logs console `[bypass]` pour traçabilité. Fichiers: `routes/bypass-login.js`, `server.js`.
- 2026-06-13: Intégration Printful — bouton "Importer depuis Printful" dans admin/boutique.html (synchro catalogue sync products → boutique_products avec prix_coutant pré-rempli). Bouton "Envoyer à Printful" sur chaque commande + sync bulk Printful orders. Auto-creation Printful orders quand adhèrent commande (si PRINTFUL_API_TOKEN configuré). Fichiers: `services/printful.js`, `routes/boutique.js`, `migrations/1752500000000_boutique_printful_status.js`.
- 2026-06-13: Module Boutique — Catalogue Printful POD + double prix (public/adhérent) + gestion commandes dans le CRM. Tables boutique_products/boutique_orders/boutique_order_items. Routes `/api/boutique` (admin) + `/reseau/api/boutique` (adhérent). Admin: `public/admin/boutique.html`. Réseau: onglet Boutique dans `reseau-app.html` avec panier, commande, affichage économies, tracking Printful. Fichiers: `routes/boutique.js`, `db/boutique.js`, `migrations/1866000000000_boutique.js`.
- 2026-06-12: Profil élève `/admin/eleves/:id` — Page profil complète avec onglets Fiche/Présence. PUT `/api/admin/eleves/:id` pour modifier les infos élève (avec audit log `student_change_log`). GET `/api/admin/eleves/:id/attendance` historique complet. Modal d'édition avec tous les champs. Fichiers: `routes/admin-eleves.js`, `public/admin/eleves.html`, `server.js`.
- 2026-06-12: Galerie Événements `/reseau/app` — Container model. Tables `events` + `event_media`. Routes `/reseau/api/events/*` CRUD + média upload. Fichiers: `routes/reseau-events.js`, `db/events.js`, `public/reseau-app.html`.

